using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using NUnit.Framework;
using ServiceTracking.Utils.Database.QueryHelpers;
using System;
using System.Threading.Tasks;

namespace ServiceTracking.Utils.Tests.QueryHelper;

[TestFixture]
public class SearchTextualTests
{
    TestDBContext _context;
    TestRepository<TestEntity> _repository;

    [TearDown]
    public void Cleanup()
    {
        _context.Dispose();
    }

    [SetUp]
    public void Setup()
    {
        var contextOptions = new DbContextOptionsBuilder<TestDBContext>()
               .UseInMemoryDatabase(Guid.NewGuid().ToString())
               .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
               .Options;

        _context = new TestDBContext(contextOptions);
        _context.Database.EnsureCreated();

        DbSeeder.Feed(_context);

        _context.SaveChanges();

        _repository = new TestRepository<TestEntity>(_context);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_Equals()
    {
        await TestSearch("Adrian", FilterOperator.Equals, 1);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_NoResult()
    {
        await TestSearch("Socio", FilterOperator.Equals, 0);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_NotEquals()
    {
        await TestSearch("Adrian", FilterOperator.NotEquals, 3);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_Contains()
    {
        await TestSearch("aco", FilterOperator.Contains, 2);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_Contains_Additional_Or()
    {
        var searchModel = new SearchModel
        {
            AdvancedFilterModels = new System.Collections.Generic.List<AdvancedFilterModel>(){
                    new AdvancedFilterModel{
                        Column = "String",
                        Type =  CellDataType.Text,
                        Value = "great",
                        Operator =   FilterOperator.Contains,
                        AdditionalOperator = FilterOperator.Contains,
                        AdditionalValue = "Paco",
                        Condition= FilterCondition.Or
                    }
                }
        };
        var entities = await _repository.Search(searchModel);
        Assert.AreEqual(3, entities.Count);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_Contains_Additional_And()
    {
        var searchModel = new SearchModel
        {
            AdvancedFilterModels = new System.Collections.Generic.List<AdvancedFilterModel>(){
                    new AdvancedFilterModel{
                        Column = "String",
                        Type =  CellDataType.Text,
                        Value = "great",
                        Operator =   FilterOperator.Contains,
                        AdditionalOperator = FilterOperator.Contains,
                        AdditionalValue = "Paco",
                        Condition= FilterCondition.And
                    }
                }
        };
        var entities = await _repository.Search(searchModel);
        Assert.AreEqual(1, entities.Count);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_Contains_Additional_None()
    {
        var searchModel = new SearchModel
        {
            AdvancedFilterModels = new System.Collections.Generic.List<AdvancedFilterModel>(){
                    new AdvancedFilterModel{
                        Column = "String",
                        Type =  CellDataType.Text,
                        Value = "great",
                        Operator =   FilterOperator.Contains,
                        AdditionalOperator = FilterOperator.Contains,
                        AdditionalValue = "Paco",
                        Condition= FilterCondition.None
                    }
                }
        };
        var entities = await _repository.Search(searchModel);
        Assert.AreEqual(2, entities.Count);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_Contains_NoResults()
    {
        await TestSearch("Socio", FilterOperator.NotContains, 4);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_NotContains()
    {
        await TestSearch("aco", FilterOperator.NotContains, 2);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_NotContains_NoResults()
    {
        await TestSearch("Socio", FilterOperator.Contains, 0);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_StartsWith()
    {
        await TestSearch("Paco", FilterOperator.StartsWith, 2);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_StartsWith_NoResults()
    {
        await TestSearch("Socio", FilterOperator.StartsWith, 0);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_EndsWith()
    {
        await TestSearch("great", FilterOperator.EndsWith, 2);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Textual_EndsWith_NoResults()
    {
        await TestSearch("the", FilterOperator.EndsWith, 0);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public void Search_Textual_GreaterThan()
    {
        Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => TestSearch("1", FilterOperator.GreaterThan, 0));
    }


    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public void Search_Textual_LessThan()
    {
        Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => TestSearch("1", FilterOperator.LessThan, 0));
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public void Search_Textual_Range()
    {
        Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => TestSearch("1", FilterOperator.Range,0));
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public void Search_Textual_None()
    {
        Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => TestSearch("1", FilterOperator.None, 0));
    }

    private async Task TestSearch(string value, FilterOperator operato, int total)
    {
        var searchModel = BuildSearchModel(value, operato);
        var entities = await _repository.Search(searchModel);
        Assert.AreEqual(total, entities.Count);
    }

    private SearchModel BuildSearchModel(string value, FilterOperator operato)
    {
        return new SearchModel
        {
            AdvancedFilterModels = new System.Collections.Generic.List<AdvancedFilterModel>(){
                    new AdvancedFilterModel{
                        Column = "String",
                        Type = CellDataType.Text,
                        Value = value,
                        Operator =  operato
                    }
                }
        };
    }
}