using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using NUnit.Framework;
using ServiceTracking.Utils.Database.QueryHelpers;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceTracking.Utils.Tests.QueryHelper;

[TestFixture]
public class SearchDateTests
{
    private TestDBContext _context;
    private TestRepository<TestEntity> _repository;

    [TearDown]
    public void Cleanup()
    {
        _context.Dispose();
    }

    [SetUp]
    public void Setup()
    {
        var contextOptions = new DbContextOptionsBuilder<TestDBContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;

        _context = new TestDBContext(contextOptions);

        _context.Database.EnsureCreated();

        DbSeeder.Feed(_context);

        _context.SaveChanges();

        _repository = new TestRepository<TestEntity>(_context);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Date_Equals()
    {
        await DateSearch("2020-01-01", FilterOperator.Equals, "Date", 1, "yyyy-MM-dd");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Date_Equals_Nullable()
    {
        var asd = _repository._dbContext.Entities.Where(x => 
            x.DateNullable != null && 
            x.DateNullable.Value.Year == 2020 &&
            x.DateNullable.Value.Month == 1 && 
            x.DateNullable.Value.Day == 1)
    .Select(entity => entity).ToList();

        await DateSearch("2020-01-01", FilterOperator.Equals, "DateNullable", 1, "yyyy-MM-dd");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Date_Equals_Nullable_WithNull()
    {
        await DateSearch(null, FilterOperator.Equals, "DateNullable", 3, "yyyy-MM-dd");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Date_Equals_OtherFormat()
    {
        await DateSearch("01:01:2020", FilterOperator.Equals, "Date", 1, "MM:dd:yyyy");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Date_Equals_Datetime()
    {
        await DateSearch("2018-01-01", FilterOperator.Equals, "Date", 1, "yyyy-MM-dd");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Date_GreaterThan()
    {
        await DateSearch("01:01:2018", FilterOperator.GreaterThan, "Date", 3, "MM:dd:yyyy");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Date_LessThan()
    {
        await DateSearch("01:01:2019", FilterOperator.LessThan, "Date", 3, "MM:dd:yyyy");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public void Search_Date_None()
    {
        Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => DateSearch("01:01:2018", FilterOperator.None, "Date", 3, "MM:dd:yyyy"));
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Date_Range()
    {
        var searchModel = new SearchModel
        {
            AdvancedFilterModels = new System.Collections.Generic.List<AdvancedFilterModel>(){
                    new AdvancedFilterModel{
                        DateFormat = "MM:dd:yyyy",
                        Column = "Date",
                        Type = CellDataType.Date,
                        Value = "01:01:2017",
                        AdditionalValue = "01:01:2019",
                        Operator = FilterOperator.Range
                    }
                }
        };

        var entities = await _repository.Search(searchModel);
        Assert.AreEqual(3, entities.Count);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_DateTime_Equals()
    {
        await DateTimeSearch("2018-01-01 01:02:03", FilterOperator.Equals, "Date", 1, "yyyy-MM-dd hh:mm:ss");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_DateTime_Equals_Nullable()
    {
        await DateTimeSearch("2020-01-01 01:02:03", FilterOperator.Equals, "DateNullable", 1, "yyyy-MM-dd hh:mm:ss");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_DateTime_Equals_Nullable_WithNull()
    {
        await DateTimeSearch(null, FilterOperator.Equals, "DateNullable", 3, "yyyy-MM-dd hh:mm:ss");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_DateTime_Equals_OtherFormat()
    {
        await DateTimeSearch("2018:01:01 01:02:03", FilterOperator.Equals, "Date", 1, "yyyy:MM:dd hh:mm:ss");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_DateTime_GreaterThan()
    {
        await DateTimeSearch("2018-01-01 01:02:03", FilterOperator.GreaterThan, "Date", 3, "yyyy-MM-dd hh:mm:ss");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_DateTime_LessThan()
    {
        await DateTimeSearch("2018-01-01 01:02:03", FilterOperator.LessThan, "Date", 2, "yyyy-MM-dd hh:mm:ss");
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public void Search_DateTime_None()
    {
        Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => DateTimeSearch("2018-01-01 01:02:03", FilterOperator.None, "Date", 3, "yyyy-MM-dd hh:mm:ss"));
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_DateTime_Range()
    {
        var searchModel = new SearchModel
        {
            AdvancedFilterModels = new System.Collections.Generic.List<AdvancedFilterModel>(){
                    new AdvancedFilterModel{
                        DateFormat = "yyyy-MM-dd hh:mm:ss",
                        Column = "Date",
                        Type = CellDataType.DateTime,
                        Value = "2016-01-01 01:01:01",
                        AdditionalValue = "2019-01-01 10:10:10",
                        Operator = FilterOperator.Range
                    }
                }
        };

        var entities = await _repository.Search(searchModel);
        Assert.AreEqual(3, entities.Count);
    }

    private async Task DateSearch(string value, FilterOperator operato, string column, int total, string dateFormat)
    {
        var searchModel = BuildSearchModel(value, operato, column, dateFormat, CellDataType.Date);
        var entities = await _repository.Search(searchModel);

        Assert.AreEqual(total, entities.Count);
    }

    private async Task DateTimeSearch(string value, FilterOperator operato, string column, int total, string dateFormat)
    {
        var searchModel = BuildSearchModel(value, operato, column, dateFormat, CellDataType.DateTime);
        var entities = await _repository.Search(searchModel);

        Assert.AreEqual(total, entities.Count);
    }

    private SearchModel BuildSearchModel(string value, FilterOperator operato, string column, string dateFormat, CellDataType type)
    {
        return new SearchModel
        {
            AdvancedFilterModels = new System.Collections.Generic.List<AdvancedFilterModel>(){
                    new AdvancedFilterModel {
                        DateFormat = dateFormat,
                        Column = column,
                        Type = type,
                        Value = value,
                        Operator = operato
                    }
                }
        };
    }
}