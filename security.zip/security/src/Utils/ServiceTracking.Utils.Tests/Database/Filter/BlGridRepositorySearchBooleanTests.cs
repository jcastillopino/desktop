using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using NUnit.Framework;
using ServiceTracking.Utils.Database.QueryHelpers;
using System;
using System.Threading.Tasks;

namespace ServiceTracking.Utils.Tests.QueryHelper;

[TestFixture]
public class SearchBooleanTests
{
    private TestDBContext _context;
    private TestRepository<TestEntity> _repository;

    [TearDown]
    public void Cleanup()
    {
        _context.Dispose();
    }

    [SetUp]
    public void Setup()
    {
        var contextOptions = new DbContextOptionsBuilder<TestDBContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
            .Options;

        _context = new TestDBContext(contextOptions);
        _context.Database.EnsureCreated();

        DbSeeder.Feed(_context);

        _context.SaveChanges();

        _repository = new TestRepository<TestEntity>(_context);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Bool_Equals_False()
    {
        await BooleanSearch("false", FilterOperator.Equals, "Bool", 1);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Bool_Equals_True()
    {
        await BooleanSearch("true", FilterOperator.Equals, "Bool", 3);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public void Search_Bool_Equals_NotParsed()
    {
        Assert.ThrowsAsync<FormatException>(() => BooleanSearch("truesss", FilterOperator.Equals, "Bool", 3));
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Bool_Equals_Nullable_False()
    {
        await BooleanSearch("false", FilterOperator.Equals, "BoolNullable", 1);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Bool_Equals_Nullable_True()
    {
        await BooleanSearch("true", FilterOperator.Equals, "BoolNullable", 2);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Search_Bool_Equals_Nullable_Null()
    {
        await BooleanSearch(null, FilterOperator.Equals, "BoolNullable", 1);
    }

    private async Task BooleanSearch(string value, FilterOperator operato, string column, int total)
    {
        var searchModel = BuildSearchModel(value, operato, column);
        var entities = await _repository.Search(searchModel);
        Assert.AreEqual(total, entities.Count);
    }

    private SearchModel BuildSearchModel(string value, FilterOperator operato, string column)
    {
        return new SearchModel
        {
            AdvancedFilterModels = new System.Collections.Generic.List<AdvancedFilterModel>(){
                    new AdvancedFilterModel {
                        Column = column,
                        Type = CellDataType.Bool,
                        Value = value,
                        Operator = operato
                    }
                }
        };
    }
}