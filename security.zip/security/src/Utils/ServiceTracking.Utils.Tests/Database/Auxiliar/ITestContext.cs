using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System.Threading;
using System.Threading.Tasks;

namespace ServiceTracking.Utils.Tests.QueryHelper;

public interface ITestContext
{
    DbSet<TestEntity> Entities { get; set; }

    DbContext GetDbContext();

    Task<int> SaveChangesAsync(CancellationToken cancellationToken);

    DatabaseFacade GetDatabase();
}