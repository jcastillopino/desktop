using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System.Threading;
using System.Threading.Tasks;

namespace ServiceTracking.Utils.Tests.QueryHelper;

public class TestDBContext : DbContext, ITestContext
{
    public TestDBContext(DbContextOptions<TestDBContext> options) : base(options)
    {
    }

    public DbSet<TestEntity> Entities { get; set; }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
    {
        return base.SaveChangesAsync(cancellationToken);
    }

    public DatabaseFacade GetDatabase()
    {
        return base.Database;
    }

    public DbContext GetDbContext()
    {
        return this;
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
    }
}