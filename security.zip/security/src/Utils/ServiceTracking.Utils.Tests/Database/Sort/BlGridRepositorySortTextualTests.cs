using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using NUnit.Framework;
using ServiceTracking.Utils.Database.QueryHelpers;
using System;
using System.Linq;
using System.Threading.Tasks;
using SortOrder = ServiceTracking.Utils.Database.QueryHelpers.SortOrder;

namespace ServiceTracking.Utils.Tests.QueryHelper;

[TestFixture]
public class SortTextualTests
{
    TestDBContext _context;
    TestRepository<TestEntity> _repository;

    [TearDown]
    public void Cleanup()
    {
        _context.Dispose();
    }

    [SetUp]
    public void Setup()
    {
        var contextOptions = new DbContextOptionsBuilder<TestDBContext>()
               .UseInMemoryDatabase(Guid.NewGuid().ToString())
               .ConfigureWarnings(b => b.Ignore(InMemoryEventId.TransactionIgnoredWarning))
               .Options;

        _context = new TestDBContext(contextOptions);
        _context.Database.EnsureCreated();

        DbSeeder.Feed(_context);

        _context.SaveChanges();

        _repository = new TestRepository<TestEntity>(_context);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Sort_Textual_Ascending()
    {
        await TestSearch("Adrian", SortOrder.Ascending);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Sort_Textual_Descending()
    {
        await TestSearch("Paco the great", SortOrder.Descending);
    }

    [Category("QueryHelper")]
    [Category("UnitTest")]
    [Test]
    public async Task Sort_Textual_None()
    {
        await TestSearch("Paco", SortOrder.None);
    }

    private async Task TestSearch(string value, SortOrder sortOrder)
    {
        var searchModel = BuildSearchModel(sortOrder);
        var entities = await _repository.Search(searchModel);
        Assert.AreEqual(entities.First().String, value);
    }

    private SearchModel BuildSearchModel(SortOrder sortOrder)
    {
        return new SearchModel
        {
            SortModel = new SortModel
            {
                ColumnName = "String",
                Order = sortOrder
            }
        };
    }
}