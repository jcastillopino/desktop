using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.AutoMock;
using Newtonsoft.Json;
using NUnit.Framework;
using ServiceTracking.Utils.Exceptions;
using ServiceTracking.Utils.Helpers;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace ServiceTracking.Utils.Tests.Exceptions;

internal class TestSetup
{
    public TestSetup()
    {
        ContextMoq = new DefaultHttpContext();
        Environment = new Mock<IWebHostEnvironment>();
        DelegateMoq = new Mock<RequestDelegate>();
        Logger = new ILoggerFake(new Exception());
        LoggerFactory = new Mock<ILoggerFactory>();
        WriteResponse = string.Empty;
        GuidHelper = new Mock<IGuidHelper>();
    }

    public Mock<ILoggerFactory> LoggerFactory { get; private set; }

    public Mock<IGuidHelper> GuidHelper { get; private set; }

    internal HttpContext ContextMoq { get; private set; }

    internal Mock<IWebHostEnvironment> Environment { get; private set; }

    internal Mock<RequestDelegate> DelegateMoq { get; private set; }

    internal ILoggerFake Logger { get; private set; }

    internal string WriteResponse { get; set; }

    public void Setup(Exception exception)
    {
        ContextMoq.Response.Body = new MemoryStream();

        Environment.Setup(x => x.EnvironmentName).Returns("Development");

        if (exception != null)
        {
            Logger.Exception = exception;
        }

        DelegateMoq.Setup(x => x.Invoke(ContextMoq)).Throws(Logger.Exception);
        LoggerFactory.Setup(_ => _.CreateLogger(It.IsAny<string>())).Returns(Logger);
    }

    public void SetupForResponse(bool isDevelopment, Exception exception)
    {
        Setup(exception);

        if (isDevelopment)
            Environment.Setup(x => x.EnvironmentName).Returns("Development");
        else
            Environment.Setup(x => x.EnvironmentName).Returns("Production");
    }
}

[TestFixture]
public class ResponseErrorMiddlewareTests
{
    [Test]
    [Category("UnitTest")]
    public async Task Should_LogException()
    {
        var testVars = new TestSetup();
        testVars.Setup(new Exception("My Custom"));
        testVars.GuidHelper.Setup(x => x.CreateNew()).Returns(Guid.Parse("85b68b98-345d-4c0f-8dda-b195947cb287"));

        var container = new AutoMocker();

        var sut = BuildSut(testVars);
        await sut.Invoke(testVars.ContextMoq);

        Assert.IsTrue(testVars.Logger.LogErrorCalled);
        Assert.IsTrue(testVars.Logger.IsExceptionCorrect);
    }

    [Test]
    [Category("UnitTest")]
    public async Task Should_WriteUnauthorizedReponse()
    {
        var expectedResponse = "{\"Type\":null,\"Title\":\"Unauthorized\",\"Status\":401,\"Detail\":\"Unauthorized\",\"Instance\":null,\"Extensions\":{\"Correlation\":\"85b68b98-345d-4c0f-8dda-b195947cb287\"}}";
        var statusCodeExpected = (int)HttpStatusCode.Unauthorized;

        var testVars = new TestSetup();
        testVars.SetupForResponse(false, new UnauthorizedAccessException("Should_WriteUnauthorizedReponse"));
        testVars.GuidHelper.Setup(x => x.CreateNew()).Returns(Guid.Parse("85b68b98-345d-4c0f-8dda-b195947cb287"));

        var sut = BuildSut(testVars);

        await sut.Invoke(testVars.ContextMoq);

        testVars.ContextMoq.Response.Body.Position = 0;
        using (var sr = new StreamReader(testVars.ContextMoq.Response.Body))
            testVars.WriteResponse = sr.ReadToEnd();

        Assert.AreEqual(expectedResponse, testVars.WriteResponse);
        Assert.AreEqual(statusCodeExpected, testVars.ContextMoq.Response.StatusCode);
    }

    [Test]
    [Category("UnitTest")]
    public async Task Should_WriteGenericReponse()
    {
        var testVars = new TestSetup();
        testVars.SetupForResponse(false, new Exception("Should_WriteGenericReponse"));
        testVars.GuidHelper.Setup(x => x.CreateNew()).Returns(Guid.Parse("f5b68b98-345d-4c0f-8dda-b195947cb287"));

        var sut = BuildSut(testVars);

        await sut.Invoke(testVars.ContextMoq);

        var expectedResponse = "{\"Type\":null,\"Title\":\"Internal Server Error\",\"Status\":500,\"Detail\":\"An unhandled error has occurred.\",\"Instance\":null,\"Extensions\":{\"Correlation\":\"f5b68b98-345d-4c0f-8dda-b195947cb287\"}}";
        var statusCodeExpected = (int)HttpStatusCode.InternalServerError;

        testVars.ContextMoq.Response.Body.Position = 0;
        using (var sr = new StreamReader(testVars.ContextMoq.Response.Body))
            testVars.WriteResponse = sr.ReadToEnd();

        Assert.AreEqual(expectedResponse, testVars.WriteResponse);
        Assert.AreEqual(statusCodeExpected, testVars.ContextMoq.Response.StatusCode);
    }

    [Test]
    [Category("UnitTest")]
    public async Task Should_WriteStackForDevelopment()
    {
        var exception = new Exception("Should_WriteStackForDevelopment");
        var testVars = new TestSetup();
        testVars.SetupForResponse(true, exception);
        testVars.GuidHelper.Setup(x => x.CreateNew()).Returns(Guid.Parse("f5b68b98-345d-4c0f-8dda-b195947cb287"));

        var sut = BuildSut(testVars);

        await sut.Invoke(testVars.ContextMoq);

        testVars.ContextMoq.Response.Body.Position = 0;
        using (var sr = new StreamReader(testVars.ContextMoq.Response.Body))
            testVars.WriteResponse = sr.ReadToEnd();

        var response = JsonConvert.DeserializeObject<ProblemDetails>(testVars.WriteResponse);
        var statusCodeExpected = (int)HttpStatusCode.InternalServerError;

        Assert.IsTrue(response!.Extensions!.ContainsKey("Exception"));
        Assert.AreEqual(statusCodeExpected, testVars.ContextMoq.Response.StatusCode);
    }

    [Test]
    [Category("UnitTest")]
    public async Task Should_WriteCustomException()
    {
        var testVars = new TestSetup();
        testVars.SetupForResponse(false, new CustomException("Should_WriteCustomException", Guid.Parse("ffb68b98-345d-4c0f-8dda-b195947cb287")));

        var sut = BuildSut(testVars);

        await sut.Invoke(testVars.ContextMoq);

        testVars.ContextMoq.Response.Body.Position = 0;
        using (var sr = new StreamReader(testVars.ContextMoq.Response.Body))
            testVars.WriteResponse = sr.ReadToEnd();

        var expectedResponse = "{\"Type\":null,\"Title\":\"Internal Server Error\",\"Status\":500,\"Detail\":\"Should_WriteCustomException\",\"Instance\":null,\"Extensions\":{\"Correlation\":\"ffb68b98-345d-4c0f-8dda-b195947cb287\"}}";
        var statusCodeExpected = (int)HttpStatusCode.InternalServerError;

        Assert.AreEqual(expectedResponse, testVars.WriteResponse);
        Assert.AreEqual(statusCodeExpected, testVars.ContextMoq.Response.StatusCode);
    }

    [Test]
    [Category("UnitTest")]
    public async Task Should_WriteCustomExceptionJson()
    {
        var jsonExpected = "{\"TestProperty\":\"TestValue\"}";
        int statusCodeExpected = (int)HttpStatusCode.InternalServerError;
        var testVars = new TestSetup();

        testVars.SetupForResponse(false, new CustomExceptionJson("Should_WriteCustomExceptionJson", jsonExpected));

        var sut = BuildSut(testVars);

        await sut.Invoke(testVars.ContextMoq);

        testVars.ContextMoq.Response.Body.Position = 0;
        using (var sr = new StreamReader(testVars.ContextMoq.Response.Body))
            testVars.WriteResponse = sr.ReadToEnd();

        Assert.AreEqual(jsonExpected, testVars.WriteResponse);
        Assert.AreEqual(statusCodeExpected, testVars.ContextMoq.Response.StatusCode);
    }

    [Test]
    [Category("UnitTest")]
    public async Task Should_WriteBadRequestReponse()
    {
        var exception = new BadHttpRequestException("Should_WriteBadRequestReponse");
        var testVars = new TestSetup();
        testVars.SetupForResponse(false, exception);
        testVars.GuidHelper.Setup(x => x.CreateNew()).Returns(Guid.Parse("85b68b98-345d-4c0f-8dda-b195947cb287"));

        var sut = BuildSut(testVars);
        await sut.Invoke(testVars.ContextMoq);

        testVars.ContextMoq.Response.Body.Position = 0;
        using (var sr = new StreamReader(testVars.ContextMoq.Response.Body))
            testVars.WriteResponse = sr.ReadToEnd();

        var expectedResponse = "{\"Type\":null,\"Title\":\"Bad Request\",\"Status\":400,\"Detail\":\"Should_WriteBadRequestReponse\",\"Instance\":null,\"Extensions\":{\"Correlation\":\"85b68b98-345d-4c0f-8dda-b195947cb287\"}}";
        int statusCodeExpected = (int)HttpStatusCode.BadRequest;

        Assert.AreEqual(expectedResponse, testVars.WriteResponse);
        Assert.AreEqual(statusCodeExpected, testVars.ContextMoq.Response.StatusCode);
    }

    private static ResponseErrorMiddleware BuildSut(TestSetup testVars)
    {
        return new ResponseErrorMiddleware(
            testVars.DelegateMoq.Object,
            testVars.Environment.Object,
            testVars.LoggerFactory.Object,
            testVars.GuidHelper.Object);
    }
}