using Microsoft.Extensions.Logging;
using System;

namespace ServiceTracking.Utils.Tests;

public class ILoggerFake : ILogger
{
    public bool LogErrorCalled { get; private set; }

    public bool IsExceptionCorrect { get; private set; }

    public Exception Exception { get; set; }

    public ILoggerFake(Exception exception)
    {
        Exception = exception;
    }

    public IDisposable BeginScope<TState>(TState state)
    {
        throw new NotImplementedException();
    }

    public bool IsEnabled(LogLevel logLevel) => true;

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
    {
        if (logLevel == LogLevel.Error)
        {
            LogErrorCalled = true;
        }

        if (exception == Exception)
        {
            IsExceptionCorrect = true;
        }
    }
}