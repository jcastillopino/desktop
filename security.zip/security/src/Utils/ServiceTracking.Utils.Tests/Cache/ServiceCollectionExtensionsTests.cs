using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using ServiceTracking.Utils.Cache;
using ServiceTracking.Utils.Cache.Configuration;
using ServiceTracking.Utils.Cache.Definitions;
using ServiceTracking.Utils.Cache.Exceptions;

namespace ServiceTracking.Utils.Tests.Cache;

[TestFixture]
public class ServiceCollectionExtensionsTests
{
    [Test]
    [Category("UnitTest")]
    public void AddCacheSupport_CorrecltyCreatesCacheService()
    {
        var configuration = new CacheConfiguration()
        {
            Buckets = new List<CacheBucketConfiguration>()
                {
                    new CacheBucketConfiguration()
                    {
                        Key = "inMemoryBucket",
                        BucketContentType = "System.String",
                        CacheTechnology = "InMemory"
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "configuredBucket",
                        BucketContentType = "System.String",
                        BucketType = "Standard",
                        CacheTechnology = "InMemory",
                        MaximunRecords = 5,
                        SlidingExpiration = TimeSpan.Parse("02:30:30"),
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "inMemoryStaticBucket",
                        BucketContentType = "System.String",
                        CacheTechnology = "InMemory",
                        BucketType = "Static"
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "configuredStaticBucket",
                        BucketContentType = "System.String",
                        BucketType = "Static",
                        CacheTechnology = "InMemory",
                        MaximunRecords = 3,
                        SlidingExpiration = TimeSpan.Parse("01:30:30"),
                    },
                }
        };

        var expectedBucketParameters = new BucketParameters[] {
                new BucketParameters
                {
                    BucketName = $"{BucketTypes.Standard}-{configuration.Buckets[0].Key}",
                    MaximumRecords = configuration.Buckets[0].MaximunRecords,
                    SlidingExpiration = configuration.Buckets[0].SlidingExpiration
                },
                new BucketParameters
                {
                    BucketName = $"{BucketTypes.Standard}-{configuration.Buckets[1].Key}",
                    MaximumRecords = configuration.Buckets[1].MaximunRecords,
                    SlidingExpiration = configuration.Buckets[1].SlidingExpiration
                },
                new BucketParameters
                {
                    BucketName = $"{BucketTypes.Static}-{configuration.Buckets[2].Key}",
                    MaximumRecords = configuration.Buckets[2].MaximunRecords,
                    SlidingExpiration = configuration.Buckets[2].SlidingExpiration
                },
                new BucketParameters
                {
                    BucketName = $"{BucketTypes.Static}-{configuration.Buckets[3].Key}",
                    MaximumRecords = configuration.Buckets[3].MaximunRecords,
                    SlidingExpiration = configuration.Buckets[3].SlidingExpiration
                },
            };

        var expectedStandardBuckets = new List<CacheBucket>
            {
                new CacheBucket(configuration.Buckets[0].Key, typeof(string), typeof(InMemoryBucket<>), BucketTypes.Standard, expectedBucketParameters[0]),
                new CacheBucket(configuration.Buckets[1].Key, typeof(string), typeof(InMemoryBucket<>), BucketTypes.Standard, expectedBucketParameters[1]),
                new CacheBucket(configuration.Buckets[2].Key, typeof(string), typeof(InMemoryStaticBucket<>), BucketTypes.Static, expectedBucketParameters[2]),
                new CacheBucket(configuration.Buckets[3].Key, typeof(string), typeof(InMemoryStaticBucket<>), BucketTypes.Static, expectedBucketParameters[3]),
            };

        var services = new ServiceCollection();
        services.AddCacheSupport(configuration);

        var cacheService = services.BuildServiceProvider().GetService<ICacheService>();

        Assert.Multiple(() =>
        {
            Assert.IsNotNull(cacheService);
            var serviceBuckets = cacheService!.GetType().GetField("_buckets", BindingFlags.Instance | BindingFlags.NonPublic)
                !.GetValue(cacheService) as IEnumerable<CacheBucket>;
            CollectionAssert.AreEqual(expectedStandardBuckets, serviceBuckets);
        });
    }

    [Test]
    [Category("UnitTest")]
    public void AddCacheSupport_WhenPassingInvalidBucketType_ThrowsCacheConfigurationException()
    {
        var expectedInvalidTypes = new List<string>() { "invalidType1", "anotherInvalidType" };
        var configuration = new CacheConfiguration()
        {
            Buckets = new List<CacheBucketConfiguration>()
                {
                    new CacheBucketConfiguration()
                    {
                        Key = "inMemoryBucket",
                        BucketContentType = "System.String",
                        CacheTechnology = "InMemory"
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "invalidType1",
                        BucketContentType = expectedInvalidTypes[0],
                        CacheTechnology = "InMemory"
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "invalidType2",
                        BucketContentType = expectedInvalidTypes[1],
                        CacheTechnology = "InMemory"
                    },
                }
        };

        var services = new ServiceCollection();
        var ex = Assert.Throws<AggregateException>(() => services.AddCacheSupport(configuration));

        var invalidBucketTypes = ex!.InnerExceptions.Where(ie => ie.GetType() == typeof(InvalidBucketContentTypeException))
            .Cast<InvalidBucketContentTypeException>()
            .Select(e => e.InvalidTypeName);
        CollectionAssert.AreEqual(expectedInvalidTypes, invalidBucketTypes);
    }

    [Test]
    [Category("UnitTest")]
    public void AddCacheSupport_WhenPassingInvalidCacheTechnologyType_ThrowsCacheConfigurationException()
    {
        var expectedInvalidTechnologies = new List<string>() { "invalidType1", "anotherInvalidType" };
        var configuration = new CacheConfiguration()
        {
            Buckets = new List<CacheBucketConfiguration>()
                {
                    new CacheBucketConfiguration()
                    {
                        Key = "inMemoryBucket",
                        BucketContentType = "System.String",
                        CacheTechnology = "InMemory"
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "invalidType1",
                        BucketContentType = "System.String",
                        CacheTechnology = expectedInvalidTechnologies[0]
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "invalidType2",
                        BucketContentType = "System.String",
                        CacheTechnology = expectedInvalidTechnologies[1]
                    },
                }
        };

        var services = new ServiceCollection();
        var ex = Assert.Throws<AggregateException>(() => services.AddCacheSupport(configuration));

        var invalidCacheTechnologyTypes = ex!.InnerExceptions.Where(ie => ie.GetType() == typeof(InvalidCacheTechnologyException))
           .Cast<InvalidCacheTechnologyException>()
           .Select(e => e.Technology);
        CollectionAssert.AreEqual(expectedInvalidTechnologies, invalidCacheTechnologyTypes);
    }

    [Test]
    [Category("UnitTest")]
    public void AddCacheSupport_WhenPassingInvalidBuvketType_ThrowsCacheConfigurationException()
    {
        var expectedInvalidBucketTypes = new List<string>() { "invalidType1", "anotherInvalidType" };
        var configuration = new CacheConfiguration()
        {
            Buckets = new List<CacheBucketConfiguration>()
                {
                    new CacheBucketConfiguration()
                    {
                        Key = "inMemoryBucket",
                        BucketContentType = "System.String",
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "invalidType1",
                        BucketContentType = "System.String",
                        BucketType = expectedInvalidBucketTypes[0],
                    },
                    new CacheBucketConfiguration()
                    {
                        Key = "invalidType2",
                        BucketContentType = "System.String",
                        BucketType = expectedInvalidBucketTypes[1],
                    },
                }
        };

        var services = new ServiceCollection();
        var ex = Assert.Throws<AggregateException>(() => services.AddCacheSupport(configuration));

        var invalidBucketTypes = ex!.InnerExceptions.Where(ie => ie.GetType() == typeof(InvalidBucketTypeException))
           .Cast<InvalidBucketTypeException>()
           .Select(e => e.InvalidTypeName);
        CollectionAssert.AreEqual(expectedInvalidBucketTypes, invalidBucketTypes);
    }

    [Test]
    [Category("UnitTest")]
    public void AddCacheSupport_WhenUsingInMemoryCache_ConfiguresIMemoryCacheDependency()
    {
        var configuration = new CacheConfiguration()
        {
            Buckets = new List<CacheBucketConfiguration>()
                {
                    new CacheBucketConfiguration()
                    {
                        Key = "inMemoryBucket",
                        BucketContentType = "System.String",
                        CacheTechnology = "InMemory"
                    },
                }
        };

        var services = new ServiceCollection();
        services.AddCacheSupport(configuration);

        var provider = services.BuildServiceProvider();
        var memoryCache = provider.GetService<IMemoryCache>();

        Assert.IsNotNull(memoryCache);
    }
}