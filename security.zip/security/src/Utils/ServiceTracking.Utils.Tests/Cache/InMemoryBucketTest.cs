using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using ServiceTracking.Utils.Cache;
using ServiceTracking.Utils.Cache.Configuration;
using ServiceTracking.Utils.Cache.Exceptions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServiceTracking.Utils.Tests.Cache;

[TestFixture]
internal class InMemoryBucketTest
{
    [Test]
    [Category("UnitTest")]
    public async Task AddInMemoryBucket_ShouldBeAdded()
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, cache, new Mock<ILogger<InMemoryBucket<string>>>().Object);
        var item = new KeyValuePair<string, string>("keyItem", "valueItem");
        await memoryBucket.Add("keyItem", "valueItem");

        var result = await memoryBucket.Get(item.Key);

        Assert.AreEqual(result, item.Value);
    }

    [Test]
    [Category("UnitTest")]
    public async Task RemoveInMemoryBucket_ShouldReturnObject()
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var item = new KeyValuePair<string, string>("keyItem", "valueItem");
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);
        await memoryBucket.Add(item.Key, item.Value);

        var result = await memoryBucket.Remove(item.Key);

        Assert.AreEqual(item.Value, result);
    }

    [Test]
    [Category("UnitTest")]
    public async Task RemoveInMemoryBucket_ShouldReturnNull()
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var item = new KeyValuePair<string, string>("keyItem", "valueItem");
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        var result = await memoryBucket.Remove(item.Key);

        Assert.AreEqual(null, result);
    }

    [Test]
    [Category("UnitTest")]
    public async Task GetObjectInMemoryBucket_ShouldReturnObject()
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var item = new KeyValuePair<string, string>("keyItem", "valueItem");
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);
        await memoryBucket.Add(item.Key, item.Value);

        var result = await memoryBucket.Get(item.Key);

        Assert.AreEqual(item.Value, result);
    }

    [Test]
    [Category("UnitTest")]
    public async Task GetObjectInMemoryBucket_ShouldReturnNull()
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var item = new KeyValuePair<string, string>("keyItem", "valueItem");
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        var result = await memoryBucket.Get(item.Key);

        Assert.AreEqual(null, result);
    }

    [Test]
    [TestCase(null)]
    [TestCase("")]
    [Category("UnitTest")]
    public void AddInMemoryBucket_ArgumentNullException(string key)
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, cache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        Assert.ThrowsAsync<ArgumentNullException>(() => memoryBucket.Add(key, null));
    }

    [Test]
    [TestCase(null)]
    [TestCase("")]
    [Category("UnitTest")]
    public void RemoveInMemoryBucket_ArgumentNullException(string key)
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        Assert.ThrowsAsync<ArgumentNullException>(() => memoryBucket.Remove(key));
    }

    [Test]
    [TestCase(null)]
    [TestCase("")]
    [Category("UnitTest")]
    public void GetObjectInMemoryBucket_ArgumentNullException(string key)
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        Assert.ThrowsAsync<ArgumentNullException>(() => memoryBucket.Get(key));
    }

    [Test]
    [Category("UnitTest")]
    public void AddInMemoryBucket_CacheBucketOperationException()
    {
        var memoryCache = new Mock<IMemoryCache>();
        memoryCache.Setup(m => m.CreateEntry(It.IsAny<string>())).Throws(new Exception());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache.Object, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        Assert.ThrowsAsync<CacheBucketOperationException>(() => memoryBucket.Add("key", null));
    }

    [Test]
    [Category("UnitTest")]
    public void RemoveInMemoryBucket_CacheBucketOperationException()
    {
        var memoryCache = new Mock<IMemoryCache>();
        object value = "string";
        memoryCache.Setup(m => m.TryGetValue(It.IsAny<string>(), out value));
        memoryCache.Setup(m => m.Remove(It.IsAny<string>())).Throws(new Exception());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache.Object, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        Assert.ThrowsAsync<CacheBucketOperationException>(() => memoryBucket.Remove("key"));
    }

    [Test]
    [Category("UnitTest")]
    public void GetObjectInMemoryBucket_CacheBucketOperationException()
    {
        var memoryCache = new Mock<IMemoryCache>();
        object value = "string";
        memoryCache.Setup(m => m.TryGetValue(It.IsAny<string>(), out value)).Throws(new Exception());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache.Object, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        Assert.ThrowsAsync<CacheBucketOperationException>(() => memoryBucket.Get("key"));
    }

    [Test]
    [Category("UnitTest")]
    public async Task TryGetObjectFromCache_ObjectInCache_ShouldReturnObjectFromCache()
    {
        var key = "memoryCacheKey";
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        memoryCache.Set(key, GetString());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        var result = await memoryBucket.Get(key, () => GetString());

        Assert.AreEqual(result, GetString());
    }

    [Test]
    [Category("UnitTest")]
    public async Task TryGetObjectFromCache_ObjectNotInCache_ShouldReturnObjectFromFunc()
    {
        var key = "memoryCacheKey";
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        var result = await memoryBucket.Get(key, () => GetString());

        Assert.AreEqual(result, GetString());
    }

    [Test]
    [TestCase(null)]
    [TestCase("")]
    [Category("UnitTest")]
    public void TryGetObjectFromCache_ArgumentNullException_Key(string key)
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };

        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        Assert.ThrowsAsync<ArgumentNullException>(() => memoryBucket.Get(key, () => GetString()));
    }

    [Test]
    [Category("UnitTest")]
    public async Task TryGetObjectFromCache_CacheFails_ReturnsFuncData()
    {
        var key = "memoryCacheKey";
        var memoryCache = new Mock<IMemoryCache>();
        memoryCache.Setup(m => m.CreateEntry(It.IsAny<string>())).Throws(new Exception());
        var logger = new Mock<ILogger<InMemoryBucket<string>>>();
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache.Object, logger.Object);

        var result = await memoryBucket.Get(key, () => GetString());

        Assert.AreEqual(result, GetString());
    }

    [Test]
    [Category("UnitTest")]
    public async Task Get_ObjectInCache_ShouldReturnObjectFromCache_AsyncFunc()
    {
        var key = "memoryCacheKey";
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        memoryCache.Set(key, GetString());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        var result = await memoryBucket.Get(key, () => GetStringAsync());

        Assert.AreEqual(result, GetString());
    }

    [Test]
    [Category("UnitTest")]
    public async Task Get_ObjectNotInCache_ShouldReturnObjectFromAsyncFunc()
    {
        var key = "memoryCacheKey";

        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);
        var result = await memoryBucket.Get(key, () => GetStringAsync());

        Assert.AreEqual(result, GetString());
    }

    [Test]
    [TestCase(null)]
    [TestCase("")]
    [Category("UnitTest")]
    public void Get_ArgumentNullException_Key_AsyncFunc(string key)
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryBucket<string>>>().Object);

        Assert.ThrowsAsync<ArgumentNullException>(() => memoryBucket.Get(key, () => GetStringAsync()));
    }

    [Test]
    [Category("UnitTest")]
    public async Task Get_CacheFails_ReturnsAsyncFuncData()
    {
        var key = "memoryCacheKey";
        var memoryCache = new Mock<IMemoryCache>();
        memoryCache.Setup(m => m.CreateEntry(It.IsAny<string>())).Throws(new Exception());
        var logger = new Mock<ILogger<InMemoryBucket<string>>>();
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryBucket<string>(bucketParameters, memoryCache.Object, logger.Object);

        var result = await memoryBucket.Get(key, () => GetStringAsync());

        Assert.AreEqual(result, GetString());
    }

    private string GetString()
    {
        return "one";
    }

    private Task<string> GetStringAsync()
    {
        return Task.FromResult("one");
    }
}
