using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using ServiceTracking.Utils.Cache;
using ServiceTracking.Utils.Cache.Configuration;
using ServiceTracking.Utils.Cache.Exceptions;

namespace ServiceTracking.Utils.Tests.Cache;

[TestFixture]
public class CacheServiceTests
{
    [Test]
    [Category("UnitTest")]
    public void GetBucket_CorrecltyConstructsBucket()
    {
        var bucketKey = "bucketKey";
        var bucketParameters = new BucketParameters { BucketName = bucketKey };
        var buckets = new List<CacheBucket>()
            {
                new CacheBucket(bucketKey, typeof(string), typeof(InMemoryBucket<>), BucketTypes.Standard, bucketParameters),
            };

        var serviceProviderMock = new Mock<IServiceProvider>();
        serviceProviderMock.Setup(p => p.GetService(typeof(IMemoryCache)))
            .Returns(new Mock<IMemoryCache>().Object)
            .Verifiable();
        serviceProviderMock.Setup(p => p.GetService(typeof(ILogger<InMemoryBucket<string>>)))
            .Returns(new Mock<ILogger<InMemoryBucket<string>>>().Object)
            .Verifiable();

        var sut = new CacheService(buckets, serviceProviderMock.Object);

        var bucket = sut.GetBucket<string>(bucketKey);

        Assert.IsNotNull(bucket);
        serviceProviderMock.Verify();
    }

    [Test]
    [Category("UnitTest")]
    public void GetBucket_WhenPassingUnexistingBucket_ThrowsCacheBucketNotFoundException()
    {
        var buckets = new List<CacheBucket>();
        var serviceProvider = new Mock<IServiceProvider>().Object;
        var sut = new CacheService(buckets, serviceProvider);

        Assert.Throws<CacheBucketNotFoundException>(() => sut.GetBucket<string>("someBucket"));
    }

    [Test]
    [Category("UnitTest")]
    public void GetBucket_WhenFailingToCreateBucket_ThrowsBucketCreationException()
    {
        var bucketKey = "bucketKey";
        var buckets = new List<CacheBucket>()
            {
                new CacheBucket(bucketKey, typeof(string), typeof(InMemoryBucket<>), BucketTypes.Standard, new BucketParameters()),
            };

        var serviceProviderMock = new Mock<IServiceProvider>();
        serviceProviderMock.Setup(p => p.GetService(typeof(IMemoryCache)))
            .Returns(null);

        var sut = new CacheService(buckets, serviceProviderMock.Object);

        Assert.Throws<BucketCreationException>(() => sut.GetBucket<string>(bucketKey));
    }

    [Test]
    [Category("UnitTest")]
    public void GetStaticBucket_CorrecltyConstructsBucket()
    {
        var bucketKey = "bucketKey";
        var bucketParameters = new BucketParameters { BucketName = bucketKey };
        var buckets = new List<CacheBucket>()
            {
                new CacheBucket(bucketKey, typeof(string), typeof(InMemoryStaticBucket<>), BucketTypes.Static, bucketParameters),
            };

        var serviceProviderMock = new Mock<IServiceProvider>();
        serviceProviderMock.Setup(p => p.GetService(typeof(IMemoryCache)))
            .Returns(new Mock<IMemoryCache>().Object)
            .Verifiable();
        serviceProviderMock.Setup(p => p.GetService(typeof(ILogger<InMemoryStaticBucket<string>>)))
            .Returns(new Mock<ILogger<InMemoryStaticBucket<string>>>().Object)
            .Verifiable();

        var sut = new CacheService(buckets, serviceProviderMock.Object);

        var bucket = sut.GetStaticBucket<string>(bucketKey);

        Assert.IsNotNull(bucket);
        serviceProviderMock.Verify();
    }

    [Test]
    [Category("UnitTest")]
    public void GetStaticBucket_WhenPassingUnexistingBucket_ThrowsCacheBucketNotFoundException()
    {
        var buckets = new List<CacheBucket>();
        var serviceProvider = new Mock<IServiceProvider>().Object;
        var sut = new CacheService(buckets, serviceProvider);

        Assert.Throws<CacheBucketNotFoundException>(() => sut.GetStaticBucket<string>("someBucket"));
    }

    [Test]
    [Category("UnitTest")]
    public void GetStaticBucket_WhenFailingToCreateBucket_ThrowsBucketCreationException()
    {
        var bucketKey = "bucketKey";
        var buckets = new List<CacheBucket>()
            {
                new CacheBucket(bucketKey, typeof(string), typeof(InMemoryStaticBucket<>), BucketTypes.Static, new BucketParameters()),
            };

        var serviceProviderMock = new Mock<IServiceProvider>();
        serviceProviderMock.Setup(p => p.GetService(typeof(IMemoryCache)))
            .Returns(null);

        var sut = new CacheService(buckets, serviceProviderMock.Object);

        Assert.Throws<BucketCreationException>(() => sut.GetStaticBucket<string>(bucketKey));
    }
}