using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ServiceTracking.Utils.Cache;
using ServiceTracking.Utils.Cache.Configuration;
using ServiceTracking.Utils.Cache.Exceptions;

namespace ServiceTracking.Utils.Tests.Cache;

[TestFixture]
internal class InMemoryStaticBucketTest
{
    [Test]
    [Category("UnitTest")]
    public async Task AddInMemoryBucket_ShouldBeAdded()
    {
        var mockCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, mockCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);
        var itemList = new List<string>() { "OneItem" };

        await memoryBucket.Add(itemList);

        var result = await memoryBucket.Get();

        Assert.AreEqual(result.First(), "OneItem");
    }

    [Test]
    [Category("UnitTest")]
    public async Task RemoveInMemoryBucket_ShouldReturnNull()
    {
        var mockCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, mockCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        var result = await memoryBucket.Remove();

        Assert.IsNull(result);
    }

    [Test]
    [Category("UnitTest")]
    public async Task RemoveInMemoryBucket_ShouldReturnObject()
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var key = "memoryStaticCacheKey";
        memoryCache.Set(key, new List<string> { "one", "two" });
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        var result = await memoryBucket.Remove();

        Assert.AreEqual(result.First(), "one");
    }

    [Test]
    [Category("UnitTest")]
    public async Task RemoveInMemoryBucket_ShouldReturnObje()
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var key = "memoryStaticCacheKey";
        memoryCache.Set(key, new List<string> { "one", "two" });
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        var result = await memoryBucket.Remove();

        Assert.AreEqual(result.First(), "one");
    }

    [Test]
    [Category("UnitTest")]
    public async Task GetObjectInMemoryBucket_ShouldReturnObject()
    {
        var key = "memoryStaticCacheKey";
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        memoryCache.Set(key, new List<string> { "one", "two", "three" });
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        var result = await memoryBucket.Get();

        Assert.AreEqual(result.FirstOrDefault(), "one");
        Assert.AreEqual(result.Last(), "three");
    }

    [Test]
    [Category("UnitTest")]
    public void AddInMemoryBucket_CacheBucketOperationException()
    {
        var memoryCache = new Mock<IMemoryCache>();
        memoryCache.Setup(m => m.CreateEntry(It.IsAny<string>())).Throws(new Exception());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache.Object, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        Assert.ThrowsAsync<CacheBucketOperationException>(() => memoryBucket.Add(null));
    }

    [Test]
    [Category("UnitTest")]
    public void RemoveInMemoryBucket_CacheBucketOperationException()
    {
        var memoryCache = new Mock<IMemoryCache>();
        object value = "string";
        memoryCache.Setup(m => m.TryGetValue(It.IsAny<string>(), out value));
        memoryCache.Setup(m => m.Remove(It.IsAny<string>())).Throws(new Exception());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache.Object, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        Assert.ThrowsAsync<CacheBucketOperationException>(() => memoryBucket.Remove());
    }

    [Test]
    [Category("UnitTest")]
    public void GetObjectInMemoryBucket_CacheBucketOperationException()
    {
        var memoryCache = new Mock<IMemoryCache>();
        object value = "string";
        memoryCache.Setup(m => m.TryGetValue(It.IsAny<string>(), out value)).Throws(new Exception());
        var bucketParameters = new BucketParameters { BucketName = "bucketName" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache.Object, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        Assert.ThrowsAsync<CacheBucketOperationException>(() => memoryBucket.Get());
    }

    [Test]
    [Category("UnitTest")]
    public async Task Get_ObjectInCache_ShouldReturnObjectFromCache()
    {
        var key = "memoryStaticCacheKey";
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        memoryCache.Set(key, GetStrings());
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        var result = await memoryBucket.Get(() => GetStrings());

        Assert.AreEqual(result, GetStrings());
    }

    [Test]
    [Category("UnitTest")]
    public async Task GetObjectFromCache_ObjectNotInCache_ShouldReturnObjectFromFunc()
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        var result = await memoryBucket.Get(() => GetStrings());

        Assert.AreEqual(result, GetStrings());
    }

    [Test]
    [Category("UnitTest")]
    public async Task GetObjectFromCache_CacheFails_ReturnsFuncData()
    {
        var memoryCache = new Mock<IMemoryCache>();
        memoryCache.Setup(m => m.CreateEntry(It.IsAny<string>())).Throws(new Exception());
        var logger = new Mock<ILogger<InMemoryStaticBucket<string>>>();
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };

        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache.Object, logger.Object);

        var result = await memoryBucket.Get(() => GetStrings());

        Assert.AreEqual(result, GetStrings());
    }

    [Test]
    [Category("UnitTest")]
    public async Task GetObjectFromCache_ObjectInCache_ShouldReturnObjectFromCache_FuncAsync()
    {
        var key = "memoryStaticCacheKey";
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        memoryCache.Set(key, GetStrings());
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);

        var result = await memoryBucket.Get(() => GetStringsAsync());

        Assert.AreEqual(result, GetStrings());
    }

    [Test]
    [Category("UnitTest")]
    public async Task GetObjectFromCache_ObjectNotInCache_ShouldReturnObjectFromAsyncFunc()
    {
        var memoryCache = new MemoryCache(new MemoryCacheOptions());
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };
        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache, new Mock<ILogger<InMemoryStaticBucket<string>>>().Object);
        var result = await memoryBucket.Get(() => GetStringsAsync());
        Assert.AreEqual(result, GetStrings());
    }

    [Test]
    [Category("UnitTest")]
    public async Task GetObjectFromCache_CacheFails_ReturnsAsyncFuncData()
    {
        var memoryCache = new Mock<IMemoryCache>();
        memoryCache.Setup(m => m.CreateEntry(It.IsAny<string>())).Throws(new Exception());
        var logger = new Mock<ILogger<InMemoryStaticBucket<string>>>();
        var bucketParameters = new BucketParameters { BucketName = "memoryStaticCacheKey" };

        var memoryBucket = new InMemoryStaticBucket<string>(bucketParameters, memoryCache.Object, logger.Object);

        var result = await memoryBucket.Get(() => GetStringsAsync());

        Assert.AreEqual(result, GetStrings());
    }

    private IEnumerable<string> GetStrings()
    {
        return new List<string>() { "one", "two", "three" };
    }

    private Task<IEnumerable<string>> GetStringsAsync()
    {
        var strings = new List<string>() { "one", "two", "three" };
        return Task.FromResult(strings.AsEnumerable());
    }
}