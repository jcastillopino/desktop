using Microsoft.Extensions.Configuration;

namespace ServiceTracking.Utils.IO
{
    public static class ConfigLoader
    {
        public static T LoadJsonConfig<T>(string path, string configSection)
        {
            try
            {
                IConfiguration configuration = new ConfigurationBuilder()
                .AddJsonFile(path, optional: false, reloadOnChange: true)
                .Build();

                var x = configuration.GetSection(configSection);

                return configuration.GetSection(configSection).Get<T>(options =>
                {
                    options.BindNonPublicProperties = true;
                    options.ErrorOnUnknownConfiguration = true;
                });
            }
            catch (InvalidOperationException ex)
            {
                throw new IOException(
                    $"The file '{path}' is malformed and does not match the structure of type {typeof(T)}. " +
                    "Check that all field names are spelled correctly and that non-null fields have a value:\n\n",
                    ex);
            }
            catch (Exception ex)
            {
                throw new IOException(
                    $"An unexpected errror occurred when trying to load configuration from path '{path}'.",
                    ex);
            }
        }
    }
}
