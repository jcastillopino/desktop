using ServiceTracking.Utils.Cache.Configuration;
using ServiceTracking.Utils.Cache.Definitions;
using ServiceTracking.Utils.Cache.Exceptions;

namespace ServiceTracking.Utils.Cache;

public class CacheService : ICacheService
{
    private readonly IEnumerable<CacheBucket> _buckets;
    private readonly IServiceProvider _serviceProvider;

    public CacheService(IEnumerable<CacheBucket> buckets, IServiceProvider serviceProvider)
    {
        _buckets = buckets ?? throw new ArgumentNullException(nameof(buckets));
        _serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
    }

    public ICacheBucket<T> GetBucket<T>(string key)
    {
        var bucketDefinition = _buckets.SingleOrDefault(x => x.Key == key && x.BucketType == BucketTypes.Standard)
            ?? throw new CacheBucketNotFoundException(key);

        return CreateInstance<ICacheBucket<T>>(
            bucketDefinition.ContentType!, 
            bucketDefinition.BucketTechnologyType, 
            bucketDefinition.BucketParameters);
    }

    public ICacheStaticBucket<T> GetStaticBucket<T>(string key)
    {
        var bucketDefinition = _buckets.SingleOrDefault(x => x.Key == key && x.BucketType == BucketTypes.Static)
            ?? throw new CacheBucketNotFoundException(key);

        return CreateInstance<ICacheStaticBucket<T>>(
            bucketDefinition.ContentType!, 
            bucketDefinition.BucketTechnologyType, 
            bucketDefinition.BucketParameters);
    }

    private T CreateInstance<T>(Type bucketType, Type technologyType, BucketParameters bucketParameters)
        where T : class
    {
        var bucketImplementationType = technologyType;
        var constructed = bucketImplementationType!.GetGenericTypeDefinition()
            .MakeGenericType(bucketType);

        var constructor = constructed.GetConstructors().First();
        var constructorArgs = constructor.GetParameters()
            .Select(p => p.ParameterType == typeof(BucketParameters) ? 
                bucketParameters : _serviceProvider.GetService(p.ParameterType))
            .ToArray();

        T instance;
        try
        {
            instance = Activator.CreateInstance(constructed, constructorArgs) as T;
        }
        catch (Exception ex)
        {
            throw new BucketCreationException(constructed.FullName!, ex);
        }

        if (instance is null)
        {
            throw new BucketCreationException(constructed.FullName!);
        }

        return instance;
    }
}
