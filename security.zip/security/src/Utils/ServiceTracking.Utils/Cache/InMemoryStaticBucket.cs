using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using ServiceTracking.Utils.Cache.Configuration;
using ServiceTracking.Utils.Cache.Definitions;
using ServiceTracking.Utils.Cache.Exceptions;

namespace ServiceTracking.Utils.Cache;

public class InMemoryStaticBucket<T> : ICacheStaticBucket<T>
{
    private readonly string _bucketName;
    private readonly TimeSpan? _slidingExpiration;

    /// <summary>
    ///  In-Memory caching variable.
    /// </summary>
    private readonly IMemoryCache _memoryCache;

    /// <summary>
    /// Logger instance
    /// </summary>
    private readonly ILogger<InMemoryStaticBucket<T>> _logger;

    /// <summary>
    /// Initializes a new instance of <see cref="InMemoryStaticBucket{T}"/>
    /// </summary>
    /// <param name="memoryCache">MemoryCache is shared between buckets</param>
    public InMemoryStaticBucket(BucketParameters bucketParameters, IMemoryCache memoryCache, ILogger<InMemoryStaticBucket<T>> logger)
    {
        ArgumentNullException.ThrowIfNull(bucketParameters);
        _bucketName = bucketParameters.BucketName;
        _slidingExpiration = bucketParameters.SlidingExpiration;
        _memoryCache = memoryCache ?? throw new ArgumentNullException(nameof(memoryCache));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <inheritdoc />
    public string GetBucketName() => _bucketName;

    /// <inheritdoc />
    public Task Add(IEnumerable<T> objects)
    {
        try
        {
            var memoryCacheEntryOptions = new MemoryCacheEntryOptions
            {
                SlidingExpiration = this._slidingExpiration,
            };

            _memoryCache.Set(_bucketName, objects, memoryCacheEntryOptions);
            return Task.CompletedTask;
        }
        catch (Exception ex)
        {
            throw new CacheBucketOperationException(_bucketName, ex);
        }
    }

    /// <inheritdoc />
    public Task<IEnumerable<T>> Remove()
    {
        try
        {
            var outputCache = _memoryCache.Get<IEnumerable<T>>(_bucketName);

            if (outputCache != null)
            {
                _memoryCache.Remove(_bucketName);
            }

            return Task.FromResult(outputCache);
        }
        catch (Exception ex)
        {
            throw new CacheBucketOperationException(_bucketName, ex);
        }
    }

    /// <inheritdoc />
    public Task<IEnumerable<T>> Get()
    {
        try
        {
            return Task.FromResult(_memoryCache.Get<IEnumerable<T>>(_bucketName));
        }
        catch (Exception ex)
        {
            throw new CacheBucketOperationException(_bucketName, ex);
        }
    }

    /// <inheritdoc />
    public async Task<IEnumerable<T>> Get(Func<Task<IEnumerable<T>>> func)
    {
        if (func == null) throw new ArgumentNullException(nameof(func));

        IEnumerable<T> result = null;
        try
        {
            result = await Get();
            if (result == null)
            {
                result = await func();
                await Add(result);
            }

            return result;
        }
        catch (CacheBucketOperationException ex)
        {
            this._logger.LogError(ex, $"ErrorMessage:{ex.Message} | InnerExceptionMessage: {ex?.InnerException?.Message}");
        }

        return result ?? await func();
    }

    /// <inheritdoc />
    public async Task<IEnumerable<T>> Get(Func<IEnumerable<T>> func)
    {
        if (func == null) throw new ArgumentNullException(nameof(func));

        IEnumerable<T> result = null;
        try
        {
            result = await Get();
            if (result == null)
            {
                result = func();
                await Add(result);
            }

            return result;
        }
        catch (CacheBucketOperationException ex)
        {
            _logger.LogError(ex, $"ErrorMessage:{ex.Message} | InnerExceptionMessage: {ex?.InnerException?.Message}");
        }

        return result ?? func();
    }
}
