using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using ServiceTracking.Utils.Cache.Configuration;
using ServiceTracking.Utils.Cache.Definitions;
using ServiceTracking.Utils.Cache.Exceptions;

namespace ServiceTracking.Utils.Cache;

/// <summary>
/// Implementation of InMemory cache bucket.
/// </summary>
/// <typeparam name="T"></typeparam>
public class InMemoryBucket<T> : ICacheBucket<T>
{
    private readonly string _bucketName;
    private readonly TimeSpan? _slidingExpiration;

    /// <summary>
    ///  In-Memory caching variable.
    /// </summary>
    private readonly IMemoryCache _memoryCache;

    /// <summary>
    /// Logger Instance.
    /// </summary>
    private readonly ILogger<InMemoryBucket<T>> _logger;

    /// <summary>
    /// Initializes a new instance of <see cref="InMemoryBucket{T}"/>
    /// </summary>
    /// <param name="memoryCache">MemoryCache is shared between buckets</param>
    public InMemoryBucket(BucketParameters bucketParameters, IMemoryCache memoryCache, ILogger<InMemoryBucket<T>> logger)
    {
        ArgumentNullException.ThrowIfNull(bucketParameters);
        _bucketName = bucketParameters.BucketName;
        _slidingExpiration = bucketParameters.SlidingExpiration;
        _memoryCache = memoryCache ?? throw new ArgumentNullException(nameof(memoryCache));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <inheritdoc />
    public string GetBucketName() => _bucketName;

    /// <inheritdoc />
    public Task Add(string key, T value)
    {
        if (string.IsNullOrEmpty(key)) throw new ArgumentNullException(nameof(key));

        try
        {
            var generatedKey = GetSpecificKey(key);
            var memoryCacheEntryOptions = new MemoryCacheEntryOptions
            {
                SlidingExpiration = this._slidingExpiration,
            };

            _memoryCache.Set(generatedKey, value, memoryCacheEntryOptions);

            return Task.CompletedTask;
        }
        catch (Exception ex)
        {
            throw new CacheBucketOperationException(_bucketName, ex);
        }
    }

    /// <inheritdoc />
    public Task<T> Remove(string key)
    {
        if (string.IsNullOrEmpty(key)) throw new ArgumentNullException(nameof(key));

        try
        {
            var generatedKey = GetSpecificKey(key);

            var obj = _memoryCache.Get<T>(generatedKey);

            if (obj != null)
            {
                _memoryCache.Remove(generatedKey);
            }

            return Task.FromResult(obj);
        }
        catch (Exception ex)
        {
            throw new CacheBucketOperationException(_bucketName, ex);
        }
    }

    /// <inheritdoc />
    public Task<T> Get(string key)
    {
        if (string.IsNullOrEmpty(key)) throw new ArgumentNullException(nameof(key));

        try
        {
            var generatedKey = GetSpecificKey(key);
            return Task.FromResult(_memoryCache.Get<T>(generatedKey));
        }
        catch (Exception ex)
        {
            throw new CacheBucketOperationException(_bucketName, ex);
        }
    }

    /// <inheritdoc />
    public async Task<T> Get(string key, Func<T> func)
    {
        if (string.IsNullOrEmpty(key)) throw new ArgumentNullException(nameof(key));
        if (func == null) throw new ArgumentNullException(nameof(func));

        T result = default;
        try
        {
            result = await Get(key);
            if (result == null)
            {
                result = func();
                await Add(key, result);
            }

            return result;
        }
        catch (CacheBucketOperationException ex)
        {
            this._logger.LogError(ex, $"ErrorMessage:{ex.Message} | InnerExceptionMessage: {ex?.InnerException?.Message}");
        }

        return result ?? func();
    }

    /// <inheritdoc />
    public async Task<T> Get(string key, Func<Task<T>> func)
    {
        if (string.IsNullOrEmpty(key)) throw new ArgumentNullException(nameof(key));
        if (func == null) throw new ArgumentNullException(nameof(func));

        T result = default(T);
        try
        {
            result = await Get(key);
            if (result == null)
            {
                result = await func();
                await Add(key, result);
            }

            return result;
        }
        catch (CacheBucketOperationException ex)
        {
            this._logger.LogError(ex, $"ErrorMessage:{ex.Message} | InnerExceptionMessage: {ex?.InnerException?.Message}");
        }

        return result ?? await func();
    }

    private string GetSpecificKey(string key)
    {
        return string.Concat(_bucketName, key);
    }
}