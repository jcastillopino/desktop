namespace ServiceTracking.Utils.Cache.Definitions;

public interface IBaseCacheBucket
{
    /// <summary>
    /// Returns the name of the bucket.
    /// </summary>
    public string GetBucketName();
}