namespace ServiceTracking.Utils.Cache.Definitions;

public interface ICacheBucket<T> : IBaseCacheBucket
{

    public Task Add(string key, T value);

    /// <summary>
    /// Remove an object from a bucket.
    /// </summary>
    /// <param name="key">remove an object from the bucket by its identifier key.</param>
    /// <returns>Return the obtained object, null if does not exist in the bucket.</returns>
    /// <exception cref="ArgumentNullException">Key cannot be null or empty</exception>
    public Task<T> Remove(string key);

    /// <summary>
    /// Get an object from the bucket by its identifier.
    /// </summary>
    /// <param name="key">object identifier.</param>
    /// <returns>an object value from the bucket by its identifier.</returns>
    /// <exception cref="ArgumentNullException">Key cannot be null or empty</exception>
    public Task<T> Get(string key);

    /// <summary>
    /// Tries to get the data from the Cache, if not, gets the data from func, saves the data in the cache and returns the data.
    /// On cache error returns the func result
    /// </summary>
    /// <param name="key">object identifier.</param>
    /// <param name="func">The delegate function that is going to be called if the element cannot be found in the cache.</param>
    /// <returns>An object value from the bucket by its identifier.</returns>
    /// <exception cref="ArgumentNullException">Key cannot be null or empty</exception>
    /// <exception cref="ArgumentNullException">Func cannot be null</exception>
    public Task<T> Get(string key, Func<Task<T>> func);

    /// <summary>
    /// Tries to get the data from the Cache, if not, gets the data from func, saves the data in the cache and returns the data.
    /// On cache error returns the func result
    /// </summary>
    /// <param name="key">object identifier.</param>
    /// <param name="getDataFunc">The delegate function that is going to be called if the element cannot be found in the cache.</param>
    /// <returns>An object value from the bucket by its identifier.</returns>
    /// <exception cref="ArgumentNullException">Key cannot be null or empty</exception>
    /// <exception cref="ArgumentNullException">Func cannot be null</exception>
    public Task<T> Get(string key, Func<T> getDataFunc);
}
