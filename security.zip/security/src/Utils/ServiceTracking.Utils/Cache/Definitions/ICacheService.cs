namespace ServiceTracking.Utils.Cache.Definitions;

public interface ICacheService
{
    ICacheBucket<T> GetBucket<T>(string key);

    ICacheStaticBucket<T> GetStaticBucket<T>(string key);
}
