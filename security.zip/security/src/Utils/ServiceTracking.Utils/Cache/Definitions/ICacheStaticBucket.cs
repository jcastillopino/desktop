namespace ServiceTracking.Utils.Cache.Definitions;

public interface ICacheStaticBucket<T> : IBaseCacheBucket
{
    /// <summary>
    /// Add /Replace the list of objects to the bucket.
    /// </summary>
    /// <param name="objects">The list of objects.</param>
    public Task Add(IEnumerable<T> objects);

    public Task<IEnumerable<T>> Remove();

    /// <summary>
    /// Get the list of objects from the bucket
    /// </summary>
    /// <returns>list of objects from the bucket</returns>
    public Task<IEnumerable<T>> Get();

    /// <summary>
    /// Tries to get the data from the Cache, if not, gets the data from func, saves the data in the cache and returns the data.
    /// On cache error returns the func result
    /// </summary>
    /// <param name="func">The delegate function that is going to be called if the element cannot be found in the cache.</param>
    /// <returns>An object value from the bucket by its identifier.</returns>
    /// <exception cref="ArgumentNullException">Func cannot be null</exception>
    public Task<IEnumerable<T>> Get(Func<Task<IEnumerable<T>>> func);

    /// <summary>
    /// Tries to get the data from the Cache, if not, gets the data from func, saves the data in the cache and returns the data.
    /// On cache error returns the func result
    /// </summary>
    /// <param name="func">The delegate function that is going to be called if the element cannot be found in the cache.</param>
    /// <returns>An object value from the bucket by its identifier.</returns>
    /// <exception cref="ArgumentNullException">Func cannot be null</exception>
    public Task<IEnumerable<T>> Get(Func<IEnumerable<T>> func);
}
