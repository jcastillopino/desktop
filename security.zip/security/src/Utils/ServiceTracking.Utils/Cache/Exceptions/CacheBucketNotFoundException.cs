namespace ServiceTracking.Utils.Cache.Exceptions;

public class CacheBucketNotFoundException : Exception
{
    public CacheBucketNotFoundException(string bucketName)
        : base($"The requested bucket '{bucketName}' does not exist.")
    { }
}