namespace ServiceTracking.Utils.Cache.Exceptions;

public class CacheBucketOperationException : Exception
{
    public string BucketName { get; set; }

    public CacheBucketOperationException(string bucketName, Exception exception)
        : base($"An error occurred when accessing the cache on the bucket ‘{bucketName}.", exception)
    {
        BucketName = bucketName;
    }
}
