using ServiceTracking.Utils.Cache.Configuration;

namespace ServiceTracking.Utils.Cache.Exceptions;

public class InvalidBucketConstructorException : Exception
{
    public InvalidBucketConstructorException(Type bucketType)
        : base($"A constructor with a parameter of type {nameof(BucketParameters)} is required in the bucket type {bucketType.FullName}.")
    { }
}
