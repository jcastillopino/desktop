namespace ServiceTracking.Utils.Cache.Exceptions;

public class InvalidCacheTechnologyException : Exception
{
    public string BucketName { get; set; }

    public string Technology { get; set; }

    public InvalidCacheTechnologyException(string bucketName, string technology)
        : base($"Invalid technology '{technology}' configured for the bucket {bucketName}.")
    {
        BucketName = bucketName;
        Technology = technology;
    }
}
