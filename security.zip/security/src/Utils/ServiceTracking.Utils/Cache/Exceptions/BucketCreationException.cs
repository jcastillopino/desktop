namespace ServiceTracking.Utils.Cache.Exceptions;

public class BucketCreationException : Exception
{
    public BucketCreationException(string bucketTypeName)
        : base($"Could not create a bucket of type {bucketTypeName}")
    { }

    public BucketCreationException(string bucketTypeName, Exception innerException)
        : base($"Could not create a bucket of type {bucketTypeName}", innerException)
    { }
}
