namespace ServiceTracking.Utils.Cache.Exceptions;

public class InvalidBucketContentTypeException : Exception
{
    public string BucketName { get; set; }

    public string InvalidTypeName { get; set; }

    public InvalidBucketContentTypeException(string bucketName, string bucketContentType)
        : base($"The type '{bucketContentType}' could not be found while constructing the bucket {bucketName}")
    {
        BucketName = bucketName;
        InvalidTypeName = bucketContentType;
    }
}
