namespace ServiceTracking.Utils.Cache.Exceptions;

public class InvalidBucketTypeException : Exception
{
    public string BucketName { get; set; }

    public string InvalidTypeName { get; set; }

    public InvalidBucketTypeException(string bucketName, string bucketType)
        : base($"Invalid type '{bucketType}' configured for the bucket {bucketName}.")
    {
        BucketName = bucketName;
        InvalidTypeName = bucketType;
    }
}
