namespace ServiceTracking.Utils.Cache.Configuration;

public record CacheBucket(string Key,
    Type ContentType,
    Type BucketTechnologyType,
    BucketTypes BucketType,
    BucketParameters BucketParameters);
