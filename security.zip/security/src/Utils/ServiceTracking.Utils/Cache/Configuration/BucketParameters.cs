namespace ServiceTracking.Utils.Cache.Configuration;

public class BucketParameters : IEquatable<BucketParameters>
{
    public string BucketName { get; set; }

    public int? MaximumRecords { get; set; }

    public TimeSpan? SlidingExpiration { get; set; }

    public bool Equals(BucketParameters other)
    {
        return BucketName == other?.BucketName &&
             MaximumRecords == other?.MaximumRecords &&
             SlidingExpiration == other?.SlidingExpiration;
    }
}