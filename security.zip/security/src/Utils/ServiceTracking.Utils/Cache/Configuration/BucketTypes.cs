namespace ServiceTracking.Utils.Cache.Configuration;

public enum BucketTypes
{
    Standard,
    Static,
}
