using Microsoft.Extensions.DependencyInjection;
using ServiceTracking.Utils.Cache.Definitions;
using ServiceTracking.Utils.Cache.Exceptions;

namespace ServiceTracking.Utils.Cache.Configuration;

public static class ServiceCollectionExtensions
{
    private static readonly IDictionary<(BucketTypes, CacheTechnologies), Type> BucketTypes = new Dictionary<(BucketTypes, CacheTechnologies), Type>()
    {
        [(Configuration.BucketTypes.Standard, CacheTechnologies.InMemory)] = typeof(InMemoryBucket<>),
        [(Configuration.BucketTypes.Static, CacheTechnologies.InMemory)] = typeof(InMemoryStaticBucket<>),
    };

  
    public static IServiceCollection AddCacheSupport(
        this IServiceCollection services,
        CacheConfiguration cacheConfiguration)
    {
        var buckets = ValidateAndLoadBuckets(cacheConfiguration.Buckets);

        var cacheTechnologies = cacheConfiguration.Buckets.Select(b => b.CacheTechnology).Distinct().ToList();
        LoadTechnologiesDependencies(cacheTechnologies, services, cacheConfiguration);

        services.AddSingleton<ICacheService>(sp => new CacheService(buckets, sp));

        return services;
    }

    private static IEnumerable<CacheBucket> ValidateAndLoadBuckets(IEnumerable<CacheBucketConfiguration> bucketsConfiguration)
    {
        var buckets = new List<CacheBucket>();
        var configurationExceptions = new List<Exception>();

        foreach (var bucket in bucketsConfiguration)
        {
            var bucketConfigurationExceptions = TryLoadBucket(bucket, out var cacheBucket);

            IEnumerable<Exception> exceptions = bucketConfigurationExceptions.ToList();
            if (exceptions.Any())
            {
                configurationExceptions.AddRange(exceptions);
            }
            else
            {
                buckets.Add(cacheBucket);
            }
        }

        if (configurationExceptions.Any())
        {
            throw new AggregateException("Invalid cache configuration.", configurationExceptions);
        }

        return buckets;
    }

    private static IEnumerable<Exception> TryLoadBucket(CacheBucketConfiguration bucket, out CacheBucket cacheBucket)
    {
        var validBucket = true;
        cacheBucket = null;
        var configurationExceptions = new List<Exception>();

        var bucketContentType = LoadBucketContentType(bucket.BucketContentType);
        if (bucketContentType is null)
        {
            validBucket = false;
            configurationExceptions.Add(new InvalidBucketContentTypeException(bucket.Key, bucket.BucketContentType));
        }

        var validBucketType = Enum.TryParse<BucketTypes>(bucket.BucketType, out var bucketType);
        if (!validBucketType)
        {
            validBucket = false;
            configurationExceptions.Add(new InvalidBucketTypeException(bucket.Key, bucket.BucketType));
        }

        var bucketTechnologyType = LoadBucketTechnologyType(bucketType, bucket.CacheTechnology);
        if (bucketTechnologyType is null)
        {
            validBucket = false;
            configurationExceptions.Add(new InvalidCacheTechnologyException(bucket.Key, bucket.CacheTechnology));
        }
        else
        {
            var validBucketConstructor = ValidateBucketConstructor(bucketTechnologyType);
            if (!validBucketConstructor)
            {
                validBucket = false;
                configurationExceptions.Add(new InvalidBucketConstructorException(bucketTechnologyType));
            }
        }

        if (validBucket)
        {
            var bucketParameters = new BucketParameters
            {
                BucketName = $"{bucketType}-{bucket.Key}",
                MaximumRecords = bucket.MaximunRecords,
                SlidingExpiration = bucket.SlidingExpiration,
            };
            cacheBucket = new CacheBucket(bucket.Key, bucketContentType, bucketTechnologyType, bucketType, bucketParameters);
        }

        return configurationExceptions;
    }

    private static void LoadTechnologiesDependencies(
        IEnumerable<string> cacheTechnologies,
        IServiceCollection services, 
        CacheConfiguration cacheConfiguration)
    {
        foreach (var cacheTechnology in cacheTechnologies)
        {
            var technology = Enum.Parse<CacheTechnologies>(cacheTechnology);
            switch (technology)
            {
                case CacheTechnologies.InMemory:
                    services.AddMemoryCache();
                    break;
            }
        }
    }

    private static Type LoadBucketContentType(string bucketTypeName)
    {
        if (string.IsNullOrEmpty(bucketTypeName))
        {
            return null;
        }

        foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
        {
            var type = assembly.GetType(bucketTypeName);
            if (type != null)
            {
                return type;
            }
        }

        return null;
    }

    private static Type LoadBucketTechnologyType(BucketTypes bucketType, string cacheTechnology)
    {
        if (!Enum.TryParse<CacheTechnologies>(cacheTechnology, out var technology))
        {
            return null;
        }

        if (BucketTypes.TryGetValue((bucketType, technology), out var bucketTechnologyType))
        {
            return bucketTechnologyType;
        }

        return null;
    }

    private static bool ValidateBucketConstructor(Type bucketType)
    {
        return bucketType.GetConstructors().Any(c =>
            c.GetParameters().Any(p => p.ParameterType == typeof(BucketParameters)));
    }

}