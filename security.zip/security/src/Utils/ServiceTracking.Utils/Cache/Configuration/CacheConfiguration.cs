namespace ServiceTracking.Utils.Cache.Configuration;

public class CacheConfiguration
{
    public IList<CacheBucketConfiguration> Buckets { get; set; } = new List<CacheBucketConfiguration>();

    public string ConnectionString { get; set; }

    public string ClientCertificatePath { get; set; }

    public string CaCertificatePath { get; set; }
}