namespace ServiceTracking.Utils.Cache.Configuration;

public enum CacheTechnologies
{
    InMemory,
}
