namespace ServiceTracking.Utils.Cache.Configuration;

public class CacheBucketConfiguration
{
    public string Key { get; set; } = string.Empty;

    public string CacheTechnology { get; set; } = CacheTechnologies.InMemory.ToString();

    public int? MaximunRecords { get; set; }

    public TimeSpan? SlidingExpiration { get; set; }

    public string BucketContentType { get; set; } = string.Empty;

    public string BucketType { get; set; } = BucketTypes.Standard.ToString();
}
