using System.Data;

namespace ServiceTracking.Utils.Mapper
{
    public static class DataTypeMapper
    {
        public static Type GetClrTypeFromSqlType(SqlDbType sqlType)
        {
            return sqlType switch
            {
                SqlDbType.BigInt => typeof(long?),
                SqlDbType.Binary or SqlDbType.Image or SqlDbType.Timestamp or SqlDbType.VarBinary => typeof(byte[]),
                SqlDbType.Bit => typeof(bool?),
                SqlDbType.Char or SqlDbType.NChar or SqlDbType.NText or SqlDbType.NVarChar or SqlDbType.Text or SqlDbType.VarChar or SqlDbType.Xml => typeof(string),
                SqlDbType.DateTime or SqlDbType.SmallDateTime or SqlDbType.Date or SqlDbType.Time or SqlDbType.DateTime2 => typeof(DateTime?),
                SqlDbType.Decimal or SqlDbType.Money or SqlDbType.SmallMoney => typeof(decimal?),
                SqlDbType.Float => typeof(double?),
                SqlDbType.Int => typeof(int?),
                SqlDbType.Real => typeof(float?),
                SqlDbType.UniqueIdentifier => typeof(Guid?),
                SqlDbType.SmallInt => typeof(short?),
                SqlDbType.TinyInt => typeof(byte?),
                SqlDbType.Variant or SqlDbType.Udt => typeof(object),
                SqlDbType.Structured => typeof(DataTable),
                SqlDbType.DateTimeOffset => typeof(DateTimeOffset?),
                _ => throw new ArgumentOutOfRangeException(nameof(sqlType)),
            };
        }
    }
}
