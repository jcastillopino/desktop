using System.Reflection;

namespace ServiceTracking.Utils.Mapper;
public class ObjectMapper : IObjectMapper
{
    public static D Map<D>(object from) where D : new()
    {
        if (from == null) return default;

        var to = new D();
        var toProperties = to.GetType().GetProperties();

        foreach (var prop in from.GetType().GetProperties())
        {
            if (IsBaseTypeProperty(prop) && HasProperty(toProperties, prop))
            {
                var toProperty = to.GetType().GetProperty(prop.Name);
                var value = ResolveValue(prop, from);

                CopyProperty(prop, toProperty, to, value);
            }
        }

        return to;
    }

    private static void CopyProperty<D>(
        PropertyInfo fromProperty,
        PropertyInfo toProperty,
        D destination,
        object value
        ) where D : new()
    {
        if (toProperty != null)
        {
            if (IsDateTypeProperty(fromProperty) && IsStringProperty(toProperty))
            {
                toProperty.SetValue(destination, value.ToString(), null);
            }
            else if (IsDateTypeProperty(toProperty) && IsStringProperty(fromProperty))
            {
                toProperty.SetValue(destination, Convert.ToDateTime(value), null);
            }
            else
            {
                toProperty.SetValue(destination, value, null);
            }
        }
    }

    private static object ResolveValue(
        PropertyInfo propertyFrom,
        object from)
    {
        var value = propertyFrom.GetValue(from);
        return value;
    }

    private static bool IsBaseTypeProperty(PropertyInfo property)
    {
        if (property.PropertyType == typeof(string) ||
           property.PropertyType == typeof(float) ||
           property.PropertyType == typeof(float?) ||
           property.PropertyType == typeof(decimal) ||
           property.PropertyType == typeof(decimal?) ||
           property.PropertyType == typeof(double) ||
           property.PropertyType == typeof(double?) ||
           property.PropertyType == typeof(int) ||
           property.PropertyType == typeof(int?) ||
           property.PropertyType == typeof(bool) ||
           property.PropertyType == typeof(bool?) ||
           property.PropertyType.IsEnum ||
           property.PropertyType == typeof(DateTime) ||
           property.PropertyType == typeof(DateTime?))
            return true;

        return false;
    }

    private static bool IsDateTypeProperty(PropertyInfo property)
    {
        if (property.PropertyType == typeof(DateTime) || property.PropertyType == typeof(DateTime?))
            return true;

        return false;
    }

    private static bool IsStringProperty(PropertyInfo property)
    {
        if (property.PropertyType == typeof(string) || property.PropertyType == typeof(string))
            return true;

        return false;
    }

    private static bool HasProperty(
        PropertyInfo[] toProperties,
        PropertyInfo property)
    {
        foreach (var prop in toProperties)
        {
            if (prop.Name == property.Name &&
                (prop.PropertyType == property.PropertyType ||
                 prop.PropertyType == typeof(int?) && property.PropertyType == typeof(int) ||
                 prop.PropertyType == typeof(DateTime) && property.PropertyType == typeof(string) ||
                 prop.PropertyType == typeof(DateTime?) && property.PropertyType == typeof(string) ||
                 prop.PropertyType == typeof(string) && property.PropertyType == typeof(DateTime) ||
                 prop.PropertyType == typeof(string) && property.PropertyType == typeof(DateTime?)))
            {
                return true;
            }
        }

        return false;
    }
}