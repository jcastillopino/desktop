namespace ServiceTracking.Utils.Mapper
{
    public interface IObjectMapper
    {
    }
}