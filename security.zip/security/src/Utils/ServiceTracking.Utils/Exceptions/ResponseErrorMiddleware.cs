using System.Net;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceTracking.Utils.Helpers;
using ServiceTracking.Utils.Validation;

namespace ServiceTracking.Utils.Exceptions;

public class ResponseErrorMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger _logger;
    private readonly IWebHostEnvironment _environment;
    private readonly IGuidHelper _guidHelper;

    public ResponseErrorMiddleware(
        RequestDelegate next,
        IWebHostEnvironment environment,
        ILoggerFactory loggerFactory,
        IGuidHelper guidHelper)
    {
        _guidHelper = guidHelper;
        _next = next;
        _logger = loggerFactory.CreateLogger<ResponseErrorMiddleware>();
        _environment = environment;
    }

    public static HttpStatusCode BuildErrorCode(Exception exception) => exception switch
    {
        UnauthorizedAccessException => HttpStatusCode.Unauthorized,
        CustomException => HttpStatusCode.InternalServerError,
        BadHttpRequestException => HttpStatusCode.BadRequest,
        ValidationException => HttpStatusCode.BadRequest,
        ConflictException => HttpStatusCode.Conflict,
        EntityNotFoundException => HttpStatusCode.NotFound,
        _ => HttpStatusCode.InternalServerError
    };

    public async Task Invoke(HttpContext context)
    {
        try
        {
            await _next.Invoke(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, ex.Message);

            if (!context.Response.HasStarted)
            {
                context.Response.ContentType = "application/json";
                context.Response.StatusCode = (int)BuildErrorCode(ex);
                var response = BuildErrorResponse(ex);
                await context.Response.WriteAsync(response);
            }
        }
    }

    public string BuildErrorResponse(Exception exception)
    {
        if (exception is CustomExceptionJson customException)
        {
            return customException.CustomReturnValue;
        }

        var response = BuildApiErrorResponse(exception);
        return JsonConvert.SerializeObject(response);
    }

    public ProblemDetails BuildApiErrorResponse(Exception exception)
    {
        var problemDetails = new ProblemDetails();

        string correlationText = "Correlation";
        Guid guid = _guidHelper.CreateNew();

        switch (exception)
        {
            case UnauthorizedAccessException:
                problemDetails.Extensions.Add(correlationText, guid);
                problemDetails.Title = "Unauthorized";
                problemDetails.Detail = "Unauthorized";
                problemDetails.Status = (int)HttpStatusCode.Unauthorized;
                break;
            case CustomException customException:
                Guid correlation = customException.Correlation ?? _guidHelper.CreateNew();
                problemDetails.Extensions.Add(correlationText, correlation);
                problemDetails.Title = "Internal Server Error";
                problemDetails.Detail = customException.Message;
                problemDetails.Status = (int)HttpStatusCode.InternalServerError;
                break;
            case BadHttpRequestException:
                problemDetails.Extensions.Add(correlationText, guid);
                problemDetails.Title = "Bad Request";
                problemDetails.Detail = exception.Message;
                problemDetails.Status = (int)HttpStatusCode.BadRequest;
                break;
            case ValidationException validationException:
                problemDetails.Extensions.Add(correlationText, guid);
                problemDetails.Title = "Validation Failed";
                problemDetails.Detail = BuildValidationMessage(validationException);
                problemDetails.Status = (int)HttpStatusCode.BadRequest;
                break;
            case ConflictException conflictException:
                problemDetails.Extensions.Add(correlationText, guid);
                problemDetails.Title = "There has been a conflict";
                problemDetails.Detail = $"The entity {conflictException.Name } already exists.";
                problemDetails.Status = (int)HttpStatusCode.Conflict;
                break;
            case EntityNotFoundException foundException:
                problemDetails.Extensions.Add(correlationText, guid);
                problemDetails.Title = "The entity was not found";
                problemDetails.Detail = $"The entity with Id {foundException.Id} does not exist.";
                problemDetails.Status = (int)HttpStatusCode.NotFound;
                break;
            default:
                {
                    problemDetails.Extensions.Add(correlationText, guid);
                    problemDetails.Title = "Internal Server Error";
                    problemDetails.Detail = "An unhandled error has occurred.";
                    problemDetails.Status = (int)HttpStatusCode.InternalServerError;
                    break;
                }
        }

        if (_environment.IsDevelopment())
            problemDetails.Extensions.Add("Exception", exception);

        return problemDetails;
    }

    private string BuildValidationMessage(ValidationException exception)
    {
        var builder = new StringBuilder("");

        foreach (var error in exception.ValidationResult)
        {
            builder.AppendLine(error.Message);
        }

        return builder.ToString();
    }
}