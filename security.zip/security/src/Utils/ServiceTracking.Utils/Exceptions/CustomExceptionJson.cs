namespace ServiceTracking.Utils.Exceptions;

public class CustomExceptionJson : Exception
{
    public string CustomReturnValue { get; }

    public CustomExceptionJson(string message, string returnValue)
        : base(message)
    {
        CustomReturnValue = returnValue;
    }

    public CustomExceptionJson(string message, Exception inner, string returnValue)
        : base(message, inner)
    {
        CustomReturnValue = returnValue;
    }
}
