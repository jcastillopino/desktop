using System.Net;

namespace ServiceTracking.Utils.Exceptions;

public class CustomException : Exception
{
    public Guid? Correlation { get; set; }

    public HttpStatusCode StatusCode { get; set; }

    public CustomException(string message, Guid? correlation = null)
        : base(message)
    {
        Correlation = correlation;
    }

    public CustomException(string message, Exception inner, HttpStatusCode statusCode, Guid? correlation = null)
        : base(message, inner)
    {
        Correlation = correlation;
        StatusCode = statusCode;
    }
}
