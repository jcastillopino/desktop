namespace ServiceTracking.Utils.Exceptions;

public class ConflictException : Exception
{
    public string Name { get; set; }

    public ConflictException(string name)
        : base("Entity already exists")
    {
        Name = name;
    }

    public ConflictException(string message, Exception inner, string name)
        : base(message, inner)
    {
        Name = name;
    }
}
