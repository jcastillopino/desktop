namespace ServiceTracking.Utils.Exceptions;

public class EntityNotFoundException : Exception
{
    public string Id { get; set; }

    public EntityNotFoundException(string id)
        : base("Entity was not found")
    {
        Id = id;
    }

    public EntityNotFoundException(string message, Exception inner, string id)
        : base(message, inner)
    {
        Id = id;
    }
}
