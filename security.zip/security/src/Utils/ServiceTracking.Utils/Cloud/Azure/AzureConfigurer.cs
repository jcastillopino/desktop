using Azure.Identity;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ServiceTracking.Utils.Cloud.Azure;

public class AzureConfigurer : ICloudConfigurer
{
    public void Configure(WebApplicationBuilder builder)
    {
        builder.Configuration.AddAzureKeyVault(
                        new Uri($"https://{builder.Configuration["KeyVaultName"]}.vault.azure.net/"),
                        new DefaultAzureCredential());

        builder.Services.AddApplicationInsightsTelemetry();
    }
}
