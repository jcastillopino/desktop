using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Specialized;
using Azure.Storage.Sas;

namespace ServiceTracking.Utils.Azure.Storage;

public class StorageHelper
{
    public static Uri GetServiceSasUriForBlob(string folder, string file, TimeSpan duration, string connectionString)
    {
        var container = new BlobContainerClient(connectionString, folder);
        var blobClient = container.GetBlobClient(file);

        if (blobClient.CanGenerateSasUri)
        {
            var sasBuilder = new BlobSasBuilder()
            {
                BlobContainerName = blobClient.GetParentBlobContainerClient().Name,
                BlobName = blobClient.Name,
                Resource = "b"
            };

            sasBuilder.ExpiresOn = DateTimeOffset.UtcNow.Add(duration);
            sasBuilder.SetPermissions(BlobSasPermissions.Read);

            var sasUri = blobClient.GenerateSasUri(sasBuilder);

            return sasUri;
        }
        else
        {
            return null;
        }
    }
}
