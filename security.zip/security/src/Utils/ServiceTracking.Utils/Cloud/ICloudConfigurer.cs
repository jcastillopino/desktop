using Microsoft.AspNetCore.Builder;

namespace ServiceTracking.Utils.Cloud;

public interface ICloudConfigurer
{
    void Configure(WebApplicationBuilder builder);
}