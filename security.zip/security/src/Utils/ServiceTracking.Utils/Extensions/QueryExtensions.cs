using System.Linq.Expressions;

namespace ServiceTracking.Utils.Extensions;

public static class QueryExtensions
{
    public static IEnumerable<T> WhereIf<T>(
        this IEnumerable<T> source,
        bool condition,
        Func<T, bool> predicate)
    {
        if (condition)
            return source.Where(predicate);

        return source;
    }

    public static IQueryable<T> WhereIf<T>(
        this IQueryable<T> source,
        bool condition,
        Expression<Func<T, bool>> predicate)
    {
        if (condition)
            return source.Where(predicate);

        return source;
    }

    public static object OrDBNull(this string value)
    {
        return string.IsNullOrEmpty(value) ? DBNull.Value : (object)value;
    }
}