namespace ServiceTracking.Utils.Extensions
{
    public static class DateTimeExtensions
    {
        public static int ToUnixTimestamp(this DateTime timestamp)
        {
            return (int)timestamp.Subtract(DateTime.UnixEpoch).TotalSeconds;
        }
    }
}
