// ReSharper disable BuiltInTypeReferenceStyle

namespace ServiceTracking.Utils.Extensions;

public static class TypeExtensions
{
    public static bool IsPrimitive(this Type type)
    {
#pragma warning disable SA1121 // Use built-in type alias
        return type == typeof(String) ||
                type == typeof(Decimal) ||
                type == typeof(Int16) ||
                type == typeof(Int32) ||
                type == typeof(Int64) ||
                type == typeof(Boolean);
#pragma warning restore SA1121 // Use built-in type alias
    }

    public static bool IsNumeric(this Type type)
    {
        var baseType = type;
        var notNullableType = Nullable.GetUnderlyingType(type);

        if (notNullableType != null)
            baseType = notNullableType;

        switch (Type.GetTypeCode(baseType))
        {
            case TypeCode.UInt16:
            case TypeCode.UInt32:
            case TypeCode.UInt64:
            case TypeCode.Int16:
            case TypeCode.Int32:
            case TypeCode.Int64:
            case TypeCode.Decimal:
            case TypeCode.Single:
            case TypeCode.Double:
                return true;
        }

        return false;
    }

    public static bool IsBoolean(this Type type)
    {
        var baseType = type;
        var notNullableType = Nullable.GetUnderlyingType(type);

        if (notNullableType != null)
            baseType = notNullableType;

        switch (Type.GetTypeCode(baseType))
        {
            case TypeCode.Boolean:
                return true;
        }

        return false;
    }

    public static bool IsString(this Type type)
    {
        return type == typeof(string) ||
                type == typeof(string);
    }

    public static bool IsDateTime(this Type type)
    {
        return type == typeof(DateTime) ||
                type == typeof(DateTime?);
    }
}