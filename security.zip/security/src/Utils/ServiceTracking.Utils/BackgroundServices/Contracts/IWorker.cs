namespace ServiceTracking.Utils.BackgroundServices.Contracts;

public interface IWorker
{
    Task DoWorkAsync(CancellationToken cancellationToken);

    Task StopWorkAsync(CancellationToken cancellationToken)
    {
        if (!cancellationToken.IsCancellationRequested)
        {
            return Task.CompletedTask;
        }

        return Task.FromCanceled(cancellationToken);
    }
}
