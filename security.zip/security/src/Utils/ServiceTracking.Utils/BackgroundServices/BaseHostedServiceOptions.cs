using ServiceTracking.Utils.BackgroundServices.Contracts;

namespace ServiceTracking.Utils.BackgroundServices;

public class BaseHostedServiceOptions<TWorker> where TWorker : class, IWorker
{
    public TimeSpan Delay { get; set; }

    public bool StopOnException { get; set; }
}
