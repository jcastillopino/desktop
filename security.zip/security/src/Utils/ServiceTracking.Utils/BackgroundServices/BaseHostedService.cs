using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ServiceTracking.Utils.BackgroundServices.Contracts;

namespace ServiceTracking.Utils.BackgroundServices;

public class BaseHostedService<TWorker> : IHostedService
    where TWorker : class, IWorker
{
    private readonly BaseHostedServiceOptions<TWorker> _options;
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<BaseHostedService<TWorker>> _logger;
    private TWorker _worker;
    // ReSharper disable once NotAccessedField.Local
    private Timer _timer;

    public BaseHostedService(
        IOptions<BaseHostedServiceOptions<TWorker>> options, 
        ILogger<BaseHostedService<TWorker>> logger, 
        IServiceProvider serviceProvider)
    {
        _options = options.Value;
        _serviceProvider = serviceProvider;
        _logger = logger;

    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _timer = new Timer(DoWork, cancellationToken, TimeSpan.Zero, TimeSpan.FromSeconds(_options.Delay.TotalSeconds));
        return Task.CompletedTask;
    }

    private void DoWork(object state)
    {
        var workerName = typeof(TWorker).Name;

        try
        {
            _worker = _serviceProvider.GetRequiredService<TWorker>();
            _logger.LogInformation($"Worker {workerName} has started execution.");
            _worker.DoWorkAsync((CancellationToken)state).Wait();
            _logger.LogInformation($"Worker {workerName} has finished execution.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Something happened on worker {workerName}: {ex.Message}", workerName, ex.Message);
            if (_options.StopOnException)
            {
                throw;
            }
        }
        finally
        {
            if (_worker is IDisposable disposableWorker)
            {
                disposableWorker.Dispose();
            }
        }
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        _worker?.StopWorkAsync(cancellationToken).Wait(cancellationToken);

        if (_worker is IDisposable disposableWorker)
        {
            disposableWorker.Dispose();
        }

        return Task.CompletedTask;
    }
}
