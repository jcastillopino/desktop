using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ServiceTracking.Utils.Authorization
{
    public class SanitizeAttribute : TypeFilterAttribute
    {
        public SanitizeAttribute() : base(typeof(SanitizerActionAttribute))
        {
            Arguments = new object[] {};
        }

        private class SanitizerActionAttribute : ActionFilterAttribute
        {
            public override void OnActionExecuting(ActionExecutingContext context)
            {

                var arguments = new List<KeyValuePair<string, object>>();

                foreach (var element in context.ActionArguments)
                {
                    arguments.Add(element);
                }

                foreach (var element in arguments)
                {
                    var sanitized = element.Value.Sanitize();

                    if (sanitized != null)
                    {
                        context.ActionArguments.Remove(element);
                        context.ActionArguments.Add(new KeyValuePair<string, object>(element.Key, sanitized));
                    }
                }

                base.OnActionExecuting(context);
            }
        }
    }
}
