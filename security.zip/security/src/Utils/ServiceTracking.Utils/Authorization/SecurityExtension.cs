using Microsoft.AspNetCore.Builder;

namespace ServiceTracking.Utils.Authorization;
public static class SecurityExtension
{
    public static IApplicationBuilder UseSecurityHeaders(
      this IApplicationBuilder app, SecurityConfiguration configuration)
    {
        return app.UseMiddleware<SecurityHeadersMiddleware>(configuration);
    }
}