namespace ServiceTracking.Utils.Authorization;

public class SecurityConfiguration
{
    public string FrontendUrl { get; set; }
}
