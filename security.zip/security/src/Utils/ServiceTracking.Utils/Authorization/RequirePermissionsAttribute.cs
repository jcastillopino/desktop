using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Net;

namespace ServiceTracking.Utils.Authorization
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
    // ReSharper disable once UnusedMember.Global
    public class RequirePermissionsAttribute : Attribute, IAuthorizationFilter
    {
        private readonly string[] _requiredPermissions;

        public RequirePermissionsAttribute(params string[] requiredPermissions)
        {
            _requiredPermissions = requiredPermissions;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var config = context.HttpContext.RequestServices.GetService<IConfiguration>();
            var authorizationEnabled = config.GetValue<bool>("Authorization:UseAuthorization");

            if (!authorizationEnabled)
            {
                return;
            }

            var user = context.HttpContext.User;

            if (user.Identity is { IsAuthenticated: false })
            {
                context.Result = new StatusCodeResult((int)HttpStatusCode.Unauthorized);
                return;
            }

            var userPermissions = user.FindFirst("permissions");
            if (userPermissions is null)
            {
                context.Result = new StatusCodeResult((int)HttpStatusCode.Forbidden);
                return;
            }

            foreach (var permission in _requiredPermissions)
            {
                if (!HasPermission(userPermissions.Value, permission))
                {
                    context.Result = new StatusCodeResult((int)HttpStatusCode.Forbidden);
                    return;
                }
            }
        }

        private bool HasPermission(string permissionList, string permission)
        {
            ReadOnlySpan<char> sp = permissionList;
            int start = 0;

            while (start < sp.Length)
            {
                int length = sp[start..].IndexOf(' ');
                length = length < 0 ? sp.Length - start : length;

                if (sp.Slice(start, length).Equals(permission.AsSpan(), StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                start += length + 1;
            }

            return false;
        }
    }
}
