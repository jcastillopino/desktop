﻿namespace ServiceTracking.Utils.Authorization;
public class EncryptionService : IEncryptionService
{
    public string Encrypt(string password)
    {
        return BCrypt.Net.BCrypt.HashPassword(password);
    }

    public bool Verify(string stringPassword, string hashPassword)
    {
        return BCrypt.Net.BCrypt.Verify(stringPassword, hashPassword);
    }
}
