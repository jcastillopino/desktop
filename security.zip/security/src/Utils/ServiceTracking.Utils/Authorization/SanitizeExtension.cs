using System.Collections;
using System.Reflection;
using System.Text.Encodings.Web;

namespace ServiceTracking.Utils.Authorization
{
    public static class SanitizeExtension
    {
        public static T Sanitize<T>(this T entity)
        {
            var sanitized = (object)entity;

            if (sanitized is string)
            {
                sanitized = HtmlEncoder.Default.Encode(sanitized.ToString() ?? string.Empty)
                    .Replace("&#xA;", "\n");
            }
            else if (sanitized is IEnumerable value)
            {
                foreach (var item in value)
                {
                    item.Sanitize();
                }
            }
            else
            {
                var properties = sanitized.GetType().GetProperties();
                foreach (var prop in properties)
                {
                    if (ShouldSanitize(prop))
                        SanitizeString(sanitized, prop);
                    else if (IsList(prop))
                        SanitizeEnumerable(sanitized, prop);
                    else if (IsObject(prop))
                        SanitizeObject(sanitized, prop);
                }
            }

            return (T)sanitized;
        }

        private static void SanitizeObject<T>(T entity, PropertyInfo prop)
        {
            var value = prop.GetValue(entity);
            if (value != null)
            {
                value.Sanitize();
            }
        }

        private static void SanitizeEnumerable<T>(T entity, PropertyInfo prop)
        {
            var value = (IEnumerable)prop.GetValue(entity);
            if (value != null)
            {
                foreach (var item in value)
                {
                    item.Sanitize();
                }
            }
        }

        private static void SanitizeString<T>(T entity, PropertyInfo prop)
        {
            var value = (string)prop.GetValue(entity);
            if (value != null)
            {
                value = HtmlEncoder.Default.Encode(value);
                value = value.Replace("&#xA;", "\n");
                prop.SetValue(entity, value, null);
            }
        }

        private static bool ShouldSanitize(PropertyInfo property)
        {
            if (property.PropertyType == typeof(string))
                return true;

            return false;
        }

        private static bool IsObject(PropertyInfo property)
        {
            if (property.PropertyType == typeof(object))
                return true;

            return false;
        }

        private static bool IsList(PropertyInfo property)
        {
            if (property.PropertyType == typeof(IEnumerable) ||
                typeof(IEnumerable).IsAssignableFrom(property.PropertyType))
                return true;

            return false;
        }
    }
}
