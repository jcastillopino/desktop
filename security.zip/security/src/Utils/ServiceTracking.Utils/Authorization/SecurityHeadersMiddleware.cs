using Microsoft.AspNetCore.Http;

namespace ServiceTracking.Utils.Authorization;

public class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;
    private readonly SecurityConfiguration _configuration;


    public SecurityHeadersMiddleware(
        RequestDelegate next,
        SecurityConfiguration configuration)
    {
        _configuration = configuration;
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        context.Response.GetTypedHeaders().CacheControl =
       new Microsoft.Net.Http.Headers.CacheControlHeaderValue()
       {
           MustRevalidate = true,
           NoCache = true,
           NoStore = true,
       };

        context.Response.Headers.Add("X-Content-Type-Options", "nosniff");

        if (!string.IsNullOrEmpty(_configuration?.FrontendUrl))
            context.Response.Headers.Add("Content-Security-Policy",
                $"default-src 'self' {_configuration.FrontendUrl} 'unsafe-inline' 'unsafe-eval'; " +
                $"script-src 'unsafe-inline' 'unsafe-eval' {_configuration.FrontendUrl}; " +
                "connect-src 'self'; " +
                $"img-src 'self' {_configuration.FrontendUrl}; " +
                $"style-src 'self' {_configuration.FrontendUrl}; " +
                "base-uri 'self'; " +
                "form-action 'self'; " +
                "frame-ancestors 'none';");

        context.Response.Headers.Add("Referrer-Policy", "same-origin");
        context.Response.Headers.Add("Permissions-Policy", "geolocation=(), microphone=()");
        context.Response.Headers.Add("X-XSS-Protection", "1; mode=block");
        context.Response.Headers.Add("X-Frame-Options", "SAMEORIGIN");
        context.Response.Headers.Add("SameSite", "Strict");

        await _next.Invoke(context);
    }
}