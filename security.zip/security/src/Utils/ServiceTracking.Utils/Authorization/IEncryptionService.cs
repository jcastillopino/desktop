﻿namespace ServiceTracking.Utils.Authorization;
public interface IEncryptionService
{
    public string Encrypt(string password);

    public bool Verify(string stringPassword, string hashPassword);
}
