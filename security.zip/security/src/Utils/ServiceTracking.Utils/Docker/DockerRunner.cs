﻿namespace ServiceTracking.Utils.Docker;

using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Threading;

public class DockerRunner
{
    public async Task<DockerCommandResult> ComposeBuild(string workingDir, string dbType, CancellationToken cancellationToken)
    {
        var commandResult = new DockerCommandResult();

        string command = "";

        if (dbType != null)
            command = $"docker-compose -f docker-compose.yml -f docker-compose.Infra.yml -f docker-compose.{dbType}.yml -f docker-compose-e2e.{dbType}.yml --env-file {dbType}.env build";
        else
            command = $"docker-compose -f docker-compose.yml -f docker-compose.Infra.yml build";

        var process = BuildCmdProcess(workingDir, command);

        process.OutputDataReceived += (s, e) =>
        {
            ExecuteErrorCheck(e, commandResult, "DockerComposeBuild");
        };

        process.ErrorDataReceived += (s, e) =>
        {
            ExecuteErrorCheck(e, commandResult, "DockerComposeBuild");
        };

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        await process.WaitForExitAsync(cancellationToken);

        return commandResult;
    }

    public async Task<DockerCommandResult> ComposeDown(string workingDir, string dbType, CancellationToken cancellationToken)
    {
        var commandResult = new DockerCommandResult();
        string command = "";

        if(dbType != null)
            command = $"docker-compose -f docker-compose.yml -f docker-compose.Infra.yml -f docker-compose.{dbType}.yml -f docker-compose-e2e.{dbType}.yml --env-file {dbType}.env down";
        else
            command = $"docker-compose -f docker-compose.yml -f docker-compose.Infra.yml down";

        var process = BuildCmdProcess(workingDir, command);

        process.OutputDataReceived += (s, e) =>
        {
            ExecuteErrorCheck(e, commandResult, "DockerComposeDown");
        };

        process.ErrorDataReceived += (s, e) =>
        {
            ExecuteErrorCheck(e, commandResult, "DockerComposeDown");
        };

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        await process.WaitForExitAsync(cancellationToken);

        return commandResult;
    }

    public async Task<DockerCommandResult> RemoveVolume(string workingDir, string volume, CancellationToken cancellationToken)
    {
        var commandResult = new DockerCommandResult();

        var process = BuildCmdProcess(workingDir, $"docker volume rm {volume}");

        process.OutputDataReceived += (s, e) =>
        {
            ExecuteErrorCheck(e, commandResult, "RemoveVolume");
        };

        process.ErrorDataReceived += (s, e) =>
        {
            ExecuteErrorCheck(e, commandResult, "RemoveVolume");
        };

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        await process.WaitForExitAsync(cancellationToken);

        return commandResult;
    }

    public async Task<DockerCommandResult> ComposeUp(IList<DockerService> servicesConfig, string workingDir, string dbType, CancellationToken cancellationToken)
    {
        var commandResult = new DockerCommandResult();
        string command = "";

        if (dbType != null)
            command = $"docker-compose -f docker-compose.yml -f docker-compose.Infra.yml -f docker-compose.{dbType}.yml -f docker-compose-e2e.{dbType}.yml --env-file {dbType}.env up";
        else
            command = $"docker-compose -f docker-compose.yml -f docker-compose.Infra.yml up";

        var process = BuildCmdProcess(workingDir, command);
        process.OutputDataReceived += (s, e) =>
        {
            ExecuteOutputCheck(servicesConfig, e, commandResult, "DockerComposeUp");
        };

        process.ErrorDataReceived += (s, e) =>
        {
            ExecuteOutputCheck(servicesConfig, e, commandResult, "DockerComposeUp");
        };

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();

        while (!commandResult.HasFinished)
        {
            if (commandResult.HasError || cancellationToken.IsCancellationRequested)
            {
                process.Kill();
                return commandResult;
            }

            await Task.Delay(1000);
        }

        process.Kill();
        return commandResult;
    }



    private Process BuildCmdProcess(string workingDir, string command)
    {
        Process process = new();
        process.StartInfo.WorkingDirectory = workingDir;
        process.StartInfo.FileName = "cmd.exe";
        process.StartInfo.Arguments = "/c " + command;
        process.StartInfo.UseShellExecute = false;
        process.StartInfo.RedirectStandardOutput = true;
        process.StartInfo.RedirectStandardError = true;

        return process;
    }

    private void ExecuteOutputCheck(IList<DockerService> servicesConfig, DataReceivedEventArgs data, DockerCommandResult result, string path)
    {
        if (data != null && data.Data != null)
        {
            var line = CleanConsoleData(data.Data);
            Debug.WriteLine("-> " + path + " " + line);

            var trimmedLined = line.Replace(" ", "");
            if (trimmedLined.Replace(" ", "").Contains("ERROR:"))
            {
                result.HasError = true;
            }

            foreach (var service in servicesConfig)
            {
                if (trimmedLined.Contains(service.DockerServiceName) && trimmedLined.Contains("Nowlisteningon"))
                {
                    service.IsRunning = true;
                }

                if (AreAllServicesRunning(servicesConfig))
                {
                    result.HasFinished = true;
                }
            }
        }
    }

    private bool AreAllServicesRunning(IList<DockerService> servicesConfig)
    {
        return servicesConfig.Count(x => !x.IsRunning) == 0;
    }

    private void ExecuteErrorCheck(DataReceivedEventArgs data, DockerCommandResult result, string path)
    {
        if (data != null && data.Data != null)
        {
            var line = CleanConsoleData(data.Data);
            Debug.WriteLine("-> " + path + " " + line);

            var trimmedLined = line.Replace(" ", "");
            if (trimmedLined.Replace(" ", "").Contains("ERROR:"))
            {
                result.HasError = true;
            }
        }
    }

    private string CleanConsoleData(string line)
    {
        string pattern = "(.\\[.{1,5}m)";
        var rgx = new Regex(pattern, RegexOptions.Multiline);
        return rgx.Replace(line, "");
    }
}