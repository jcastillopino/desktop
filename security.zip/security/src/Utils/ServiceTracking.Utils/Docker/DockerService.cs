﻿namespace ServiceTracking.Utils.Docker;

public class DockerService
{
    /// <summary>
    /// API execution URL of the service
    /// </summary>
    public string URL { get; set; }

    /// <summary>
    /// Main name of the container in docker
    /// </summary>
    public string DockerServiceName { get; set; }

    /// <summary>
    /// Unique Identifier for selecting the service in the config file. Used in healthcheck tests
    /// </summary>
    public string Tag { get; set; }

    /// <summary>
    /// Main Namespace of the service, used in the healthcheck tests
    /// </summary>
    public string Namespace { get; set; }

    public string Database { get; set; }

    public string Password { get; set; }

    public string Server { get; set; }

    public string User { get; set; }

    public bool IsRunning { get; set; }
}