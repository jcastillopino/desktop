﻿namespace ServiceTracking.Utils.Docker;

public class DockerCommandResult
{
    public bool HasFinished { get; set; }

    public bool HasError { get; set; }
}