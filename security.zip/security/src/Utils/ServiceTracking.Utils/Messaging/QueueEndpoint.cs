namespace ServiceTracking.Utils.Messaging;

/// <summary>
/// Queue endpoint base class
/// </summary>
public class QueueEndpoint
{
    /// <summary>
    /// Name of the queue
    /// </summary>
    public string QueueName { get; set; }
}
