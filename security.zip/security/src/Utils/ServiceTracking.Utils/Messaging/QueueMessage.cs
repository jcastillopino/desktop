using System.Text;

namespace ServiceTracking.Utils.Messaging;

/// <summary>
/// Queue Message definition. Needs to be extended for the technology specifics
/// </summary>
/// <typeparam name="S">Sender object</typeparam>
public abstract class QueueMessage
{
    public QueueMessage()
    {
        Headers = new Dictionary<string, object>();
    }

    private byte[] _data;

    /// <summary>
    /// Headers of the message
    /// </summary>
    public IDictionary<string, object> Headers { get; set; }

    /// <summary>
    /// Parameters of the message
    /// </summary>
    public IDictionary<string, object> Params { get; set; }

    /// <summary>
    /// Sets a message as processed in the broker
    /// </summary>
    /// <param name="sender">Message sender</param>
    /// <param name="args">Additional arguments</param>
    internal abstract void Confirm(object sender, object confirmationInfo);

    /// <summary>
    /// Message content
    /// </summary>
    public byte[] Data
    {
        get
        {
            return _data;
        }

        set
        {
            _data = value;
        }
    }

    /// <summary>
    /// Message content displayed as text
    /// </summary>
    public string Text
    {
        get
        {
            return Encoding.UTF8.GetString(_data);
        }

        set
        {
            _data = Encoding.UTF8.GetBytes(value);
        }
    }
}
