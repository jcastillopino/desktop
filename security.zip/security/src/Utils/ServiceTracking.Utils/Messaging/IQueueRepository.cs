namespace ServiceTracking.Utils.Messaging;

/// <summary>
/// Repository for communicating with a messaging broker
/// </summary>
/// <typeparam name="E">Queue endpoint type</typeparam>
/// <typeparam name="M">Queue message type</typeparam>
/// <typeparam name="S">Sender type</typeparam>
public interface IQueueRepository<E, M>
    where E : QueueEndpoint
    where M : QueueMessage
{
    /// <summary>
    /// Publishes a message to the broker
    /// </summary>
    /// <param name="endpoint">Queue endpoint</param>
    /// <param name="message">Queue message</param>
    /// <param name="delay">Milliseconds for message send delay</param>
    void Send(E endpoint, M message, int? delay = null);

    /// <summary>
    /// Sends the asynchronous.
    /// </summary>
    /// <param name="endpoint">The endpoint.</param>
    /// <param name="message">The message.</param>
    /// <param name="delay">The delay.</param>
    /// <returns></returns>
    Task SendAsync(E endpoint, M message, int? delay = null);

    /// <summary>
    /// Receives a message from a queue applying retry and dead letter mechanism
    /// </summary>
    /// <param name="endpoint">Queue endpoint</param>
    /// <param name="messageReceive">Function that will be executed when the message is received. Depending on the resul the message will be considered processed </param>
    void Receive(E endpoint, Func<M, bool> messageReceive, int retries = 3);

    /// <summary>
    /// Receives the asynchronous.
    /// </summary>
    /// <param name="endpoint">The endpoint.</param>
    /// <param name="messageReceive">The message receive.</param>
    /// <param name="retries">The retries.</param>
    Task ReceiveAsync(E endpoint, Func<M, bool> messageReceive, int retries = 3);

    /// <summary>
    /// Receives a message from a queue with no retry or reprocess
    /// </summary>
    /// <param name="endpoint">Queue Endpoint</param>
    /// <returns>Message received</returns>
    M Receive(E endpoint);

    /// <summary>
    /// Receives the asynchronous.
    /// </summary>
    /// <param name="endpoint">The endpoint.</param>
    /// <returns></returns>
    Task<M> ReceiveAsync(E endpoint);
}
