namespace ServiceTracking.Utils.Messaging
{
    /// <summary>
    /// Service to manage retry mecahnism in queues. Some queues brokes has those already implemented but some not.
    /// </summary>
    public interface IQueueRetriesService
    {
        /// <summary>
        /// get the number of executed retries for a message
        /// </summary>
        /// <param name="messageId">Message Id</param>
        /// <returns></returns>
        int GetRetries(string messageId);

        /// <summary>
        /// Adds one to the number of retries for a message
        /// </summary>
        /// <param name="messageId">The message Id</param>
        void IncrementRetries(string messageId);
    }
}
