namespace ServiceTracking.Utils.Messaging
{
    public class QueueRetriesService : IQueueRetriesService
    {
        private static readonly Dictionary<string, int> _queueRetries = new Dictionary<string, int>();

        public int GetRetries(string messageId)
        {
            if (!_queueRetries.TryGetValue(messageId, out int retries))
            {
                _queueRetries.Add(messageId, retries);
            }

            return retries;
        }

        public void IncrementRetries(string messageId)
        {
            if (_queueRetries.TryGetValue(messageId, out int retries))
            {
                _queueRetries.Remove(messageId);
                _queueRetries.Add(messageId, retries + 1);
            }
            else
            {
                throw new Exception("Retries failed");
            }
        }
    }
}
