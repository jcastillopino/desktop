using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace ServiceTracking.Utils.Validation;

public static class ValidatorHelper
{
    public static bool TryValidate<T>(this T obj, out string errors)
    {
        var validationErrors = new List<ValidationResult>();
        var result = Validator.TryValidateObject(obj, new ValidationContext(obj), validationErrors, true);
        errors = string.Join("; ", validationErrors.Select(x => x.ErrorMessage).ToArray());
        return result;
    }

    public static bool TryValidate<T>(this T obj, out ICollection<ValidationResult> results)
    {
        results = new List<ValidationResult>();
        return Validator.TryValidateObject(obj, new ValidationContext(obj), results, true);
    }

    public static void Validate(this object obj)
    {
        var validationErrors = new List<ValidationValue>();

        if (obj == null) return;

        foreach (var prop in obj.GetType().GetProperties())
        {
            var value = prop.GetValue(obj);

            ValidationValue? result;

            if ((result = TryValidateRequired(value, prop)) != null)
            {
                validationErrors.Add(result.Value);
            }

            if ((result = TryValidateMaxLength(value, prop)) != null)
            {
                validationErrors.Add(result.Value);
            }

            if ((result = TryValidateMinLength(value, prop)) != null)
            {
                validationErrors.Add(result.Value);
            }
        }

        if (validationErrors.Count > 0)
            throw new ValidationException(validationErrors);
    }

    public static ValidationValue? TryValidateRequired(object value, PropertyInfo prop)
    {
        ValidationValue? result = null;

        var hasRequired = Attribute.IsDefined(prop, typeof(RequiredAttribute));

        if (hasRequired)
        {
            if (value == null ||
                prop.PropertyType == typeof(string) && string.IsNullOrEmpty(value.ToString())
                )
            {
                result = new ValidationValue($"Property {prop.Name} can't be empty.", prop.Name);
            }
        }

        return result;
    }

    public static ValidationValue? TryValidateMaxLength(object value, PropertyInfo prop)
    {
        if (value == null) return null;

        ValidationValue? result = null;
        
        var attr = (MaxLengthAttribute[])prop.GetCustomAttributes(typeof(MaxLengthAttribute), false);

        if (attr.Length > 0)
        {
            if (prop.PropertyType == typeof(string) && value.ToString().Length > attr[0].Length)
            {
                result = new ValidationValue($"Property {prop.Name} exceeds maximum length ({attr[0].Length}).", prop.Name);
            }
        }

        return result;
    }

    public static ValidationValue? TryValidateMinLength(object value, PropertyInfo prop)
    {
        if (value == null) return null;

        ValidationValue? result = null;

        var attr = (MinLengthAttribute[])prop.GetCustomAttributes(typeof(MinLengthAttribute), false);

        if (attr.Length > 0)
        {
            if (prop.PropertyType == typeof(string) && value.ToString().Length < attr[0].Length)
            {
                result = new ValidationValue($"Property {prop.Name} doesn't reach minimun length ({attr[0].Length}).", prop.Name);
            }
        }

        return result;
    }
}