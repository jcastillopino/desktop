﻿namespace ServiceTracking.Utils.Validation;

public class ValidationException : Exception
{
    public ValidationException(IEnumerable<ValidationValue> validationResult)
        : base("Validation has failed")
    {
        ValidationResult = validationResult;
    }

    public IEnumerable<ValidationValue> ValidationResult { get; private set; }

}
