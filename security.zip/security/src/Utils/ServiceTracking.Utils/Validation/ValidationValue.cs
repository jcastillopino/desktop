namespace ServiceTracking.Utils.Validation;

public record struct ValidationValue(string Message, string PropertyName);