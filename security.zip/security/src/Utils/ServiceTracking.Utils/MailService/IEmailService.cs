namespace ServiceTracking.Utils.MailService
{
    public interface IEmailService
    {
        public Task SendAsync(string to, string subject, string html, EmailOptions emailOptions);
    }
}
