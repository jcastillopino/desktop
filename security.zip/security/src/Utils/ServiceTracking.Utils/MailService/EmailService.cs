using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using MimeKit.Text;

namespace ServiceTracking.Utils.MailService
{
    public class EmailService : IEmailService
    {
        public async Task SendAsync(string to, string subject, string html, EmailOptions emailOptions)
        {
            using var email = new MimeMessage();
            email.From.Add(MailboxAddress.Parse(emailOptions.EmailFrom));
            email.To.Add(MailboxAddress.Parse(to));
            email.Subject = subject;
            email.Body = new TextPart(TextFormat.Html) { Text = html };

            using var smtp = new SmtpClient();
            smtp.ServerCertificateValidationCallback = (s, c, h, e) => true;
            smtp.Connect(emailOptions.SmtpHost, emailOptions.SmtpPort, SecureSocketOptions.StartTlsWhenAvailable);
            smtp.Authenticate(emailOptions.SmtpUser, emailOptions.SmtpPass);
            await smtp.SendAsync(email);
            smtp.Disconnect(true);
        }
    }
}
