﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Routing;

namespace ServiceTracking.Utils.HealthChecks;

public static class HealthChecksExtensions
{
    public static IEndpointConventionBuilder MapHealthyChecks(this IEndpointRouteBuilder endpoints, string route)
    {
        return endpoints.MapHealthChecks(route, new HealthCheckOptions
        {
            Predicate = healthCheck => healthCheck.Tags.Contains(HealthCheckTags.Healthy)
        });
    }

    public static IEndpointConventionBuilder MapReadyChecks(this IEndpointRouteBuilder endpoints, string route)
    {
        return endpoints.MapHealthChecks(route, new HealthCheckOptions
        {
            Predicate = healthCheck => healthCheck.Tags.Contains(HealthCheckTags.Ready)
        });
    }

    public static IEndpointConventionBuilder MapErrorHandlerCheck(this IEndpointRouteBuilder endpoints, string route)
    {
        return endpoints.MapGet(route, context => throw new Exception("Testing exception"));
    }
}