﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Reflection;

namespace ServiceTracking.Utils.HealthChecks;

public class BasicHealthCheck : IHealthCheck
{
    public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        return Task.FromResult(HealthCheckResult.Healthy($"Ok from {Assembly.GetExecutingAssembly().GetName().Name}"));
    }
}
