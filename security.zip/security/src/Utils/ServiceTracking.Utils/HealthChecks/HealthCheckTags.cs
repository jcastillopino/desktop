﻿namespace ServiceTracking.Utils.HealthChecks;

public static class HealthCheckTags
{
    public const string Ready = "ready";
    public const string Healthy = "healthy";
    public const string Database = "database";
}
