﻿using ServiceTracking.Utils.Extensions;
using ServiceTracking.Utils.Validation;
using System.ComponentModel.DataAnnotations;

namespace ServiceTracking.Utils.Database.Models;

public abstract class NamedEntity : Auditable
{
    protected NamedEntity(string name)
    {
        SetName = name;
        IsActive = true;
    }

    protected NamedEntity(string name, string normalizedName, bool isActive)
    {
        _name = name;
        NormalizedName = normalizedName;
        IsActive = isActive;
    }

    private string _name;

    [Required, MaxLength(30), MinLength(3)]
    public string Name
    {
        get => _name;
        set
        {
            SetName = value;
            this.Validate();
        }
    }

    private string SetName
    {
        set
        {
            _name = value;
            NormalizedName = _name.Standarize();
        }
    }

    [Required, MaxLength(30), MinLength(3)]
    public string NormalizedName { get; private set; }

    [Required]
    public bool IsActive { get; set; }
}
