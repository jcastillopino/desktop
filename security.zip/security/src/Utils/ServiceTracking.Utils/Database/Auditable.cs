using System.ComponentModel.DataAnnotations;

namespace ServiceTracking.Utils.Database.Models
{
    public abstract class Auditable
    {
        [Required]
        public DateTime LastUpdate { get; set; }


    }
}
