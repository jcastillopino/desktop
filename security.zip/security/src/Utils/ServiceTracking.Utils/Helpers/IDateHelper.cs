﻿namespace ServiceTracking.Utils.Helpers;

public interface IDateHelper
{
    DateTime GetCurrentUtc();
}
