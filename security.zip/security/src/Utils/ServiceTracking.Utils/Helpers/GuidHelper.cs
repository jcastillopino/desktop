using ServiceTracking.Utils.Helpers;

namespace ServiceTracking.Utils.Helpers;

public class GuidHelper : IGuidHelper
{
    public Guid CreateNew()
    {
        return Guid.NewGuid();
    }
}