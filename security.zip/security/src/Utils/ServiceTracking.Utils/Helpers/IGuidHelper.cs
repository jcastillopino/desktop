namespace ServiceTracking.Utils.Helpers;

public interface IGuidHelper
{
    Guid CreateNew();
}
