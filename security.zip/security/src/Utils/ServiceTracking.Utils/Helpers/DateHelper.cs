﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceTracking.Utils.Helpers;

public class DateHelper : IDateHelper
{
    public DateTime GetCurrentUtc()
    {
        return DateTime.UtcNow;
    }
}
