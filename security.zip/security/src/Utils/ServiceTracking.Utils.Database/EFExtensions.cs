using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using System.Linq.Expressions;

namespace ServiceTracking.Utils.Database;

public static class EFExtensions
{
    public static bool IsGreaterThan(this string left, string right) => string.CompareOrdinal(left, right) > 0;

    public static bool IsGreaterThanOrEqual(this string left, string right) => string.CompareOrdinal(left, right) >= 0;

    public static bool IsLessThan(this string left, string right) => string.CompareOrdinal(left, right) < 0;

    public static bool IsLessThanOrEqual(this string left, string right) => string.CompareOrdinal(left, right) <= 0;

    public static ModelBuilder RegisterStringFunctions(this ModelBuilder modelBuilder) => modelBuilder
        .RegisterFunction(nameof(IsGreaterThan), ExpressionType.GreaterThan)
        .RegisterFunction(nameof(IsGreaterThanOrEqual), ExpressionType.GreaterThanOrEqual)
        .RegisterFunction(nameof(IsLessThan), ExpressionType.LessThan)
        .RegisterFunction(nameof(IsLessThanOrEqual), ExpressionType.LessThanOrEqual);

    private static ModelBuilder RegisterFunction(this ModelBuilder modelBuilder, string name, ExpressionType type)
    {
        var method = typeof(EFExtensions).GetMethod(name, new[] { typeof(string), typeof(string) });

        modelBuilder.HasDbFunction(method).HasTranslation(parameters =>
        {
            var left = parameters.ElementAt(0);
            var right = parameters.ElementAt(1);

            if (right is SqlParameterExpression rightParam)
                right = rightParam.ApplyTypeMapping(left.TypeMapping);
            else if (left is SqlParameterExpression leftParam)
                left = leftParam.ApplyTypeMapping(right.TypeMapping);

            return new SqlBinaryExpression(type, left, right, typeof(bool), null);
        });

        return modelBuilder;
    }
}
