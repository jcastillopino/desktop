using Microsoft.EntityFrameworkCore;
using ServiceTracking.Utils.Database.Contracts;
using System.Data;

namespace ServiceTracking.Utils.Database.Feed;

public abstract class FeedRepository<TEntity, TFeedEntity> :IFeedRepository<TEntity, TFeedEntity> where TFeedEntity : IAmFeed where TEntity : class
{
    protected readonly DbContext _context;

    protected FeedRepository(DbContext context)
    {
        _context = context;
    }

    public abstract Task ReplaceFeed(IEnumerable<TFeedEntity> entities, string mergeSP);

    protected static void LoadDataTable(IEnumerable<TFeedEntity> entities, DataTable dataTable)
    {
        var rows = entities.Select(r =>
        {
            var row = dataTable.NewRow();

            if (r == null) throw new NullReferenceException(nameof(r));

            foreach (var prop in r.GetType().GetProperties().ToArray())
            {
                row[prop.Name] = prop.GetValue(r) ?? DBNull.Value;
            }

            return row;
        });

        foreach (var row in rows)
        {
            dataTable.Rows.Add(row);
        }
    }
}