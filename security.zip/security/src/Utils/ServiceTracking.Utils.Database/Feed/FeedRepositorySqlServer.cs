using Microsoft.EntityFrameworkCore;
using ServiceTracking.Utils.Database.Contracts;
using System.Data;
using System.Data.SqlClient;

namespace ServiceTracking.Utils.Database.Feed;

public class FeedRepositorySqlServer<TEntity, TFeedEntity> : FeedRepository<TEntity, TFeedEntity> where TFeedEntity : IAmFeed where TEntity : class
{
    public FeedRepositorySqlServer(DbContext context)
        : base(context)
    {
    }

    public override async Task ReplaceFeed(IEnumerable<TFeedEntity> entities, string mergeSP)
    {
        await using var connection = new SqlConnection(_context.Database.GetConnectionString());

        await connection.OpenAsync();

        await CleanFeed(connection);
        await InsertBulk(entities, connection);
        await ReplaceFeedTable(mergeSP);
    }

    private async Task InsertBulk(IEnumerable<TFeedEntity> entities, SqlConnection connection)
    {
        using var dataTable = new DataTable();

        var feedTable = GetFeedTableName();

        var columns = typeof(TFeedEntity).GetProperties().Where(x => x.GetAccessors().Any(y => y.IsPublic)).Select(p =>
                new DataColumn(
                    p.Name,
                    Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType)).
            ToArray();

        dataTable.Columns.AddRange(columns);
        dataTable.AcceptChanges();

        var bulkCopy = new SqlBulkCopy(connection) { DestinationTableName = feedTable };

        LoadDataTable(entities, dataTable);

        dataTable.AcceptChanges();
        if (dataTable.Rows.Count > 0)
        {
            await bulkCopy.WriteToServerAsync(dataTable);
        }
    }

    private async Task CleanFeed(SqlConnection connection)
    {
        var feedTable = GetFeedTableName();

        await using var command = new SqlCommand
        {
            Connection = connection,
            CommandType = CommandType.Text,
            CommandText = $"TRUNCATE TABLE {feedTable}"
        };

        await command.ExecuteNonQueryAsync();
    }

    private string GetFeedTableName()
    {
        var entityType = _context.Model.FindEntityType(typeof(TFeedEntity));
        var schema = entityType.GetSchema();
        var tableName = entityType.GetTableName();

        return $"[{schema}].[{tableName}]";
    }

    private async Task ReplaceFeedTable(string sp)
    {
        await _context.Database.ExecuteSqlRawAsync($"EXEC {sp}");
    }
}