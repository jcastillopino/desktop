using ServiceTracking.Utils.Database.Contracts;

namespace ServiceTracking.Utils.Database.Feed
{
    public interface IFeedRepository<TEntity, FeedEntity> where FeedEntity : IAmFeed
    {
        Task ReplaceFeed(IEnumerable<FeedEntity> entities,string mergeSP);
    }
}