namespace ServiceTracking.Utils.Database
{
    public class ConnectionStringManager : IConnectionStringManager
    {
        public string GetConnectionString(string server, string database, string user, string password)
        {
            return $"Server=.\\{server};Database={database};User Id={user};Password={password};";
        }

        public string GetConnectionString(DBConnectionProvider dbConnectionProvider)
        {
            return dbConnectionProvider.ConnectionString;
        }
    }
}
