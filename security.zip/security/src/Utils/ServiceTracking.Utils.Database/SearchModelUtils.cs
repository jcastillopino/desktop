﻿using Newtonsoft.Json;
using System.Text;
using ServiceTracking.Utils.Database.QueryHelpers;
using SortOrder = ServiceTracking.Utils.Database.QueryHelpers.SortOrder;

namespace ServiceTracking.Utils.Database;

public static class SearchModelUtils
{
    public static StringContent BuildSearchModel(string columnName, string columnValue, CellDataType columnType,
        string sortColumn)
    {
        var payload = new SearchModel
        {
            PaginationModel = new PaginationModel
            {
                PageSize = 10,
                CurrentPage = 1
            },
            AdvancedFilterModels = new List<AdvancedFilterModel>
            {
                new AdvancedFilterModel
                {
                    Column = columnName,
                    Value = columnValue,
                    Type = columnType,
                    Operator = FilterOperator.Equals
                }
            },
            SortModel = new SortModel
            {
                ColumnName = sortColumn,
                Order = SortOrder.Ascending
            }
        };
        return new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
    }

    public static StringContent BuildSortSearchModel(string sortColumn)
    {
        var payload = new SearchModel
        {
            PaginationModel = new PaginationModel
            {
                PageSize = 10,
                CurrentPage = 1
            },
            SortModel = new SortModel
            {
                ColumnName = sortColumn,
                Order = SortOrder.Ascending
            }
        };

        return new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
    }
}
