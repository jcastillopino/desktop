﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using ServiceTracking.Utils.Database;
using System.Data.SqlClient;

namespace ServiceTracking.Utils.HealthChecks;

public class DatabaseHealthCheck : IHealthCheck
{
    private readonly DBConnectionProvider _connectionProvider;

    public DatabaseHealthCheck(IOptions<DBConnectionProvider> connectionProviderOptions)
    {
        _connectionProvider = connectionProviderOptions.Value;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        await using var connection = new SqlConnection(_connectionProvider.ConnectionString);
        var cts = new CancellationTokenSource();
        cts.CancelAfter(1500);
        await connection.OpenAsync(cts.Token);

        return HealthCheckResult.Healthy("Able to connect to the database.");
    }
}
