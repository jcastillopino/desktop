﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace ServiceTracking.Utils.HealthChecks;
public class DatabaseMigrationsHealthCheck<TContext> : IHealthCheck
    where TContext : DbContext
{
    private readonly TContext _dbContext;

    public DatabaseMigrationsHealthCheck(TContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        var migrationsApplied = !(await _dbContext.Database.GetPendingMigrationsAsync(cancellationToken)).Any();
       
        if (migrationsApplied)
        {
            return HealthCheckResult.Healthy("DB migrations are up to date.");
        }

        return HealthCheckResult.Unhealthy("DB migrations are not up to date.");
    }
}
