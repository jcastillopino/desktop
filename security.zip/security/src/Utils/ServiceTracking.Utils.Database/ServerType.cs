namespace ServiceTracking.Utils.Database;
public enum ServerType
{
    SqlServer,
}
