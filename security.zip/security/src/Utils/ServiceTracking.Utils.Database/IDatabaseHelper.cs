namespace ServiceTracking.Utils.Database;

public interface IDatabaseHelper
{
    Task<IReadOnlyCollection<IReadOnlyCollection<string>>> ReadFromStoreProcedure(
      string connectionString,
      IReadOnlyCollection<Guid> ids,
      string procedure,
      string parameterName,
      string typeName,
      string columnName,
      IReadOnlyCollection<string> resultParamNames);

    void ExecuteScript(string connectionString, string content);


}
