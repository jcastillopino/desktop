using Microsoft.Data.SqlClient;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using System.Data;

namespace ServiceTracking.Utils.Database;

public class DatabaseHelper : IDatabaseHelper
{
    public void ExecuteScript(string connectionString, string content)
    {
        if (string.IsNullOrEmpty(content)) return;
        SqlConnection? connection = null;

        try
        {
            connection = new SqlConnection(connectionString);
            Server server = new(new ServerConnection(connection));
            server.ConnectionContext.ExecuteNonQuery(content);
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            connection?.Close();
        }
    }

    public async Task<IReadOnlyCollection<IReadOnlyCollection<string>>> ReadFromStoreProcedure(
      string connectionString,
      IReadOnlyCollection<Guid> ids,
      string procedure,
      string parameterName,
      string typeName,
      string columnName,
      IReadOnlyCollection<string> resultParamNames)
    {
        var result = new List<IReadOnlyCollection<string>>();

        var table = new DataTable();
        table.Columns.Add(columnName, typeof(Guid));

        foreach (var id in ids)
        {
            var row = table.NewRow();
            row[columnName] = id;
            table.Rows.Add(row);
        }

        await using var con = new SqlConnection(connectionString);
        await using var cmd = new SqlCommand(procedure, con);

        cmd.CommandType = CommandType.StoredProcedure;

        var parameter = cmd.CreateParameter();
        parameter.TypeName = typeName;
        parameter.Value = table;
        parameter.ParameterName = parameterName;

        cmd.Parameters.Add(parameter);

        con.Open();
        var reader = await cmd.ExecuteReaderAsync();

        while (reader.Read())
        {
            var paramResult = new List<string>();

            foreach (var param in resultParamNames)
            {
                paramResult.Add(reader[param].ToString());
            }

            result.Add(paramResult);
        }

        return result;
    }
}
