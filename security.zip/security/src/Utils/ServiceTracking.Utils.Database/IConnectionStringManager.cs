namespace ServiceTracking.Utils.Database
{
    public interface IConnectionStringManager
    {
        string GetConnectionString(DBConnectionProvider dbConnectionProvider);
    }
}
