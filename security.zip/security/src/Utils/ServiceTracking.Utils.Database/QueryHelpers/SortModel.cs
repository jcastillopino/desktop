namespace ServiceTracking.Utils.Database.QueryHelpers;

public class SortModel
{
    public string ColumnName { get; set; }

    public SortOrder Order { get; set; }
}
