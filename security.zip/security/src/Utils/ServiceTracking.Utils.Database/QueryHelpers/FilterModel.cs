namespace ServiceTracking.Utils.Database.QueryHelpers;

public class FilterModel
{
    public string Filter { get; set; }

    public string HeaderName { get; set; }
}
