using ServiceTracking.Utils.Database.QueryHelpers.FilterHelpers;

namespace ServiceTracking.Utils.Database.QueryHelpers
{
    public static class SearchExtensions
    {
        public static IQueryable<TEntity> Filter<TEntity>(
            this IQueryable<TEntity> query,
            SearchModel searchModel) where TEntity : class
        {
            if (searchModel?.AdvancedFilterModels != null)
            {
                query = new FilterHelper<TEntity>().Apply(query, searchModel);
            }

            return query;
        }

        public static IQueryable<TEntity> Sort<TEntity>(
            this IQueryable<TEntity> query, 
            SearchModel searchModel) where TEntity : class
        {
            if (searchModel?.SortModel != null)
            {
                query = new SortHelper<TEntity>().Apply(query, searchModel);
            }

            return query;
        }

        public static IQueryable<TEntity> Paginate<TEntity>(
            this IQueryable<TEntity> query, 
            SearchModel searchModel) where TEntity : class
        {
            if (searchModel?.PaginationModel != null)
            {
                var pageNumber = searchModel.PaginationModel.CurrentPage <= 0 ? 1 : searchModel.PaginationModel.CurrentPage;

                var pageSize = searchModel.PaginationModel.PageSize;

                if (pageNumber != null && pageSize != null)
                    query = query.Skip((pageNumber.Value - 1) * pageSize.Value).Take(pageSize.Value);
            }

            return query;
        }
    }
}
