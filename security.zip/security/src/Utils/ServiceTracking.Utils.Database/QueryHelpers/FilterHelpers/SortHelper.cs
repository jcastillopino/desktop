using System.Linq.Expressions;
using System.Reflection;

namespace ServiceTracking.Utils.Database.QueryHelpers.FilterHelpers;

public class SortHelper<TEntity>
{
    public IQueryable<TEntity> Apply(IQueryable<TEntity> query, SearchModel searchModel)
    {
        var isAscendingSort = searchModel.SortModel.Order == SortOrder.Ascending;

        if (!string.IsNullOrEmpty(searchModel.SortModel.ColumnName) && searchModel.SortModel.Order != SortOrder.None)
            return OrderBy(query, searchModel.SortModel.ColumnName, isAscendingSort);

        return query;
    }

    private static IQueryable<TEntity> OrderBy(IQueryable source, string ordering, bool isAscending = true)
    {
        var type = typeof(TEntity);
        var propertyParts = ordering.Split(".");
        var property = GetProperty(type, ordering);
        if (property is null)
        {
            throw new InvalidOperationException($"Error sorting, the type {type.Name} does not have a property {ordering}.");
        }

        // E1 = x
        var expression1 = Expression.Parameter(type, "x");

        // E2 = E1.PROPERTY(.NESTEDPROPERTY)
        Expression body = expression1;
        foreach (var member in propertyParts)
        {
            body = Expression.PropertyOrField(body, member);
        }

        // E3 = E1 => E2
        var expression3 = Expression.Lambda(body, expression1);

        var sortType = isAscending ? "OrderBy" : "OrderByDescending";

        // PropertyType should be of the type of the nested property
        var resultExp = Expression.Call(typeof(Queryable), sortType, new[] { type, property.PropertyType }, source.Expression, Expression.Quote(expression3));
        return source.Provider.CreateQuery<TEntity>(resultExp);
    }

    private static PropertyInfo GetProperty(Type type, string ordering)
    {
        var index = ordering.IndexOf(".", StringComparison.Ordinal);

        if (index <= -1)
            return type.GetProperty(ordering);

        var nestedPropertyName = ordering.Substring(0, index);
        var propertyInfo = type.GetProperty(nestedPropertyName);
        var propertyType = propertyInfo?.PropertyType;
        return GetProperty(propertyType, ordering.Substring(index + 1));
    }
}