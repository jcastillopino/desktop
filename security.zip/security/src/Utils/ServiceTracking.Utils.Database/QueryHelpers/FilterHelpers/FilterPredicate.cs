using System.Linq.Expressions;

namespace ServiceTracking.Utils.Database.QueryHelpers.FilterHelpers;

public class FilterPredicate
{
    public Expression Predicate { get; set; }

    public FilterCondition OperatorType { get; set; }
}