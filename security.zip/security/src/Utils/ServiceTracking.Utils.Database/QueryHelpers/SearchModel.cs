using ServiceTracking.Utils.Database.QueryHelpers.FilterHelpers;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace ServiceTracking.Utils.Database.QueryHelpers;

public class SearchModel
{
    public PaginationModel PaginationModel { get; set; }

    public List<AdvancedFilterModel> AdvancedFilterModels { get; set; } = new();

    public List<FilterModel> FilterModels { get; set; } = new();

    public SortModel SortModel { get; set; }

    public IQueryable<T> ApplySearch<T>(IQueryable<T> query)
    {
        if (AdvancedFilterModels != null)
            query = new FilterHelper<T>().Apply(query, this);

        if (SortModel != null)
            query = new SortHelper<T>().Apply(query, this);

        if (PaginationModel != null)
        {
            var pageNumber = PaginationModel.CurrentPage <= 0 ? 1 : PaginationModel.CurrentPage;
            var pageSize = PaginationModel.PageSize;

            if (pageNumber != null && pageSize != null)
                query = query.Skip((pageNumber.Value - 1) * pageSize.Value).Take(pageSize.Value);
        }

        return query;
    }

    public IQueryable<T> ApplyCount<T>(IQueryable<T> query)
    {
        if (AdvancedFilterModels != null)
            query = new FilterHelper<T>().Apply(query, this);
        if (SortModel != null)
            query = new SortHelper<T>().Apply(query, this);

        return query;
    }

}
