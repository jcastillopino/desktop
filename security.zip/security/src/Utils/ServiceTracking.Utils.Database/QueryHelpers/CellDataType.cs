namespace ServiceTracking.Utils.Database.QueryHelpers;

public enum CellDataType
{
    None = 0,
    Text = 1,
    Number = 2,
    Bool = 3,
    Date = 4,
    DateTime = 5
}
