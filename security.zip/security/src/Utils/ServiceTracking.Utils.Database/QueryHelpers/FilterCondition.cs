namespace ServiceTracking.Utils.Database.QueryHelpers;

public enum FilterCondition
{
    None = 0,
    And = 1,
    Or = 2,
}
