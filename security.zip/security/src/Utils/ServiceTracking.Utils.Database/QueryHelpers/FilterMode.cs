namespace ServiceTracking.Utils.Database.QueryHelpers;

public enum FilterMode
{
    Textual = 1,
    Contained = 2,
    Date = 3
}