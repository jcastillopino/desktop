namespace ServiceTracking.Utils.Database.QueryHelpers;

public enum SortOrder
{
    Ascending = 1,
    Descending = 2,
    None = 3
}