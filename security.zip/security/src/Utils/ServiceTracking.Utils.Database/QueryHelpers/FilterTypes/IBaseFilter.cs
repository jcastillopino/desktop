using ServiceTracking.Utils.Database.QueryHelpers.FilterHelpers;
using System.Linq.Expressions;

namespace ServiceTracking.Utils.Database.QueryHelpers.FilterTypes;

internal interface IBaseFilter<TEntity>
{
    FilterPredicate GetPredicateExpression(
      IQueryable<TEntity> query,
      AdvancedFilterModel filter,
      ParameterExpression accessExpression
    );

    Expression GetSingleFilterPredicateExpression(
        AdvancedFilterModel filter,
        ParameterExpression accessExpression
        );
}