using ServiceTracking.Utils.Database.QueryHelpers.FilterHelpers;
using System.Globalization;
using System.Linq.Expressions;

namespace ServiceTracking.Utils.Database.QueryHelpers.FilterTypes;

internal class DateFilter<TEntity> : IBaseFilter<TEntity>
{
    public FilterPredicate GetPredicateExpression(
        IQueryable<TEntity> query, 
        AdvancedFilterModel filter,
        ParameterExpression accessExpression)
    {
        var resultPredicate = GetSingleFilterPredicateExpression(filter, accessExpression);

        var filterPredicate = new FilterPredicate()
        {
            Predicate = resultPredicate,
            OperatorType = filter.Condition
        };

        return filterPredicate;
    }

    public Expression GetSingleFilterPredicateExpression(
        AdvancedFilterModel filter, 
        ParameterExpression accessExpression)
    {
        var type = typeof(TEntity);
        var propertyType = type.GetProperty(filter.Column);

        var propertyExpression = Expression.MakeMemberAccess(
            accessExpression, 
            propertyType ?? throw new InvalidOperationException());

        if (propertyType == null) throw new NullReferenceException(nameof(propertyType));

        var datePart = GetDate(filter);
        var datePartAdditional = GetDateAdditional(filter);

        var filterExpression = GetOperationExpression(filter, propertyExpression, datePart, datePartAdditional);
        return filterExpression;
    }

    private static DateOnly? GetDate(AdvancedFilterModel filter)
    {
        if (filter.Value == null) return null;

        var culture = !string.IsNullOrEmpty(filter.CultureCode) ?
              new CultureInfo(filter.CultureCode) :
              CultureInfo.InvariantCulture;

        var year = DateTime.ParseExact(filter.Value, filter.DateFormat, culture).Year;
        var month = DateTime.ParseExact(filter.Value, filter.DateFormat, culture).Month;
        var day = DateTime.ParseExact(filter.Value, filter.DateFormat, culture).Day;

        return new DateOnly(year, month, day);
    }

    private static DateOnly? GetDateAdditional(AdvancedFilterModel filter)
    {
        if (string.IsNullOrEmpty(filter.AdditionalValue)) return null;

        var culture = !string.IsNullOrEmpty(filter.CultureCode) ?
              new CultureInfo(filter.CultureCode) :
              CultureInfo.InvariantCulture;

        var year = DateTime.ParseExact(filter.AdditionalValue, filter.DateFormat, culture).Year;
        var month = DateTime.ParseExact(filter.AdditionalValue, filter.DateFormat, culture).Month;
        var day = DateTime.ParseExact(filter.AdditionalValue, filter.DateFormat, culture).Day;

        return new DateOnly(year, month, day);
    }

    private static Expression GetOperationExpression(
        AdvancedFilterModel filter,
        Expression accessExpression,
        DateOnly? value,
        DateOnly? valueAdditional = null)
    {
        var type = typeof(TEntity);
        var propertyType = type.GetProperty(filter.Column);
        Expression propertyExpression = accessExpression;

        if (propertyType?.PropertyType == typeof(DateTime?) && value.HasValue)
        {
            propertyExpression = Expression.MakeMemberAccess(
                accessExpression,
                typeof(DateTime?).GetProperty("Value") ?? throw new InvalidOperationException());

            var yearPredicate = GetPartExpresion(1, filter, propertyExpression, value, valueAdditional);
            var monthPredicate = GetPartExpresion(2, filter, propertyExpression, value, valueAdditional);
            var dayPredicate = GetPartExpresion(3, filter, propertyExpression, value, valueAdditional);

            accessExpression = Expression.NotEqual(accessExpression, Expression.Constant(null, propertyType.PropertyType));
            accessExpression = Expression.AndAlso(accessExpression, yearPredicate);
            accessExpression = Expression.AndAlso(accessExpression, monthPredicate);
            accessExpression = Expression.AndAlso(accessExpression, dayPredicate);
        }
        else if (propertyType?.PropertyType == typeof(DateTime?) && !value.HasValue)
        {
            accessExpression = GetPartExpresion(0, filter, propertyExpression, null, valueAdditional);
        }
        else
        {
            var yearPredicate = GetPartExpresion(1, filter, propertyExpression, value, valueAdditional);
            var monthPredicate = GetPartExpresion(2, filter, propertyExpression, value, valueAdditional);
            var dayPredicate = GetPartExpresion(3, filter, propertyExpression, value, valueAdditional);

            accessExpression = Expression.And(yearPredicate, monthPredicate);
            accessExpression = Expression.And(accessExpression, dayPredicate);
        }

        return accessExpression;
    }

    private static Expression GetPartExpresion(
        int type,
        AdvancedFilterModel filter,
        Expression accessExpression,
        DateOnly? value,
        DateOnly? valueAdditional = null)
    {
        Expression predicate;
        Expression constant;
        Expression constantAdditional;

        var type2 = typeof(TEntity);
        var propertyType = type2.GetProperty(filter.Column);

        switch (type)
        {
            case 1:
                constant = Expression.Constant(value.Value.Year);
                constantAdditional = valueAdditional.HasValue ? Expression.Constant(valueAdditional.Value.Year) : null;
                accessExpression = Expression.MakeMemberAccess(
                    accessExpression,
                    typeof(DateTime).GetProperty("Year") ?? throw new InvalidOperationException());
                break;
            case 2:
                constant = Expression.Constant(value.Value.Month);
                constantAdditional = valueAdditional.HasValue ? Expression.Constant(valueAdditional.Value.Month) : null;
                accessExpression = Expression.MakeMemberAccess(
                    accessExpression,
                    typeof(DateTime).GetProperty("Month") ?? throw new InvalidOperationException());
                break;
            case 3:
                constant = Expression.Constant(value.Value.Day);
                constantAdditional = valueAdditional.HasValue ? Expression.Constant(valueAdditional.Value.Day) : null;
                accessExpression = Expression.MakeMemberAccess(
                    accessExpression,
                    typeof(DateTime).GetProperty("Day") ?? throw new InvalidOperationException());
                break;
            default:
                constant = Expression.Convert(Expression.Constant(null), propertyType?.PropertyType ?? throw new InvalidOperationException());
                constantAdditional = Expression.Convert(Expression.Constant(null), propertyType.PropertyType);
                break;
        }

        switch (filter.Operator)
        {
            case FilterOperator.Equals:
                predicate = Expression.Equal(accessExpression, constant);
                break;

            case FilterOperator.NotEquals:
                predicate = Expression.NotEqual(accessExpression, constant);
                break;

            case FilterOperator.GreaterThan:
                predicate = Expression.GreaterThanOrEqual(accessExpression, constant);
                break;

            case FilterOperator.LessThan:
                predicate = Expression.LessThanOrEqual(accessExpression, constant);
                break;

            case FilterOperator.Range:
                var predicateLess = Expression.GreaterThanOrEqual(accessExpression, constant);
                var predicateGreat = Expression.LessThanOrEqual(accessExpression, constantAdditional ?? throw new InvalidOperationException());
                predicate = Expression.And(predicateLess, predicateGreat);
                break;

            default:
                throw new ArgumentOutOfRangeException();
        }

        return predicate;
    }
}