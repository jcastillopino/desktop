using ServiceTracking.Utils.Database.QueryHelpers.FilterHelpers;
using System.Globalization;
using System.Linq.Expressions;

namespace ServiceTracking.Utils.Database.QueryHelpers.FilterTypes;

internal class DateTimeFilter<TEntity> : IBaseFilter<TEntity>
{
    public FilterPredicate GetPredicateExpression(IQueryable<TEntity> query, AdvancedFilterModel filter, ParameterExpression accessExpression)
    {
        var resultPredicate = GetSingleFilterPredicateExpression(filter, accessExpression);

        var filterPredicate = new FilterPredicate()
        {
            Predicate = resultPredicate,
            OperatorType = filter.Condition
        };

        return filterPredicate;
    }

    public Expression GetSingleFilterPredicateExpression(
        AdvancedFilterModel filter, 
        ParameterExpression accessExpression)
    {
        var type = typeof(TEntity);
        var propertyType = type.GetProperty(filter.Column);

        var propertyExpression = Expression.MakeMemberAccess(accessExpression, propertyType ?? throw new InvalidOperationException());

        if (propertyType == null) throw new NullReferenceException(nameof(propertyType));

        var culture = !string.IsNullOrEmpty(filter.CultureCode) ? new CultureInfo(filter.CultureCode):CultureInfo.InvariantCulture;

        var dateValue = !string.IsNullOrEmpty(filter.Value) ?
             DateTime.ParseExact(filter.Value, filter.DateFormat, culture) :
             (DateTime?)null;

        var dateAdditional = !string.IsNullOrEmpty(filter.AdditionalValue) ?
            DateTime.ParseExact(filter.AdditionalValue, filter.DateFormat, culture):
            (DateTime?)null;

        var filterExpression = GetOperationExpression(filter, propertyExpression, dateValue, dateAdditional);

        return filterExpression;
    }

    private static Expression GetOperationExpression(
        AdvancedFilterModel filter, 
        Expression accessExpression, 
        DateTime? value, 
        DateTime? valueAdditional = null)
    {
        Expression predicate;

        var type = typeof(TEntity);
        var propertyType = type.GetProperty(filter.Column);

        Expression constant;

        Expression constantAdditional;


        if (Nullable.GetUnderlyingType(propertyType?.PropertyType ?? throw new InvalidOperationException()) != null)
        {
            constant = Expression.Convert(
                Expression.Constant(value), 
                    propertyType.PropertyType);
            
            constantAdditional = Expression.Convert(
                Expression.Constant(valueAdditional), propertyType.PropertyType);
        }
        else
        {
            constant = Expression.Constant(value.GetValueOrDefault());
            constantAdditional = Expression.Constant(valueAdditional.GetValueOrDefault());
        }

        switch (filter.Operator)
        {
            case FilterOperator.Equals:
                predicate = Expression.Equal(accessExpression, constant);
                break;

            case FilterOperator.NotEquals:
                predicate = Expression.NotEqual(accessExpression, constant);
                break;

            case FilterOperator.GreaterThan:
                predicate = Expression.GreaterThanOrEqual(accessExpression, constant);
                break;

            case FilterOperator.LessThan:
                predicate = Expression.LessThanOrEqual(accessExpression, constant);
                break;

            case FilterOperator.Range:
                var predicateLess = Expression.GreaterThanOrEqual(accessExpression, constant);
                var predicateGreat = Expression.LessThanOrEqual(accessExpression, constantAdditional);
                predicate = Expression.And(predicateLess, predicateGreat);
                break;

            default:
                throw new ArgumentOutOfRangeException();
        }

        return predicate;
    }
}