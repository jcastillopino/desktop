using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using ServiceTracking.Utils.Database.Extensions;

namespace ServiceTracking.Utils.Database.Extensions;
public static class AppDbContextExtension
{
    private static IConnectionStringManager _connectionStringManager = new ConnectionStringManager();

    public static IServiceCollection AddDbContext<TContext>(
        this IServiceCollection services,
        DBConnectionProvider dbConnectionProvider) where TContext : DbContext
    {
        var connectionString = _connectionStringManager.GetConnectionString(dbConnectionProvider);
        switch (dbConnectionProvider.ServerType)
        {
            case ServerType.SqlServer:
                {
                    services.AddDbContext<TContext>(options =>
                    {
                        options.UseSqlServer(connectionString);
                    }, ServiceLifetime.Scoped);
                    break;
                }
            default:
                {
                    throw new NotImplementedException();
                }
        }

        return services;
    }

    public static DbContextOptionsBuilder UseDatabaseServer(this DbContextOptionsBuilder builder, DBConnectionProvider dbConnectionProvider, string migrationsAssembly)
    {
        var connectionString = _connectionStringManager.GetConnectionString(dbConnectionProvider);
        switch (dbConnectionProvider.ServerType)
        {
            case ServerType.SqlServer:
                builder.UseSqlServer(connectionString, b => b.MigrationsAssembly(migrationsAssembly));
                break;
            default:
                {
                    throw new NotImplementedException();
                }
        }

        return builder;
    }
}
