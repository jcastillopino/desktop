using Microsoft.EntityFrameworkCore.Migrations;

namespace ServiceTracking.Utils.Database.Providers.Postgres;

public static class MigrationBuilderExtensions
{
    public static void ExecuteSQL(this MigrationBuilder builder, string fileName)
    {
        Console.WriteLine($"Executing: {fileName}");
        using var reader = new StreamReader(fileName);
        var sqlContent = reader.ReadToEnd();
        var execution = sqlContent;
        Console.WriteLine(execution);
        builder.Sql(execution);
    }
}