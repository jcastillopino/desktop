using Microsoft.EntityFrameworkCore.Migrations;

namespace ServiceTracking.Utils.Database.Providers.SqlServer;

public static class MigrationBuilderExtensions
{
    public static void ExecuteSQL(this MigrationBuilder builder, string fileName)
    {
        Console.WriteLine($"Executing: {fileName}");
        using var reader = new StreamReader(fileName);
        var sqlContent = reader.ReadToEnd().Replace("'", "''");
        sqlContent = $"DECLARE @SQL AS NVARCHAR(MAX) = '{sqlContent}'";
        var execution = sqlContent + "\r\nEXEC sp_executesql @SQL\r\nGO";
        builder.Sql(execution);
    }
}