using System.Linq.Expressions;

namespace ServiceTracking.Utils.Database.Contracts
{
    public interface IRepository<TEntity> where TEntity : class
    {
        IQueryable<TEntity> GetAll(IEnumerable<string> paths = null, bool isNoTracking = true);

        Task<IList<TEntity>> FindByAsync(Expression<Func<TEntity, bool>> predicate);

        Task<IList<TEntity>> FindByIncludingAsync(Expression<Func<TEntity, bool>> predicate, string path);

        Task AddAsync(TEntity entity);

        Task BulkAddAsync(IList<TEntity> entities);

        Task Delete(TEntity entity);

        Task BulkDelete(IList<TEntity> entities);

        Task Update(TEntity entity);

        Task BulkUpdate(IList<TEntity> entities);
    }
}
