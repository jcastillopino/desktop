namespace ServiceTracking.Utils.Database.Contracts
{
    public interface IAmFeed
    {
    }
}
