﻿namespace ServiceTracking.Utils.Database;
public interface ISoftDelete
{
    public bool IsDeleted { get; set; }
}
