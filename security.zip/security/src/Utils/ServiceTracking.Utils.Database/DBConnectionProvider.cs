
namespace ServiceTracking.Utils.Database;

public class DBConnectionProvider
{
    public ServerType ServerType { get; set; }

    public string ConnectionString { get; set; }

}
