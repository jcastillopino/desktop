namespace ServiceTracking.Utils.Database;

public class SearchResult<T>
{
    public IEnumerable<T> Items { get; set; } = new List<T>();

    public int TotalItems { get; set; }
}
