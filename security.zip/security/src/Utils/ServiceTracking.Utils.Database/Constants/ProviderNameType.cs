namespace ServiceTracking.Utils.Database.Constants;
public static class ProviderNameType
{
    public const string SqlServer = "Microsoft.EntityFrameworkCore.SqlServer";
}
