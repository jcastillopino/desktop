using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Utils.BackgroundServices.Contracts;

namespace ServiceTracking.Security.API.Utils.HostedServices;

public class CleanExpiredPasswordResetCodes : IWorker
{
    private readonly IServiceScopeFactory _serviceScopeFactory;

    public CleanExpiredPasswordResetCodes(IServiceScopeFactory serviceScopeFactory)
    {
        _serviceScopeFactory = serviceScopeFactory;
    }

    public async Task DoWorkAsync(CancellationToken cancellationToken)
    {
        var scope = _serviceScopeFactory.CreateScope();

        try
        {

            if (!cancellationToken.IsCancellationRequested)
            {
                var scopedServices = scope.ServiceProvider;
                var logger = scopedServices.GetRequiredService<ILogger<CleanExpiredPasswordResetCodes>>();
                var userRepository = scopedServices.GetRequiredService<IUserRepository>();

                int result = await userRepository.RemoveExpiredPasswordResetCodes();
                logger.LogInformation($"Timed Hosted Service RemoveExpiredPasswordResetCodes is working. Deleted {result} codes. Datetime: {DateTime.UtcNow}.");
            }
        }
        finally 
        {
            scope.Dispose();
        }
    }
}