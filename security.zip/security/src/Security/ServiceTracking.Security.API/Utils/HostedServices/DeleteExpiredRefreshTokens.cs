using ServiceTracking.Security.API.Flows.Authorization;
using ServiceTracking.Utils.BackgroundServices.Contracts;

namespace ServiceTracking.Security.API.Utils.HostedServices;

public class DeleteExpiredRefreshTokens : IWorker
{
    private readonly IServiceScopeFactory _serviceScopeFactory;

    public DeleteExpiredRefreshTokens(IServiceScopeFactory serviceScopeFactory)
    {
        _serviceScopeFactory = serviceScopeFactory;
    }

    public async Task DoWorkAsync(CancellationToken cancellationToken)
    {
        var scope = _serviceScopeFactory.CreateScope();

        try
        {
            if (!cancellationToken.IsCancellationRequested)
            {
                var scopedServices = scope.ServiceProvider;
                var logger = scopedServices.GetRequiredService<ILogger<DeleteExpiredRefreshTokens>>();
                var authRepository = scopedServices.GetRequiredService<IAuthRepository>();

                int result = await authRepository.CleanExpiredRefreshTokens();
                logger.LogInformation($"Timed Hosted Service {nameof(DeleteExpiredRefreshTokens)} is working. Deleted {result} codes. Datetime: {DateTime.UtcNow}.");
            }
        }
        finally
        {
            scope.Dispose();
        }
    }
}