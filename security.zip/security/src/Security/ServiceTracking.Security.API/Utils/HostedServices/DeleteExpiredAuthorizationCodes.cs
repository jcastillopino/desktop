using ServiceTracking.Security.API.Flows.Authorization;
using ServiceTracking.Utils.BackgroundServices.Contracts;

namespace ServiceTracking.Security.API.Utils.HostedServices;

public class DeleteExpiredAuthorizationCodes : IWorker
{
    private readonly IServiceScopeFactory _serviceScopeFactory;

    public DeleteExpiredAuthorizationCodes(IServiceScopeFactory serviceScopeFactory)
    {
        _serviceScopeFactory = serviceScopeFactory;
    }

    public async Task DoWorkAsync(CancellationToken cancellationToken)
    {
        var scope = _serviceScopeFactory.CreateScope();

        try
        {
            if (!cancellationToken.IsCancellationRequested)
            {
                var scopedServices = scope.ServiceProvider;
                var logger = scopedServices.GetRequiredService<ILogger<DeleteExpiredAuthorizationCodes>>();
                var authRepository = scopedServices.GetRequiredService<IAuthRepository>();

                int result = await authRepository.CleanExpiredAuthorizationCodes();
                logger.LogInformation($"Timed Hosted Service {nameof(DeleteExpiredAuthorizationCodes)} is working. Deleted {result} codes. Datetime: {DateTime.UtcNow}.");
            }
        }
        finally
        {
            scope.Dispose();
        }
    }
}
