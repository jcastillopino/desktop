using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceTracking.Security.API.RBAC.Permissions;
using ServiceTracking.Security.API.RBAC.Permissions.Abstracts;
using ServiceTracking.Security.DTO;
using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Utils.Authorization;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;
using ServiceTracking.Utils.Exceptions;

namespace ServiceTracking.Security.API.Controllers;

[ApiController]
[Authorize]
public sealed class PermissionController : ControllerBase
{
    private readonly IPermissionRepository _permissionRepository;
    private readonly IPermissionService _permissionService;

    public PermissionController(
        IPermissionRepository permissionRepository, 
        IPermissionService permissionService)
    {
        _permissionRepository = permissionRepository;
        _permissionService = permissionService;
    }

    [ProducesResponseType(typeof(PermissionRecord), StatusCodes.Status201Created)]
    [HttpPost("permissions", Name = "PermissionsCreate")]
    public async Task<ActionResult<PermissionRecord>> Create(PermissionAddDto permissionDto)
    {
        var permission = permissionDto.ToEntity();
        var created = await _permissionService.Create(permission);

        var createdPermission = created.ToDto().Sanitize();
        return Created("Get", createdPermission);
    }

    [ProducesResponseType(StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityPermissionsEdit)]
    [HttpPut("permissions", Name = "PermissionsUpdate")]
    public async Task<IActionResult> Update(PermissionUpdateDto permissionDto)
    {
        await _permissionService.Update(permissionDto.Id, permissionDto.Name);

        return Ok();
    }

    [ProducesResponseType(typeof(void), StatusCodes.Status204NoContent)]
    [RequirePermissions(Permissions.SecurityPermissionsEdit)]
    [HttpDelete("permissions/{id}", Name = "PermissionsDelete")]
    public async Task<ActionResult> Delete(Guid id)
    {
        if (!await _permissionRepository.Exists(id))
            throw new EntityNotFoundException(nameof(id));

        await _permissionRepository.Delete(id);
        return NoContent();
    }

    [ProducesResponseType(typeof(SearchResult<PermissionRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityPermissionsRead)]
    [HttpPost("permissions/search", Name = "PermissionsSearch")]
    public async Task<IActionResult> Search([FromBody] SearchModel searchModel)
    {
        var permissionData = await _permissionService.Search(searchModel);

        return Ok(new SearchResult<PermissionRecord>
        {
            Items = permissionData.Data.ToDto().Sanitize(),
            TotalItems = permissionData.Count
        });
    }

    [ProducesResponseType(typeof(SearchResult<PermissionRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityPermissionsRead)]
    [HttpPost("permissions/role/{id}", Name = "PermissionsSearchByRole")]
    public async Task<IActionResult> SearchByRole([FromBody] SearchModel searchModel, Guid id)
    {
        var permissionData = await _permissionService.SearchByRole(searchModel, id);

        return Ok(new SearchResult<PermissionRecord>
        {
            Items = permissionData.Data.ToDto().Sanitize(),
            TotalItems = permissionData.Count
        });
    }

    [ProducesResponseType(typeof(SearchResult<PermissionRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityPermissionsRead)]
    [HttpPost("permissions/user/{id}", Name = "PermissionsSearchByUser")]
    public async Task<IActionResult> SearchByUser([FromBody] SearchModel searchModel, Guid id)
    {
        var permissionData = await _permissionService.SearchByUser(searchModel, id);

        return Ok(new SearchResult<PermissionRecord>
        {
            Items = permissionData.Data.ToDto().Sanitize(),
            TotalItems = permissionData.Count
        });
    }

}