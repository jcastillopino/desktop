using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceTracking.Security.API.RBAC.Permissions;
using ServiceTracking.Security.API.RBAC.Roles;
using ServiceTracking.Security.API.RBAC.Roles.Abstracts;
using ServiceTracking.Security.DTO;
using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Utils.Authorization;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;
using ServiceTracking.Utils.Exceptions;

namespace ServiceTracking.Security.API.Controllers;

[ApiController]
[Authorize]
public sealed class RoleController : ControllerBase
{
    private readonly IRoleRepository _roleRepository;

    private readonly IRoleService _roleService;

    public RoleController(IRoleRepository roleRepository, IRoleService roleService)
    {
        _roleRepository = roleRepository;
        _roleService = roleService;
    }

    [ProducesResponseType(typeof(RoleRecord), StatusCodes.Status201Created)]
    [RequirePermissions(Permissions.SecurityRolesEdit)]
    [HttpPost("roles", Name = "RolesCreate")]
    public async Task<ActionResult<RoleRecord>> Create(RoleAddDto roleDto)
    {
        var role = roleDto.ToEntity();

        var createdUser = await _roleService.Create(role);

        return Created("Get", createdUser.ToDto().Sanitize());
    }

    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [RequirePermissions(Permissions.SecurityRolesEdit)]
    [HttpPut("roles", Name = "RolesUpdate")]
    public async Task<IActionResult> Update(RoleUpdateDto roleDto)
    {
        await _roleService.Update(roleDto.Id, roleDto.Name, roleDto.Permissions);

        return NoContent();
    }

    [ProducesResponseType(typeof(void), StatusCodes.Status204NoContent)]
    [RequirePermissions(Permissions.SecurityRolesEdit)]
    [HttpDelete("roles/{id}", Name = "RolesDelete")]
    public async Task<ActionResult> Delete(Guid id)
    {
        if (!await _roleRepository.Exists(id))
            throw new EntityNotFoundException(nameof(id));

        await _roleRepository.Delete(id);
        return NoContent();
    }

    [ProducesResponseType(typeof(SearchResult<RoleRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityRolesRead)]
    [HttpPost("roles/search", Name = "RolesSearch")]
    public async Task<IActionResult> Search([FromBody] SearchModel searchModel)
    {
        var roleData = await _roleService.Search(searchModel);

        return Ok(new SearchResult<RoleRecord>
        {
            Items = roleData.Data.ToDto().Sanitize(),
            TotalItems = roleData.Count
        });
    }

    [ProducesResponseType(typeof(SearchResult<RoleSimplifiedRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityRolesRead)]
    [HttpPost("roles/user/{id}", Name = "RolesSearchByUser")]
    public async Task<IActionResult> SearchByUser([FromBody] SearchModel searchModel,Guid id)
    {
        var roleData = await _roleService.SearchByUser(searchModel, id);

        return Ok(new SearchResult<RoleSimplifiedRecord>
        {
            Items = roleData.Data.ToSimpleDto().Sanitize(),
            TotalItems = roleData.Count
        });
    }

    [ProducesResponseType(typeof(SearchResult<RoleSimplifiedRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityRolesRead)]
    [HttpPost("roles/permission/{id}", Name = "RolesSearchByPermission")]
    public async Task<IActionResult> SearchByPermission([FromBody] SearchModel searchModel, Guid id)
    {
        var roleData = await _roleService.SearchByPermission(searchModel, id);

        return Ok(new SearchResult<RoleSimplifiedRecord>
        {
            Items = roleData.Data.ToSimpleDto().Sanitize(),
            TotalItems = roleData.Count
        });
    }

    [ProducesResponseType(typeof(List<PermissionRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityRolesRead)]
    [HttpGet("roles/{id}/permissions", Name = "GetRolePermissions")]
    public async Task<IActionResult> GetRolePermissions(Guid id)
    {
        var permissions = await _roleRepository.GetRolePermissions(id);
        var result = new List<PermissionRecord>();

        foreach (var permission in permissions)
        {
            result.Add(permission.ToDto());
        }

        return Ok(result.Sanitize());
    }
}