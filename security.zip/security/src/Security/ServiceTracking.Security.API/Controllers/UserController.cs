using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceTracking.Security.API.Flows.Authentication;
using ServiceTracking.Security.API.RBAC.Permissions;
using ServiceTracking.Security.API.RBAC.Roles;
using ServiceTracking.Security.API.RBAC.Users;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.DTO;
using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Utils.Authorization;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;
using ServiceTracking.Utils.Exceptions;
using System.Net;

namespace ServiceTracking.Security.API.Controllers;

[ApiController]
[Authorize]
public class UserController : ControllerBase
{
    private readonly IUserService _userService;
    private readonly ILoginService _loginService;
    private readonly IUserRepository _userRepository;
    private readonly AppDbContext _dbContext;

    public UserController(
        IUserService userService, 
        IUserRepository userRepository, 
        ILoginService loginService,
        AppDbContext context)
    {
        _userService = userService;
        _userRepository = userRepository;
        _loginService = loginService;
        _dbContext = context;
    }

    [ProducesResponseType(typeof(UserRecord), StatusCodes.Status201Created)]
    [RequirePermissions(Permissions.SecurityUsersEdit)]
    [HttpPost("users", Name = "UsersCreate")]
    public async Task<ActionResult<UserRecord>> Create(UserAddDto userDto)
    {
        var user = userDto.ToEntity();
        await using var transaction = await _dbContext.Database.BeginTransactionAsync();

        try
        {
            var createdUser = await _userService.Create(user);
            await _loginService.AddPassword(user, userDto.Password);

            await transaction.CommitAsync();
            return Created("Get", createdUser.ToDto().Sanitize());
        }
        catch (Exception)
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [RequirePermissions(Permissions.SecurityUsersEdit)]
    [HttpPut("users", Name = "UsersUpdate")]
    public async Task<IActionResult> Update(UserUpdateDto userDto)
    {
        await _userService.Update(userDto.Id, userDto.Name, userDto.LastName, userDto.Permissions, userDto.Roles);

        return NoContent();
    }

    [ProducesResponseType(typeof(void), StatusCodes.Status204NoContent)]
    [RequirePermissions(Permissions.SecurityUsersEdit)]
    [HttpDelete("users/{id}", Name = "UsersDelete")]
    public async Task<ActionResult> Delete(Guid id)
    {
        if ((await _userRepository.Get(id)) == null )
            throw new EntityNotFoundException(nameof(id));

        await _userRepository.Delete(id);
        return NoContent();
    }

    [ProducesResponseType(typeof(SearchResult<UserRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityUsersRead)]
    [HttpPost("users/search", Name = "UsersSearch")]
    public async Task<IActionResult> Search([FromBody] SearchModel searchModel)
    {
        var userData = await _userService.Search(searchModel);

        return Ok(new SearchResult<UserRecord>
        {
            Items = userData.Data.ToDto().Sanitize(),
            TotalItems = userData.Count
        });
    }

    [ProducesResponseType(typeof(SearchResult<UserSimplifiedRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityUsersRead)]
    [HttpPost("users/role/{id}", Name = "UsersSearchByRole")]
    public async Task<IActionResult> SearchByRole([FromBody] SearchModel searchModel, Guid id)
    {
        var userData = await _userService.SearchByRole(searchModel, id);

        return Ok(new SearchResult<UserSimplifiedRecord>
        {
            Items = userData.Data.ToSimpleDto().Sanitize(),
            TotalItems = userData.Count
        });
    }

    [ProducesResponseType(typeof(SearchResult<UserSimplifiedRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityUsersRead)]
    [HttpPost("users/permission/{id}", Name = "UsersSearchByPermission")]
    public async Task<IActionResult> SearchByPermission([FromBody] SearchModel searchModel, Guid id)
    {
        var userData = await _userService.SearchByPermission(searchModel, id);

        return Ok(new SearchResult<UserSimplifiedRecord>
        {
            Items = userData.Data.ToSimpleDto().Sanitize(),
            TotalItems = userData.Count
        });
    }

    [HttpPut("users/password")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    public async Task<ActionResult> ChangePassword(ChangePasswordDto request)
    {
        //ToDo: Do not send username
        await _loginService.ChangePassword(request.Email, request.OldPassword, request.NewPassword);
        return Ok();
    }

    [ProducesResponseType(typeof(List<PermissionRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityUsersRead)]
    [HttpGet("users/{id}/permissions", Name = "GetUserPermissions")]
    public async Task<IActionResult> GetUserPermissions(Guid id)
    {
        var permissions = await _userRepository.GetPermissions(id);
        var result = new List<PermissionRecord>();

        foreach (var permission in permissions)
        {
            result.Add(permission.ToDto());
        }

        return Ok(result.Sanitize());
    }

    [ProducesResponseType(typeof(List<RoleRecord>), StatusCodes.Status200OK)]
    [RequirePermissions(Permissions.SecurityUsersRead)]
    [HttpGet("users/{id}/roles", Name = "GetUserRoles")]
    public async Task<IActionResult> GetRolePermissions(Guid id)
    {
        var roles = await _userRepository.GetRoles(id);
        var result = new List<RoleRecord>();

        foreach (var role in roles)
        {
            result.Add(role.ToDto());
        }

        return Ok(result.Sanitize());
    }
}
