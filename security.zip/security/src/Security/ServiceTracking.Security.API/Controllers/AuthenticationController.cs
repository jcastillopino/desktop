using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using ServiceTracking.Security.DTO.Oauth;
using System.Net;
using System.Security.Claims;
using ServiceTracking.Security.API.Flows.Authentication;

namespace ServiceTracking.Security.API.Controllers;

[Route("auth/")]
[ApiController]
public class AuthenticationController : ControllerBase
{
    private readonly ILoginService _loginService;

    public AuthenticationController(ILoginService userService)
    {
        _loginService = userService;
    }

    [HttpPost("login")]
    [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    public async Task<IActionResult> Login(LoginDto model)
    {
        var user = await _loginService.Login(model.Username, model.Password);

        var claims = new List<Claim>
        {
            new (ClaimTypes.NameIdentifier, user.Id.ToString()),
            new (ClaimTypes.Name, user.Email)
        };

        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var principal = new ClaimsPrincipal(claimsIdentity);

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

        return Ok();
    }

    [HttpGet("logout")]
    [ProducesResponseType((int)HttpStatusCode.OK)]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Ok();
    }
}