using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceTracking.Security.API.Flows.Authorization;
using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using System.Net;
using System.Security.Claims;
using System.Web;

// ReSharper disable InconsistentNaming

namespace ServiceTracking.Security.API.Controllers;

[ApiController]
public class AuthorizationController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly IAuthValidator _authValidator;
    private readonly string _loginChallengeRedirectUri;

    public AuthorizationController(
        IAuthService authService, 
        IConfiguration configuration,
        IAuthValidator authValidator)
    {
        _authService = authService;
        _loginChallengeRedirectUri = configuration.GetValue<string>("Authentication:LoginChallengeRedirectUri");
        _authValidator = authValidator;
    }

    [HttpGet("oauth/authorize")]
    [ProducesResponseType((int)HttpStatusCode.Redirect)]
    public IActionResult OauthAuthorize(string response_type,
        Guid client_id,
        string redirect_uri,
        string scope,
        string state,
        string code_challenge,
        string code_challenge_method)
    {
        var validRedirecturi = _authValidator.ValidateRedirectUri(client_id, new Uri(redirect_uri));
        if (!validRedirecturi)
        {
            return Redirect("/login/invalid");
        }

        string redirectUriAction = Url.Action(nameof(AuthorizeCallback), new
        {
            response_type,
            client_id,
            redirect_uri,
            scope,
            state,
            code_challenge,
            code_challenge_method
        });

        string redirectUri = $"{_loginChallengeRedirectUri}{redirectUriAction}";

        AuthenticationProperties authProps = new()
        {
            RedirectUri = redirectUri
        };

        return Challenge(authProps, CookieAuthenticationDefaults.AuthenticationScheme);
    }

    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    [HttpGet("oauth/authorize/callback")]
    public async Task<IActionResult> AuthorizeCallback(string response_type,
        Guid client_id,
        string redirect_uri,
        string scope,
        string state,
        string code_challenge,
        string code_challenge_method)
    {
        var userId = Guid.Parse(User.Claims.Single(c => c.Type == ClaimTypes.NameIdentifier).Value);

        var request = new AuthRequest(
            response_type,
            client_id,
            new Uri(redirect_uri),
            scope,
            state,
            code_challenge,
            Enum.Parse<CodeChallengeMethod>(code_challenge_method));

        var response = await _authService.Authorize(request, userId);

        UriBuilder uriBuilder = new (redirect_uri);

        System.Collections.Specialized.NameValueCollection query = HttpUtility.ParseQueryString(uriBuilder.Query);
        if (!string.IsNullOrWhiteSpace(response.Code))
        {
            query.Add("code", response.Code);
        }
        else
        {
            query.Add("error", response.Error);
            query.Add("error_description", response.ErrorDescription);
        }

        query.Add("state", response.State);
        uriBuilder.Query = query.ToString() ?? string.Empty;

        return Redirect(uriBuilder.ToString());
    }

    [Authorize]
    [HttpGet("oauth/protected")]
    public IActionResult GetProtectedResource()
    {
        return Ok("The protected resource");
    }

    [HttpPost("oauth/token/api")]
    [ProducesResponseType(typeof(TokenResponse), (int)HttpStatusCode.OK)]
    public async Task<IActionResult> Token(ApiLoginDto model)
    {
        var response = await _authService.BuildApiToken(model.Id, model.Password, model.Client);
        return Ok(response);
    }

    [HttpPost("oauth/token")]
    [ProducesResponseType(typeof(TokenResponse), (int)HttpStatusCode.OK)]
    public async Task<IActionResult> Token(TokenRequest request)
    {
        var response = await _authService.BuildToken(request);
        return Ok(response);
    }
}