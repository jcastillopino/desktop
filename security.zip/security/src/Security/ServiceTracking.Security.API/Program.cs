using Lamar.Microsoft.DependencyInjection;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using ServiceTracking.Security.API.Utils.HostedServices;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Utils.BackgroundServices;
using ServiceTracking.Utils.Cloud;
using ServiceTracking.Utils.Cloud.Azure;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.Extensions;
using ServiceTracking.Utils.Exceptions;
using ServiceTracking.Utils.HealthChecks;
using ServiceTracking.Utils.Helpers;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Text;

namespace ServiceTracking.Security.API
{
    public class Program
    {
        private const string CorsPolicy = "CORSPolicy";

        public static void Main(string[] args)
        {
            WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

            builder.WebHost.UseKestrel(option => option.AddServerHeader = false);

            builder.Host.UseSerilog((hostingContext, loggerConfiguration) =>
            {
                loggerConfiguration.ReadFrom.Configuration(hostingContext.Configuration)
                    .Enrich.FromLogContext()
                    .Enrich.WithProperty("ApplicationName", typeof(Program).Assembly.GetName().Name)
                    .Enrich.WithProperty("Environment", hostingContext.HostingEnvironment);
            });

            if (string.IsNullOrEmpty(builder.Configuration.GetValue<string>("DBConnectionProvider:ConnectionString")))
                builder.Configuration.AddJsonFile($"dbsettings.SqlServer.json", optional: true, reloadOnChange: true);

            ConfigureServices(builder);
            Configure(builder);
        }

        public static void ConfigureServices(WebApplicationBuilder builder)
        {
            if (builder.Environment.IsProduction())
            {
                builder.Services.AddTransient<ICloudConfigurer, AzureConfigurer>();
                AzureConfigurer configurer = new AzureConfigurer();
                configurer.Configure(builder);
            }

            ConfigureSecurityServices(builder);
            ConfigureDIContainer(builder);
            //ConfigureHostedServices(builder);

            if (builder.Environment.IsDevelopment() || builder.Environment.EnvironmentName == "Local")
            {
                builder.Services.AddEndpointsApiExplorer();
                builder.Services.AddSwaggerGen(c =>
                {
                    c.SwaggerDoc("v1", new OpenApiInfo { Title = "MyTestService", Version = "v1", });
                });
            }

            builder.Services.AddHttpClient();

            builder.Services.AddHealthChecks()
                .AddCheck<DatabaseHealthCheck>("database", tags: new[]
                {
                    HealthCheckTags.Healthy,
                    HealthCheckTags.Database
                })
                .AddCheck<DatabaseMigrationsHealthCheck<AppDbContext>>("databaseMigrations", tags: new[]
                {
                    HealthCheckTags.Ready,
                    HealthCheckTags.Database
                })
                .AddCheck<BasicHealthCheck>("healthy", tags: new[]
                {
                    HealthCheckTags.Healthy
                });

            var dbConnectionProviderSection = builder.Configuration.GetRequiredSection("DBConnectionProvider");
            builder.Services.Configure<DBConnectionProvider>(dbConnectionProviderSection);

            var dbConnectionProvider = new DBConnectionProvider();
            dbConnectionProviderSection.Bind(dbConnectionProvider);

            builder.Services.AddDbContext<AppDbContext>(dbConnectionProvider);
        }


        public static void ConfigureHostedServices(WebApplicationBuilder builder)
        {
            builder.Services.AddOptions<BaseHostedServiceOptions<CleanExpiredPasswordResetCodes>>()
                .Bind(builder.Configuration
                .GetSection("CleanExpiredPasswordResetCodes"));
            builder.Services.AddOptions<BaseHostedServiceOptions<DeleteExpiredAuthorizationCodes>>()
                .Bind(builder.Configuration
                .GetSection("DeleteExpiredAuthorizationCodes"));
            builder.Services.AddOptions<BaseHostedServiceOptions<DeleteExpiredRefreshTokens>>()
                .Bind(builder.Configuration
                .GetSection("DeleteExpiredRefreshTokens"));

            builder.Services.AddHostedService<BaseHostedService<CleanExpiredPasswordResetCodes>>();
            builder.Services.AddHostedService<BaseHostedService<DeleteExpiredAuthorizationCodes>>();
            builder.Services.AddHostedService<BaseHostedService<DeleteExpiredRefreshTokens>>();
        }

        public static void ConfigureDIContainer(WebApplicationBuilder builder)
        {
            builder.Host.UseLamar((context, registry) =>
            {
                registry.Scan(x =>
                {
                    x.Assembly("ServiceTracking.Security.API");
                    x.Assembly("ServiceTracking.Security.Infrastructure");
                    x.Assembly("ServiceTracking.Utils");
                    x.Assembly("ServiceTracking.Utils.Database");
                    x.WithDefaultConventions(ServiceLifetime.Transient);
                });

                registry.AddControllers().AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.PropertyNamingPolicy = null;
                    options.JsonSerializerOptions.Converters.Add(new DateTimeJsonConverter());
                    options.JsonSerializerOptions.Converters.Add(new DateOnlyJsonConverter());
                });
            });
        }

        public static void ConfigureSecurityServices(WebApplicationBuilder builder)
        {
            var oauthOptions = new OauthOptions();
            builder.Configuration.GetSection("OauthOptions").Bind(oauthOptions);

            builder.Services.Configure<OauthOptions>(builder.Configuration.GetSection("OauthOptions"));

            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, opt =>
                {
                    var conf = builder.Configuration.GetSection("Authentication");
                    opt.LoginPath = conf.GetValue<string>("LoginPath");
                    opt.ExpireTimeSpan = conf.GetValue<TimeSpan>("CookieExpireTimespan");
                })
                .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, opt =>
                {
                    opt.TokenValidationParameters.ValidateIssuerSigningKey = true;
                    SymmetricSecurityKey securityKey = new(Encoding.ASCII.GetBytes(oauthOptions.AccessTokenSecret));
                    opt.TokenValidationParameters.IssuerSigningKey = securityKey;
                    opt.TokenValidationParameters.ValidateAudience = true;
                    opt.TokenValidationParameters.ValidAudiences = oauthOptions.Clients.Select(c => c.Id.ToString().Replace("-", ""));
                    opt.TokenValidationParameters.ValidateIssuer = true;
                    opt.TokenValidationParameters.ValidIssuer = oauthOptions.Issuer;
                    opt.TokenValidationParameters.ValidateLifetime = true;
                    opt.TokenValidationParameters.ClockSkew = TimeSpan.FromSeconds(5);
                });

            builder.Services.AddCors(options =>
            {
                options.AddPolicy(name: CorsPolicy,
                    policy =>
                    {
                        policy
                            .WithOrigins(
                                builder.Configuration.GetValue<string>("LandingUrl"),
                                builder.Configuration.GetValue<string>("SecurityUrl"),
                                builder.Configuration.GetValue<string>("LandingAdminUrl"))
                            .AllowAnyMethod()
                            .AllowAnyHeader();
                    });
            });
        }

        public static void Configure(WebApplicationBuilder builder)
        {
            if (!builder.Environment.IsProduction())
            {
                builder.WebHost.UseStaticWebAssets();
            }

            var app = builder.Build();
            app.UsePathBase("/security");
            app.UseCors(CorsPolicy);

            if (builder.Environment.IsDevelopment() || builder.Environment.EnvironmentName == "Local")
            {
                app.UseSwagger();
                app.UseSwaggerUI();
                app.UseWebAssemblyDebugging();
            }

            app.UseMiddleware<ResponseErrorMiddleware>();

            app.UseBlazorFrameworkFiles();
            app.UseStaticFiles();
            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.MapHealthyChecks("/healthy");
            app.MapReadyChecks("/ready");
            app.MapErrorHandlerCheck("/errorHandler");

            app.MapControllers();
            app.MapFallbackToFile("index.html");

            app.Run();
        }
    }
}