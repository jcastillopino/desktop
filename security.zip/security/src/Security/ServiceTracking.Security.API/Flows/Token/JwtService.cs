﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ServiceTracking.Security.API.Flows.Token;

public class JwtService : IJwtService
{
    public string CreateJwt(
        IEnumerable<Claim> claims,
        string signatureKey,
        DateTime emission,
        DateTime expires,
        string audience,
        string issuer)
    {
        SymmetricSecurityKey securityKey = new(Encoding.ASCII.GetBytes(signatureKey));

        JwtSecurityTokenHandler tokenHandler = new();
        SecurityTokenDescriptor tokenDescriptor = new()
        {
            TokenType = "at+JWT",
            Subject = new ClaimsIdentity(claims),
            Issuer = issuer,
            Audience = audience,
            IssuedAt = emission,
            NotBefore = emission,
            Expires = expires,
            SigningCredentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature)
        };

        var token = tokenHandler.CreateJwtSecurityToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }
}
