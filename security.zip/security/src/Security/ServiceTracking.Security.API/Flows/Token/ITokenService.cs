using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.API.Flows.Token;

/// <summary>
/// Generates tokens based on a strategy to obtain claims
/// </summary>
public interface ITokenService
{
    Task<TokenResponseModel> BuildToken(
        User user,
        IReadOnlyCollection<Permission> permissions,
        Guid clientId,
        string scope,
        string refreshToken = null);

    public TokenResponseModel BuildToken(
        User user,
        IReadOnlyCollection<Permission> permissions,
        string client);
}