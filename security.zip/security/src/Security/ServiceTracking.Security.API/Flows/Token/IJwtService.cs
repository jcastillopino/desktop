﻿using System.Security.Claims;

namespace ServiceTracking.Security.API.Flows.Token;

public interface IJwtService
{
    string CreateJwt(
        IEnumerable<Claim> claims,
        string signatureKey,
        DateTime emission,
        DateTime expires,
        string audience,
        string issuer);
}
