using Microsoft.Extensions.Options;
using ServiceTracking.Security.API.Flows.Authorization;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Extensions;
using System.Web;
using Claim = System.Security.Claims.Claim;

namespace ServiceTracking.Security.API.Flows.Token;

public class TokenService : ITokenService
{
    private readonly string _issuer;
    private readonly OauthOptions _oauthOptions;
    private readonly IAuthRepository _authRepository;
    private readonly IJwtService _jwtService;
    public TokenService(
        IOptions<OauthOptions> oauthOptions,
        IAuthRepository authRepository,
        IJwtService jwtService)
    {
        _issuer = oauthOptions.Value.Issuer;
        _oauthOptions = oauthOptions.Value;
        _authRepository = authRepository;
        _jwtService = jwtService;
    }

    public async Task<TokenResponseModel> BuildToken(
        User user,
        IReadOnlyCollection<Permission> permissions,
        Guid clientId,
        string scope,
        string refreshToken = null)
    {
        var permissionsClaimValue = string.Join(" ", permissions.Select(p => p.NormalizedName));
        var claims = BuildAccessTokenClaims(user.Id, scope, permissionsClaimValue);

        string idToken = null;

        var accessToken = _jwtService.CreateJwt(
            claims,
            _oauthOptions.AccessTokenSecret,
            DateTime.UtcNow,
            DateTime.UtcNow.Add(_oauthOptions.AccessTokenExpiration),
            clientId.ToString().Replace("-", ""),
            _issuer);

        var newRefreshToken = await CreateRefreshToken(user.Id, clientId, scope);

            idToken = BuildIdToken(user, clientId);

        var response = new TokenResponseModel
        {
            AccessToken = accessToken,
            ExpiresIn = _oauthOptions.AccessTokenExpiration.TotalSeconds,
            RefreshToken = newRefreshToken,
            Scope = scope,
            IdToken = idToken
        };

        return response;
    }

    public TokenResponseModel BuildToken(
        User user,
        IReadOnlyCollection<Permission> permissions,
        string client)
    {
        string permissionsClaimValue = string.Join(" ", permissions.Select(p => p.NormalizedName));
        var accessTokenClaims = BuildAccessTokenClaims(
            user.Id,
            HttpUtility.UrlEncode("scope"),
            permissionsClaimValue);

        var accessTokenExpiration = DateTime.UtcNow.Add(_oauthOptions.AccessTokenExpiration);

        var accessTokenJwt = _jwtService.CreateJwt(
            accessTokenClaims,
            _oauthOptions.AccessTokenSecret,
            DateTime.UtcNow,
            accessTokenExpiration,
            client,
            _issuer);

        var response = new TokenResponseModel
        {
            AccessToken = accessTokenJwt,
            ExpiresIn = accessTokenExpiration.ToUnixTimestamp(),
            Scope = HttpUtility.UrlEncode("scope"),
        };

        return response;
    }

    private string BuildIdToken(User user, Guid clientId)
    {
        var idTokenClaims = BuildIdTokenClaims(user);
        var idTokenExpiration = DateTime.UtcNow.Add(_oauthOptions.IdTokenExpiration);
        return _jwtService.CreateJwt(
            idTokenClaims,
            _oauthOptions.IdTokenSecret,
            DateTime.UtcNow,
            idTokenExpiration,
            clientId.ToString(),
            _issuer);
    }

    private async Task<string> CreateRefreshToken(Guid userId, Guid clientId, string scope)
    {
        var refreshTokenExpiration = DateTime.UtcNow.Add(_oauthOptions.RefreshTokenExpiration);
        var refreshTokenEntity = new RefreshToken(clientId, userId, refreshTokenExpiration, scope);
        await _authRepository.AddRefreshToken(refreshTokenEntity);
        return refreshTokenEntity.Token;
    }

    private IEnumerable<Claim> BuildAccessTokenClaims(Guid userId, string scope, string permissions)
    {
        return new List<Claim>
            {
                new("jti", Guid.NewGuid().ToString()),
                new("scope", scope),
                new("sub", userId.ToString()),
                new("permissions", permissions),
            };
    }

    private IEnumerable<Claim> BuildIdTokenClaims(User user)
    {

        return new List<Claim>
            {
                new ("sub", user.Id.ToString()),
                new ("email", user.Email),
                new ("name", user.Name),
                new ("last_name", user.LastName),
            };
    }
}