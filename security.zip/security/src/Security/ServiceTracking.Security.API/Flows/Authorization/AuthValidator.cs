using Microsoft.Extensions.Options;
using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using System.Security.Cryptography;
using System.Text;

namespace ServiceTracking.Security.API.Flows.Authorization;

public class AuthValidator : IAuthValidator
{
    private readonly ILogger<AuthValidator> _logger;
    private readonly OauthOptions _oauthOptions;

    public AuthValidator(
        ILogger<AuthValidator> logger,
        IOptions<OauthOptions> oauthOptions)
    {
        _logger = logger;
        _oauthOptions = oauthOptions.Value;
    }

    public bool ValidateRedirectUri(Guid clientId, Uri redirectUri)
    {
        var client = _oauthOptions.Clients.SingleOrDefault(c => c.Id == clientId);
        if (client == null)
        {
            _logger.LogError("Invalid OAuth configuration. Unexisting client: {clientId}", clientId);
            return false;
        }

        if (!IsValidRedirectUri(client.RedirectUri, redirectUri))
        {
            _logger.LogError("Invalid OAuth configuration. Invalid redirect URI {redirectUri}", redirectUri);
            return false;
        }

        return true;
    }

    public AuthorizeError ValidateAuthorizeRequest(AuthRequest request, User user)
    {
        if (user == null)
        {
            _logger.LogError("Error validating authorize request: User not found");
            return AuthorizeErrors.UnauthorizedUser;
        }

        if (string.IsNullOrEmpty(request.State))
        {
            _logger.LogError("Error validating authorize request: State does not exist");
            return AuthorizeErrors.InvalidRequest;
        }

        if (request.ResponseType != "code")
        {
            _logger.LogError("Error validating authorize request: Unsupported response type");
            return AuthorizeErrors.UnsupportedResponseType;
        }

        var client = _oauthOptions.Clients.SingleOrDefault(c => c.Id == request.ClientId);
        if (client is null)
        {
            _logger.LogError("Error validating authorize request: Unauthorized Client");
            return AuthorizeErrors.UnauthorizedClient;
        }

        if (!IsValidRedirectUri(client.RedirectUri, request.RedirectUri))
        {
            _logger.LogError("Error validating authorize request: Redirect does not match");
            return AuthorizeErrors.UnauthorizedRedirectUri;
        }

        if (client.AllowedScopes.Any() && client.AllowedScopes.All(s => s != request.Scope))
        {
            _logger.LogError("Error validating authorize request: Scope not allowed");
            return AuthorizeErrors.InvalidScope;
        }

        return null;
    }

    public TokenError ValidateAuthorizationCodeRequest(
        AuthorizationCode authorizationCode,
        User user,
        TokenRequest request)
    {
        if (user == null)
        {
            _logger.LogError("Error validating authorize request: User not found");
            return TokenErrors.InvalidUser;
        }

        if (authorizationCode is null)
        {
            _logger.LogError("Error validating token refresh: Could not find the authorization code");
            return TokenErrors.InvalidRequest;
        }

        if (authorizationCode.ExpirationTime <= DateTime.UtcNow)
        {
            _logger.LogError("Error validating token refresh: Expired code");
            return TokenErrors.Expired;
        }

        if (request.State != authorizationCode.State)
        {
            _logger.LogError("Error validating token refresh: Mismatch on state");
            return TokenErrors.InvalidState;
        }

        if (!string.IsNullOrWhiteSpace(request.RedirectUri) && request.RedirectUri != authorizationCode.RedirectUri.ToString())
        {
            _logger.LogError("Error validating token refresh: Invalid redirect uri");
            return TokenErrors.InvalidRedirect;
        }

        if (request.ClientId != authorizationCode.ClientId.ToString().Replace("-", ""))
        {
            _logger.LogError("Error validating token refresh: Unexisting client");
            return TokenErrors.InvalidClient;
        }

        if (!ValidateCodeChallenge(authorizationCode.CodeChallenge, request.CodeVerifier, authorizationCode.CodeChallengeMethod))
        {
            _logger.LogError("Error validating token refresh: Invalid PKCE code verification");
            return TokenErrors.InvalidPKCE;
        }

        return null;
    }

    public TokenError ValidateRefreshTokenRequest(
        RefreshToken refreshToken,
        User user,
        TokenRequest request)
    {
        if (refreshToken is null)
        {
            _logger.LogDebug("Error validating refresh token: Could not find the refresh token");
            return TokenErrors.InvalidRequest;
        }

        if (user is null)
        {
            _logger.LogDebug("Error validating refresh token: Could not find the user");
            return TokenErrors.InvalidUser;
        }

        if (!refreshToken.IsLastGenerated)
        {
            _logger.LogDebug("Error validating refresh token: Refresh token reuse detection");
            return TokenErrors.TokenReuse;
        }

        if (refreshToken.ExpirationTime <= DateTime.UtcNow)
        {
            _logger.LogDebug("Error validating refresh token: Expired refresh token");
            return TokenErrors.Expired;
        }

        if (!string.IsNullOrWhiteSpace(request.Scope))
        {
            string[] originalScopes = refreshToken.Scope.Split(' ');
            string[] requestedScopes = request.Scope.Split(' ');
            if (requestedScopes.Except(originalScopes).Any())
            {
                _logger.LogDebug("Error validating refresh token: Requesting more scopes than the original access code");
                return TokenErrors.InvalidScope;
            }
        }

        return null;
    }

    private bool ValidateCodeChallenge(string codeChallenge, string codeVerifier, CodeChallengeMethod codeChallengeMethod)
        => codeChallengeMethod switch
        {
            CodeChallengeMethod.Plain => codeChallenge == codeVerifier,
            CodeChallengeMethod.S256 => codeChallenge == GetHashStr(codeVerifier),
            _ => true
        };

    private bool IsValidRedirectUri(Uri clientUri, Uri redirectUri)
    {
        return clientUri.IsBaseOf(redirectUri);
    }


    private string GetHashStr(string value) => Convert.ToHexString(SHA256.HashData(Encoding.ASCII.GetBytes(value)));

}