using ServiceTracking.Security.Infrastructure.Domain.Oauth;

namespace ServiceTracking.Security.API.Flows.Authorization;

public interface IAuthRepository
{
    /// <summary>
    /// Persists an authorization code.
    /// </summary>
    /// <param name="authorizationCode">The authorizatino code to store.</param>
    Task AddAuthorizationCode(AuthorizationCode authorizationCode);

    /// <summary>
    /// Retrieves the details and context of the authorization code.
    /// </summary>
    /// <param name="authorizationCode">The authorization code.</param>
    Task<AuthorizationCode> GetAuthorizationCode(string authorizationCode);

    /// <summary>
    /// Persists a refresh token.
    /// </summary>
    /// <param name="refreshToken">The refresh token to store.</param>
    Task AddRefreshToken(RefreshToken refreshToken);

    /// <summary>
    /// Updates an existing refresh token.
    /// </summary>
    /// <param name="refreshToken">The refresh token to store.</param>
    Task UpdateRefreshToken(RefreshToken refreshToken);

    /// <summary>
    /// Retrieves the details and context of the refresh token.
    /// </summary>
    /// <param name="refreshToken">The refresh token.</param>
    /// <returns>The refresh token.</returns>
    Task<RefreshToken> GetRefreshToken(string refreshToken);

    Task RevokeForUser(Guid userId);

    /// <summary>
    /// Deletes the refresh token.
    /// </summary>
    /// <param name="refreshToken">The refresh token.</param>
    Task DeleteRefreshTokens(RefreshToken refreshToken);

    /// <summary>
    /// Removes all the expired authorization codes.
    /// </summary>
    /// <returns>The amount of authorization codes deleted.</returns>
    Task<int> CleanExpiredAuthorizationCodes();

    /// <summary>
    /// Removes all the expired refresh tokens.
    /// </summary>
    /// <returns>The amount of tokens removed.</returns>
    Task<int> CleanExpiredRefreshTokens();
}