using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.API.Flows.Authorization;

public interface IAuthValidator
{
    bool ValidateRedirectUri(Guid clientId, Uri redirectUri);

    public AuthorizeError ValidateAuthorizeRequest(AuthRequest request, User user);

    TokenError ValidateAuthorizationCodeRequest(
        AuthorizationCode authorizationCode,
        User user,
        TokenRequest request);

    TokenError ValidateRefreshTokenRequest(
        RefreshToken refreshToken,
        User user,
        TokenRequest request);
}