using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;

namespace ServiceTracking.Security.API.Flows.Authorization;

// ReSharper disable once UnusedMember.Global
public class AuthRepository : IAuthRepository
{
    private readonly AppDbContext _context;

    public AuthRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task RevokeForUser(Guid userId)
    {
        await _context.RefreshTokens.Where(x => x.UserId == userId).ExecuteDeleteAsync();
        await _context.AuthorizationCodes.Where(x => x.UserId == userId).ExecuteDeleteAsync();
    }

    public async Task<int> CleanExpiredAuthorizationCodes()
    {
        // Raw SQL used not frequently with no params, no need to create an SPROC and not vulnerable to SQL Injection
        return await _context.Database.ExecuteSqlRawAsync("DELETE FROM [AuthorizationCode] WHERE ExpirationTime <= GETUTCDATE();");
    }

    public async Task<int> CleanExpiredRefreshTokens()
    {
        //Raw SQL used not frequently with no params, no need to create an SPROC and not vulnerable to SQL Injection
        return await _context.Database.ExecuteSqlRawAsync("DELETE FROM [RefreshToken] WHERE ExpirationTime <= GETUTCDATE();");
    }

    public async Task AddAuthorizationCode(AuthorizationCode authorizationCode)
    {

        await _context.AuthorizationCodes.AddAsync(authorizationCode);
        await _context.SaveChangesAsync();
    }

    public async Task<AuthorizationCode> GetAuthorizationCode(string authorizationCode)
    {
        var authCode = await _context.AuthorizationCodes.SingleOrDefaultAsync(c => c.Code == authorizationCode);
        _context.AuthorizationCodes.Remove(authCode);
        await _context.SaveChangesAsync();
        return authCode;
    }

    public async Task AddRefreshToken(RefreshToken refreshToken)
    {
        await _context.RefreshTokens.Where(x => x.UserId == refreshToken.UserId).ExecuteUpdateAsync(
            s => s.SetProperty(
                b => b.IsLastGenerated , b => false));
        await _context.RefreshTokens.AddAsync(refreshToken);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateRefreshToken(RefreshToken refreshToken)
    {
        _context.RefreshTokens.Update(refreshToken);
        await _context.SaveChangesAsync();
    }

    public async Task<RefreshToken> GetRefreshToken(string refreshToken)
    {
        return await _context.RefreshTokens.SingleOrDefaultAsync(r => r.Token == refreshToken);
    }

    public async Task DeleteRefreshTokens(RefreshToken refreshToken)
    {
        _context.RefreshTokens.RemoveRange(_context.RefreshTokens.Where(x => x.UserId == refreshToken.UserId));
        await _context.SaveChangesAsync();
    }
}