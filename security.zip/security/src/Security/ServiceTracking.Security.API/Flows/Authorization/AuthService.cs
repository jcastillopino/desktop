using ServiceTracking.Security.API.Flows.Authentication;
using ServiceTracking.Security.API.Flows.Token;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;

namespace ServiceTracking.Security.API.Flows.Authorization;

public class AuthService : IAuthService
{
    private readonly IAuthRepository _authRepository;
    private readonly IUserRepository _userRepository;
    private readonly ITokenService _tokenService;
    private readonly ILoginService _loginService;
    private readonly IAuthValidator _authValidator;

    public AuthService(
        IAuthRepository authRepository,
        IUserRepository userRepository,
        ITokenService tokenService,
        ILoginService loginService,
        IAuthValidator authValidator)
    {
        _authRepository = authRepository;
        _tokenService = tokenService;
        _authValidator = authValidator;
        _userRepository = userRepository;
        _loginService = loginService;

    }

    public async Task<AuthorizeResponse> Authorize(AuthRequest request, Guid userId)
    {
        var user = await _userRepository.Get(userId);
        var error = _authValidator.ValidateAuthorizeRequest(request, user);

        if (error != null)
        {
            throw new UnauthorizedAccessException();
        }

        var authorizationCode = new AuthorizationCode(
            request.State,
            request.ClientId,
            request.RedirectUri,
            request.Scope,
            DateTime.UtcNow.AddSeconds(15),
            userId,
            request.CodeChallenge,
            request.CodeChallengeMethod);

        await _authRepository.AddAuthorizationCode(authorizationCode);

        return new AuthorizeResponse
        {
            Code = authorizationCode.Code,
            State = authorizationCode.State,
        };
    }

    public async Task<TokenResponseModel> BuildToken(TokenRequest request)
    {
        return request.GrantType switch
        {
            "authorization_code" => await BuildTokenFromAuthorizationCode(request),
            "refresh_token" => await BuildTokenFromRefresh(request),
            _ => throw new UnauthorizedAccessException("Wrong grant type")
        };
    }

    public async Task<TokenResponseModel> BuildApiToken(Guid userId, string userPassword, string client)
    {
        var user = await _loginService.Login(userId, userPassword);

        if (user == null || user.IsApi == false)
        {
            throw new UnauthorizedAccessException();
        }

        var userPermissions = await _userRepository.GetPermissionsAssigned(userId);

        return _tokenService.BuildToken(user, userPermissions, client);
    }

    public async Task Delete(TokenRequest request)
    {
        var refreshToken = await _authRepository.GetRefreshToken(request.RefreshToken);
        await _authRepository.DeleteRefreshTokens(refreshToken);
    }

    private async Task<TokenResponseModel> BuildTokenFromAuthorizationCode(TokenRequest request)
    {
        var authCode = await _authRepository.GetAuthorizationCode(request.Code);

        if (authCode == null)
        {
            throw new UnauthorizedAccessException();
        }

        var user = await _userRepository.Get(authCode.UserId);
        var error = _authValidator.ValidateAuthorizationCodeRequest(authCode, user, request);

        if (error != null)
        {
            throw new UnauthorizedAccessException();
        }

        var userPermissions = await _userRepository.GetPermissionsAssigned(authCode.UserId);

        return await _tokenService.BuildToken(user, userPermissions, authCode.ClientId, authCode.Scope);
    }

    private async Task<TokenResponseModel> BuildTokenFromRefresh(TokenRequest request)
    {
        var refreshToken = await _authRepository.GetRefreshToken(request.RefreshToken);

        if (refreshToken == null)
        {
            throw new UnauthorizedAccessException();
        }

        if (!refreshToken.IsLastGenerated)
        {
            await _authRepository.RevokeForUser(refreshToken.UserId);
            throw new UnauthorizedAccessException();
        }

        var user = await _userRepository.Get(refreshToken.UserId);
        var error = _authValidator.ValidateRefreshTokenRequest(refreshToken, user, request);

        if (error != null)
        {
            throw new UnauthorizedAccessException();
        }

        var userPermissions = await _userRepository.GetPermissionsAssigned(refreshToken.UserId);

        return await _tokenService.BuildToken(
            user,
            userPermissions,
            refreshToken.ClientId,
            refreshToken.Scope,
            request.RefreshToken);
    }
}