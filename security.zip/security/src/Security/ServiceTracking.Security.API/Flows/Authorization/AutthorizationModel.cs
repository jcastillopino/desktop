﻿using ServiceTracking.Security.Infrastructure.Domain.Oauth;

namespace ServiceTracking.Security.API.Flows.Authorization;

public record struct AuthRequest(
    string ResponseType,
    Guid ClientId,
    Uri RedirectUri,
    string Scope,
    string State,
    string CodeChallenge,
    CodeChallengeMethod CodeChallengeMethod);


