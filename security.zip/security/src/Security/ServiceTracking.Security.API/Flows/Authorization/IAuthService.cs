using ServiceTracking.Security.API.Flows.Token;
using ServiceTracking.Security.DTO.Oauth;

namespace ServiceTracking.Security.API.Flows.Authorization;

public interface IAuthService
{
    Task<AuthorizeResponse> Authorize(AuthRequest request, Guid userId);

    Task<TokenResponseModel> BuildToken(TokenRequest request);

    Task<TokenResponseModel> BuildApiToken(Guid userId, string userPassword, string client);

    Task Delete(TokenRequest request);
}