﻿using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Authorization;
using ServiceTracking.Utils.Validation;

namespace ServiceTracking.Security.API.Flows.Authentication;

public class LoginService : ILoginService
{
    private readonly IUserRepository _userRepository;
    private readonly IEncryptionService _encryptionService;

    public LoginService(IUserRepository userRepository, IEncryptionService encryptionService)
    {
        _userRepository = userRepository;
        _encryptionService = encryptionService;
    }

    public async Task AddPassword(User user, string password)
    {
        var validator = new PasswordValidationAttribute();

        if (!validator.ValidatePassword( password))
        {
            var value = new ValidationValue("Password does not meet security criteria", nameof(password));
            throw new ValidationException(new List<ValidationValue> { value });
        }

        user.AddPassword(_encryptionService.Encrypt(password));
        await _userRepository.Update(user);
    }

    public async Task<User> Login(string email, string password)
    {
        var user = await _userRepository.GetByMail(email);
        if (user == null)
            throw new UnauthorizedAccessException();

        if (!_encryptionService.Verify(password, user.GetPassword()))
            throw new UnauthorizedAccessException();

        return user;
    }

    public async Task<User> Login(Guid userId, string password)
    {
        var user = await _userRepository.Get(userId);
        if (user == null)
            throw new UnauthorizedAccessException();

        if (!_encryptionService.Verify(password, user.GetPassword()))
            throw new UnauthorizedAccessException();

        return user;
    }

    public async Task ChangePassword(string email, string oldPassword, string newPassword)
    {
        var user = await _userRepository.GetByMail(email);

        var validator = new PasswordValidationAttribute();

        if (!validator.ValidatePassword(newPassword))
        {
            var value = new ValidationValue("Password does not meet security criteria", nameof(newPassword));
            throw new ValidationException(new List<ValidationValue> { value });
        }

        if (!_encryptionService.Verify(oldPassword, user.GetPassword()))
        {
            throw new Exception();
        }

        var passwordHash = _encryptionService.Encrypt(newPassword);
        user.AddPassword(passwordHash);
        await _userRepository.Update(user);
    }
}
