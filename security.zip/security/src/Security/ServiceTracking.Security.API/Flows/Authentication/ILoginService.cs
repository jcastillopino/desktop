﻿using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.API.Flows.Authentication;

public interface ILoginService
{
    Task AddPassword(User user, string password);

    Task<User> Login(string email, string password);

    Task<User> Login(Guid userId, string password);

    Task ChangePassword(string email, string oldPassword, string newPassword);
}
