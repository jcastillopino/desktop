using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.API.RBAC.Permissions.Abstracts;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;

namespace ServiceTracking.Security.API.RBAC.Permissions;

// ReSharper disable once UnusedMember.Global
public class PermissionRepository : IPermissionRepository
{
    private readonly AppDbContext _context;

    private readonly IDatabaseHelper _databaseHelper;

    public PermissionRepository(AppDbContext context, IDatabaseHelper databaseHelper)
    {
        _context = context;
        _databaseHelper = databaseHelper;
    }

    public async Task<Permission> Get(Guid id)
    {
        return await _context.ActivePermissions.FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<IReadOnlyCollection<(Guid Id, PermissionModel Permission)>> GetForUsers(IReadOnlyCollection<Guid> userIds)
    {
        var permissions = await _databaseHelper.ReadFromStoreProcedure(
            _context.Database.GetConnectionString(),
            userIds,
            "[dbo].[usp_GetPermissionsForUsers]",
            "@users",
            "dbo.UserType",
            "UserId",
            new[] { "UserId", "PermissionName", "PermissionId" });

        return MapPermission(permissions);
    }

    public async Task<IReadOnlyCollection<(Guid Id, PermissionModel Permission)>> GetForRoles(IReadOnlyCollection<Guid> roleIds)
    {
        var permissions = await _databaseHelper.ReadFromStoreProcedure(
            _context.Database.GetConnectionString(),
            roleIds,
            "[dbo].[usp_GetPermissionsForRoles]",
            "@roles",
            "dbo.RoleType",
            "RoleId",
            new[] { "RoleId", "PermissionName", "PermissionId" });

        return MapPermission(permissions);
    }

    private IReadOnlyCollection<(Guid Id, PermissionModel Permission)> MapPermission(IReadOnlyCollection<IReadOnlyCollection<string>> roles)
    {
        var result = new List<(Guid Id, PermissionModel Permission)>();

        foreach (var role in roles)
        {
            var enumerable = role as string[] ?? role.ToArray();
            result.Add((
                Guid.Parse(enumerable.ElementAt(0)),
                new PermissionModel
                {
                    Id = Guid.Parse(enumerable.ElementAt(2)),
                    Name = enumerable.ElementAt(1)
                }));
        }

        return result;
    }

    public async Task<bool> Exists(Guid id)
    {
        return await _context.ActivePermissions.AnyAsync(x => x.Id == id);
    }

    public async Task<bool> Exists(string name)
    {
        return await _context.ActivePermissions.AnyAsync(x => x.Name == name);
    }

    public async Task<bool> ExistsAll(IReadOnlyCollection<Guid> ids)
    {
        var total = await _context.ActivePermissions.CountAsync(x => ids.Contains(x.Id));
        return total == ids.Count;
    }

    public async Task<Permission> Create(Permission permission)
    {
        permission.LastUpdate = DateTime.UtcNow;
        await _context.AddAsync(permission);
        await _context.SaveChangesAsync();

        return permission;
    }

    public async Task<Permission> Update(Permission permission)
    {
        permission.LastUpdate = DateTime.UtcNow;
        _context.Permission.Update(permission);
        await _context.SaveChangesAsync();

        return permission;
    }

    public async Task Delete(Guid id)
    {
        var permission = await _context.ActivePermissions.FirstAsync(x => x.Id == id);
        permission.IsActive = false;
        _context.Permission.Update(permission);
        await _context.SaveChangesAsync();
    }

    public async Task<IReadOnlyCollection<Permission>> Search(SearchModel searchModel)
    {
        var query = searchModel.ApplySearch(_context.ActivePermissions);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<IReadOnlyCollection<Permission>> SearchByRole(SearchModel searchModel, Guid roleId)
    {
        var query = _context.ActivePermissions
            .Where(p => p.RolesPermissions
                .Any(x => x.RoleId == roleId));

        query = searchModel.ApplySearch(query);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<IReadOnlyCollection<Permission>> SearchByUser(SearchModel searchModel, Guid userId)
    {
        var query = _context.Set<Permission>()
            .Where(p => p.UserPermissions
                .Any(x => x.UserId == userId));

        query = searchModel.ApplySearch(query);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<int> Count(SearchModel searchModel)
    {
        var query = searchModel.ApplyCount(_context.ActivePermissions);
        return await query.CountAsync();
    }

    public async Task<int> CountByRole(SearchModel searchModel, Guid roleId)
    {
        var query = _context.ActivePermissions
            .Where(p => p.RolesPermissions
                .Any(x => x.RoleId == roleId));

        query = searchModel.ApplyCount(query);
        return await query.CountAsync();
    }

    public async Task<int> CountByUser(SearchModel searchModel, Guid userId)
    {
        var query = _context.ActivePermissions
            .Where(p => p.UserPermissions
                .Any(x => x.UserId == userId));

        query = searchModel.ApplyCount(query);
        return await query.CountAsync();
    }
}