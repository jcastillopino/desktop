namespace ServiceTracking.Security.API.RBAC.Permissions;

public class PermissionModel
{
    public Guid Id { get; set; }

    public string Name { get; set; }

    public DateTimeOffset LastUpdate { get; set; }

    public IEnumerable<string> Users { get; set; }

    public IEnumerable<string> Roles { get; set; }

}