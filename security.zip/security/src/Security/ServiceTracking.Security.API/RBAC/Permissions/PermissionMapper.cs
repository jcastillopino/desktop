using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.API.RBAC.Permissions;

public static class PermissionMapper
{
    public static Permission ToEntity(this PermissionAddDto dto)
    {
        return new Permission(dto.Name);
    }

    public static PermissionRecord ToDto(this Permission entity)
    {
        return new PermissionRecord
        {
            Id = entity.Id,
            Name = entity.Name,
            LastUpdate = entity.LastUpdate
        };
    }

    public static IReadOnlyCollection<PermissionRecord> ToDto(this IReadOnlyCollection<PermissionModel> permissions)
    {
        var permissionsResult = new List<PermissionRecord>();

        foreach (var permission in permissions)
        {
            permissionsResult.Add(new PermissionRecord
            {
                Id = permission.Id,
                Name = permission.Name,
                LastUpdate = permission.LastUpdate,
                Roles = permission.Roles,
                Users = permission.Users
            });
        }

        return permissionsResult;
    }
}