﻿using ServiceTracking.Security.API.RBAC.Permissions.Abstracts;
using ServiceTracking.Security.API.RBAC.Roles;
using ServiceTracking.Security.API.RBAC.Roles.Abstracts;
using ServiceTracking.Security.API.RBAC.Users;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;
using ServiceTracking.Utils.Exceptions;
using ServiceTracking.Utils.Extensions;

namespace ServiceTracking.Security.API.RBAC.Permissions;
public class PermissionService : IPermissionService
{
    private readonly IPermissionRepository _permissionRepository;

    private readonly IRoleRepository _roleRepository;

    private readonly IUserRepository _userRepository;

    public PermissionService(
        IPermissionRepository permissionRepository,
        IRoleRepository roleRepository,
        IUserRepository userRepository)
    {
        _permissionRepository = permissionRepository;
        _roleRepository = roleRepository;
        _userRepository = userRepository;
    }

    public async Task<Permission> Create(Permission permission)
    {
        if (await _permissionRepository.Exists(permission.Name))
        {
            throw new ConflictException(nameof(permission.Name));
        }

        return await _permissionRepository.Create(permission);
    }

    public async Task Update(Guid id, string name)
    {
        var permission = await _permissionRepository.Get(id);

        if (permission == null)
            throw new EntityNotFoundException(id.ToString());

        permission.Name = name;

        await _permissionRepository.Update(permission);
    }

    public async Task<(IReadOnlyCollection<PermissionModel> Data, int Count)> Search(SearchModel searchModel)
    {
        NormalizeSearchModel(searchModel);

        var permissions = await _permissionRepository.Search(searchModel);
        var permissionIds = permissions.Select(x => x.Id).ToList();

        var countTask = _permissionRepository.Count(searchModel);
        var rolesTask = _roleRepository.GetForPermissions(permissionIds);
        var usersTask = _userRepository.GetForPermissions(permissionIds);

        await Task.WhenAll(rolesTask, usersTask, countTask);

        return (BuildSearchModel(permissions, await rolesTask, await usersTask), await countTask);
    }

    public async Task<(IReadOnlyCollection<PermissionModel> Data, int Count)>
        SearchByRole(SearchModel searchModel, Guid roleId)
    {
        NormalizeSearchModel(searchModel);

        var permissions = await _permissionRepository.SearchByRole(searchModel, roleId);
        var countTask = _permissionRepository.CountByRole(searchModel, roleId);

        return (BuildSimpleSearchModel(permissions), await countTask);
    }


    public async Task<(IReadOnlyCollection<PermissionModel> Data, int Count)>
        SearchByUser(SearchModel searchModel, Guid userId)
    {
        NormalizeSearchModel(searchModel);

        var permissions = await _permissionRepository.SearchByUser(searchModel, userId);
        var countTask = _permissionRepository.CountByUser(searchModel, userId);

        return (BuildSimpleSearchModel(permissions), await countTask);
    }

    private List<PermissionModel> BuildSearchModel(
        IReadOnlyCollection<Permission> permissions,
      IReadOnlyCollection<(Guid Id, RoleModel Role)> permissionRoles,
      IReadOnlyCollection<(Guid Id, UserModel User)> permissionUsers)
    {
        var result = new List<PermissionModel>();

        foreach (var per in permissions)
        {
            result.Add(new PermissionModel
            {
                Name = per.Name,
                LastUpdate = per.LastUpdate,
                Id = per.Id,
                Roles = permissionRoles
                    .Where(x => x.Id == per.Id)
                    .Select(x => x.Role.Name)
                    .ToList(),
                Users = permissionUsers
                    .Where(x => x.Id == per.Id)
                    .Select(x => x.User.Name)
                    .ToList()
            });
        }

        return result;
    }

    private List<PermissionModel> BuildSimpleSearchModel(
        IReadOnlyCollection<Permission> permissions)
    {
        var result = new List<PermissionModel>();

        foreach (var per in permissions)
        {
            result.Add(new PermissionModel
            {
                Name = per.Name,
                LastUpdate = per.LastUpdate,
                Id = per.Id
            });
        }

        return result;
    }

    private void NormalizeSearchModel(SearchModel searchModel)
    {
        searchModel.AdvancedFilterModels ??= new List<AdvancedFilterModel>();

        searchModel.AdvancedFilterModels.Add(new AdvancedFilterModel
        {
            Column = "IsActive",
            Value = "true",
            Operator = FilterOperator.Equals,
            Type = CellDataType.Bool
        });

        var filters = searchModel.AdvancedFilterModels.Where(x => x.Column == "Name");

        foreach (var filter in filters)
        {
            filter.Column = "NormalizedName";
            filter.Value = filter.Value.Standarize();
        }
    }
}
