﻿using ServiceTracking.Security.API.RBAC.Permissions;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;

namespace ServiceTracking.Security.API.RBAC.Permissions.Abstracts;

public interface IPermissionService
{
    Task<Permission> Create(Permission permission);

    Task Update(Guid id, string name);

    Task<(IReadOnlyCollection<PermissionModel> Data, int Count)> Search(SearchModel searchModel);

    Task<(IReadOnlyCollection<PermissionModel> Data, int Count)> SearchByRole(SearchModel searchModel, Guid roleId);

    Task<(IReadOnlyCollection<PermissionModel> Data, int Count)> SearchByUser(SearchModel searchModel, Guid userId);
}
