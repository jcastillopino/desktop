using ServiceTracking.Security.API.RBAC.Permissions;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;

namespace ServiceTracking.Security.API.RBAC.Permissions.Abstracts;

public interface IPermissionRepository
{
    Task<Permission> Get(Guid id);

    Task<IReadOnlyCollection<(Guid Id, PermissionModel Permission)>> GetForUsers(IReadOnlyCollection<Guid> userIds);

    Task<IReadOnlyCollection<(Guid Id, PermissionModel Permission)>> GetForRoles(IReadOnlyCollection<Guid> roleIds);

    Task<bool> Exists(Guid id);

    Task<bool> Exists(string name);

    Task<bool> ExistsAll(IReadOnlyCollection<Guid> ids);

    Task<Permission> Create(Permission permission);

    Task<Permission> Update(Permission permission);

    Task Delete(Guid permissionId);

    Task<IReadOnlyCollection<Permission>> Search(SearchModel searchModel);

    Task<IReadOnlyCollection<Permission>> SearchByRole(SearchModel searchModel, Guid roleId);

    Task<IReadOnlyCollection<Permission>> SearchByUser(SearchModel searchModel, Guid roleId);

    Task<int> Count(SearchModel searchModel);

    Task<int> CountByRole(SearchModel searchModel, Guid roleId);

    Task<int> CountByUser(SearchModel searchModel, Guid roleId);
}