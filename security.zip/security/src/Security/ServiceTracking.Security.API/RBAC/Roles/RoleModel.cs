namespace ServiceTracking.Security.API.RBAC.Roles;

public class RoleModel
{
    public Guid Id { get; set; }

    public string Name { get; set; }

    public DateTimeOffset LastUpdate { get; set; }

    public IEnumerable<string> Users { get; set; }

    public IEnumerable<string> Permissions { get; set; }
}