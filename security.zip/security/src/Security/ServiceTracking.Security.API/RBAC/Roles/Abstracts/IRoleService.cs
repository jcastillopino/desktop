﻿using ServiceTracking.Security.API.RBAC.Roles;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;

namespace ServiceTracking.Security.API.RBAC.Roles.Abstracts;

public interface IRoleService
{
    Task<Role> Create(Role role);

    Task Update(Guid roleId, string name, IReadOnlyCollection<Guid> permissions);

    Task<(IReadOnlyCollection<RoleModel> Data, int Count)> Search(SearchModel searchModel);

    Task<(IReadOnlyCollection<RoleModel> Data, int Count)> SearchByUser(SearchModel searchModel, Guid userId);

    Task<(IReadOnlyCollection<RoleModel> Data, int Count)> SearchByPermission(SearchModel searchModel, Guid permissionId);
}
