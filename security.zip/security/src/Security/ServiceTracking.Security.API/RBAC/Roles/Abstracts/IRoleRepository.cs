using ServiceTracking.Security.API.RBAC.Roles;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;

namespace ServiceTracking.Security.API.RBAC.Roles.Abstracts;
public interface IRoleRepository
{
    Task<Role> Get(Guid id);

    Task<IReadOnlyCollection<Role>> Get();

    Task<IReadOnlyCollection<Permission>> GetRolePermissions(Guid roleId);

    Task<IReadOnlyCollection<(Guid Id, RoleModel Role)>> GetForPermissions(IReadOnlyCollection<Guid> permissionIds);

    Task<IReadOnlyCollection<(Guid Id, RoleModel Role)>> GetForUsers(IReadOnlyCollection<Guid> userIds);

    Task<bool> Exists(Guid id);

    Task<bool> Exists(string name);

    Task<bool> ExistsAll(IReadOnlyCollection<Guid> ids);

    Task<Role> Create(Role role);

    Task<Role> Update(Role role);

    Task Delete(Guid roleId);

    Task<IReadOnlyCollection<Role>> Search(SearchModel searchModel);

    Task<IReadOnlyCollection<Role>> SearchByUser(SearchModel searchModel, Guid userId);

    Task<IReadOnlyCollection<Role>> SearchByPermission(SearchModel searchModel, Guid permissionId);

    Task<int> Count(SearchModel searchModel);

    Task<int> CountByUser(SearchModel searchModel, Guid userId);

    Task<int> CountByPermission(SearchModel searchModel, Guid permissionId);
}
