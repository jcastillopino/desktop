﻿using ServiceTracking.Security.API.RBAC.Permissions;
using ServiceTracking.Security.API.RBAC.Permissions.Abstracts;
using ServiceTracking.Security.API.RBAC.Roles.Abstracts;
using ServiceTracking.Security.API.RBAC.Users;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;
using ServiceTracking.Utils.Exceptions;
using ServiceTracking.Utils.Extensions;

namespace ServiceTracking.Security.API.RBAC.Roles;
public class RoleService : IRoleService
{
    private readonly IPermissionRepository _permissionRepository;

    private readonly IRoleRepository _roleRepository;

    private readonly IUserRepository _userRepository;

    public RoleService(
        IRoleRepository roleRepository,
        IPermissionRepository permissionRepository,
        IUserRepository userRepository)
    {
        _permissionRepository = permissionRepository;
        _roleRepository = roleRepository;
        _userRepository = userRepository;
    }

    public async Task<Role> Create(Role role)
    {
        if (await _roleRepository.Exists(role.Name))
            throw new ConflictException(role.Name);

        if (!await _permissionRepository.ExistsAll(role.GetPermissionIds()))
            throw new EntityNotFoundException(nameof(role.RolesPermissions));

        if (!await _userRepository.ExistsAll(role.GetUserIds()))
            throw new EntityNotFoundException(nameof(role.RolesPermissions));

        return await _roleRepository.Create(role);
    }

    public async Task Update(Guid roleId, string name, IReadOnlyCollection<Guid> permissions)
    {
        permissions ??= new List<Guid>();

        var role = await _roleRepository.Get(roleId);

        if (role == null)
            throw new EntityNotFoundException(roleId.ToString());

        if (!await _permissionRepository.ExistsAll(permissions))
            throw new EntityNotFoundException(roleId + " permissions");

        role.Name = name;

        UpdateRolePermissions(permissions, role);

        await _roleRepository.Update(role);
    }

    private static void UpdateRolePermissions(IReadOnlyCollection<Guid> permissions, Role role)
    {
        var added = permissions
            .Where(p => role.RolesPermissions.All(p2 => p2.PermissionId != p))
            .ToList();

        var deleted = role.RolesPermissions
            .Where(p => permissions.All(p2 => p2 != p.PermissionId))
            .Select(x => x.PermissionId).ToList();

        foreach (var permission in added)
        {
            role.RolesPermissions.Add(new RolePermission { PermissionId = permission });
        }

        foreach (var permission in deleted)
        {
            var permissionDelete = role.RolesPermissions.First(x => x.PermissionId == permission);
            role.RolesPermissions.Remove(permissionDelete);
        }
    }

    public async Task<(IReadOnlyCollection<RoleModel> Data, int Count)> Search(SearchModel searchModel)
    {
        NormalizeSearchModel(searchModel);

        var roles = await _roleRepository.Search(searchModel);
        var roleIds = roles.Select(x => x.Id).ToList();

        var countTask = _roleRepository.Count(searchModel);
        var permissionTask = _permissionRepository.GetForRoles(roleIds);
        var usersTask = _userRepository.GetForRoles(roleIds);

        await Task.WhenAll(permissionTask, usersTask, countTask);

        return (BuildSearchModel(roles, await permissionTask, await usersTask), await countTask);
    }

    public async Task<(IReadOnlyCollection<RoleModel> Data, int Count)> SearchByUser(SearchModel searchModel, Guid userId)
    {
        NormalizeSearchModel(searchModel);

        var roles = await _roleRepository.SearchByUser(searchModel, userId);
        var countTask = _roleRepository.CountByUser(searchModel, userId);

        return (BuildSimpleSearchModel(roles), await countTask);
    }

    public async Task<(IReadOnlyCollection<RoleModel> Data, int Count)> SearchByPermission(SearchModel searchModel, Guid permissionId)
    {
        NormalizeSearchModel(searchModel);

        var roles = await _roleRepository.SearchByPermission(searchModel, permissionId);
        var countTask = _roleRepository.CountByPermission(searchModel, permissionId);

        return (BuildSimpleSearchModel(roles), await countTask);
    }

    private List<RoleModel> BuildSearchModel(
        IReadOnlyCollection<Role> roles,
        IReadOnlyCollection<(Guid Id, PermissionModel Permissions)> rolePermissions,
        IReadOnlyCollection<(Guid Id, UserModel User)> roleUsers)
    {
        var result = new List<RoleModel>();

        foreach (var role in roles)
        {
            result.Add(new RoleModel
            {
                Name = role.Name,
                LastUpdate = role.LastUpdate,
                Id = role.Id,
                Permissions = rolePermissions
                    .Where(x => x.Id == role.Id)
                    .Select(x => x.Permissions.Name)
                    .ToList(),
                Users = roleUsers
                    .Where(x => x.Id == role.Id)
                    .Select(x => x.User.Name)
                    .ToList()
            });
        }

        return result;
    }

    private List<RoleModel> BuildSimpleSearchModel(IEnumerable<Role> roles)
    {
        var result = new List<RoleModel>();

        foreach (var role in roles)
        {
            result.Add(new RoleModel
            {
                Name = role.Name,
                Id = role.Id
            });
        }

        return result;
    }

    private void NormalizeSearchModel(SearchModel searchModel)
    {
        if (searchModel.AdvancedFilterModels == null)
            searchModel.AdvancedFilterModels = new List<AdvancedFilterModel>();

        searchModel.AdvancedFilterModels.Add(new AdvancedFilterModel
        {
            Column = "IsActive",
            Value = "true",
            Operator = FilterOperator.Equals,
            Type = CellDataType.Bool
        });

        var filters = searchModel.AdvancedFilterModels.Where(x => x.Column == "Name");

        foreach (var filter in filters)
        {
            filter.Column = "NormalizedName";
            filter.Value = filter.Value.Standarize();
        }
    }
}
