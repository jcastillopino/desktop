using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.API.RBAC.Roles.Abstracts;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;
using ServiceTracking.Utils.Database.QueryHelpers.FilterHelpers;

namespace ServiceTracking.Security.API.RBAC.Roles;

// ReSharper disable once UnusedMember.Global
public class RoleRepository : IRoleRepository
{
    private readonly AppDbContext _context;

    private readonly IDatabaseHelper _databaseHelper;

    public RoleRepository(AppDbContext context, IDatabaseHelper databaseHelper)
    {
        _context = context;
        _databaseHelper = databaseHelper;
    }

    public async Task<Role> Get(Guid id)
    {
        return await _context.ActiveRoles
            .Where(x => x.Id == id)
            .Include(x => x.RolesPermissions)
            .Include(x => x.UserRoles)
            .FirstOrDefaultAsync();
    }

    public async Task<IReadOnlyCollection<Role>> Get()
    {
        return await _context.ActiveRoles.ToListAsync();
    }

    public async Task<Role> Update(Role role)
    {
        _context.Role.Update(role);
        await _context.SaveChangesAsync();
        return role;
    }

    public async Task<IReadOnlyCollection<Permission>> GetRolePermissions(Guid roleId)
    {
        var permissions = await _context.RolePermission
            .Where(rolePermission => rolePermission.RoleId == roleId)
            .Join(_context.Permission,
                rolePermission => rolePermission.PermissionId,
                permission => permission.Id,
                (_, permission) => permission)
            .Where(p => p.IsActive)
            .ToListAsync();

        return permissions;
    }

    public async Task<bool> Exists(Guid id)
    {
        return await _context.ActiveRoles.AnyAsync(x => x.Id == id);
    }

    public async Task<bool> Exists(string name)
    {
        return await _context.ActiveRoles.AnyAsync(x => x.Name == name);
    }

    public async Task<bool> ExistsAll(IReadOnlyCollection<Guid> ids)
    {
        var total = await _context.ActiveRoles.CountAsync(x => ids.Contains(x.Id));
        return total == ids.Count;
    }

    public async Task<Role> Create(Role role)
    {
        await _context.AddAsync(role);
        await _context.SaveChangesAsync();

        return role;
    }

    public async Task Delete(Guid id)
    {
        var role = await _context.ActiveRoles.FirstAsync(x => x.Id == id);
        role.IsActive = false;
        _context.Role.Update(role);
        await _context.SaveChangesAsync();
    }

    public async Task<IReadOnlyCollection<Role>> Search(SearchModel searchModel)
    {
        var query = _context.ActiveRoles;
        query = searchModel.ApplySearch(query);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<IReadOnlyCollection<Role>> SearchByUser(SearchModel searchModel, Guid userId)
    {
        var query = _context.ActiveRoles
            .Where(p => p.UserRoles.Any(x => x.UserId == userId));

        query = searchModel.ApplySearch(query);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<IReadOnlyCollection<Role>> SearchByPermission(SearchModel searchModel, Guid permissionId)
    {
        var query = _context.ActiveRoles
            .Where(p => p.RolesPermissions.Any(x => x.PermissionId == permissionId));

        query = searchModel.ApplySearch(query);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<int> Count(SearchModel searchModel)
    {
        var query = _context.ActiveRoles;
        query = searchModel.ApplyCount(query);
        return await query.CountAsync();
    }

    public async Task<int> CountByUser(SearchModel searchModel, Guid userId)
    {
        var query = _context.ActiveRoles
            .Where(p => p.UserRoles.Any(x => x.UserId == userId));

        query = searchModel.ApplyCount(query);
        return await query.CountAsync();
    }

    public async Task<int> CountByPermission(SearchModel searchModel, Guid permissionId)
    {
        var query = _context.ActiveRoles
            .Where(p => p.RolesPermissions.Any(x => x.PermissionId == permissionId));

        query = searchModel.ApplyCount(query);
        return await query.CountAsync();
    }

    public async Task<IReadOnlyCollection<(Guid Id, RoleModel Role)>> GetForUsers(IReadOnlyCollection<Guid> userIds)
    {
        var result = new List<(Guid Id, RoleModel Role)>();

        var roles = await _databaseHelper.ReadFromStoreProcedure(
            _context.Database.GetConnectionString(),
            userIds,
            "[dbo].[usp_GetRolesForUsers]",
            "@users",
            "dbo.UserType",
            "UserId",
            new[] { "UserId", "RoleName", "RoleId" });

        foreach (var role in roles)
        {
            result.Add((
                Guid.Parse(role.ElementAt(0)),
                new RoleModel
                {
                    Id = Guid.Parse(role.ElementAt(2)),
                    Name = role.ElementAt(1)
                }));
        }

        return result;
    }

    public async Task<IReadOnlyCollection<(Guid Id, RoleModel Role)>> GetForPermissions(IReadOnlyCollection<Guid> permissionIds)
    {
        var result = new List<(Guid Id, RoleModel Role)>();

        var roles = await _databaseHelper.ReadFromStoreProcedure(
            _context.Database.GetConnectionString(),
            permissionIds,
            "[dbo].[usp_GetRolesForPermissions]",
            "@permissions",
            "dbo.PermissionType",
            "PermissionId",
            new[] { "PermissionId", "RoleName", "RoleId" });

        foreach (var role in roles)
        {
            result.Add((
                Guid.Parse(role.ElementAt(0)),
                new RoleModel
                {
                    Id = Guid.Parse(role.ElementAt(2)),
                    Name = role.ElementAt(1)
                }));
        }

        return result;
    }
}
