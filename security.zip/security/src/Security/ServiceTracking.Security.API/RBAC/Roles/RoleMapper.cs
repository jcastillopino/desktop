using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.API.RBAC.Roles;

public static class RoleMapper
{
    public static Role ToEntity(this RoleAddDto dto)
    {
        return new Role(dto.Name, dto.Permissions, dto.Users);
    }

    public static RoleRecord ToDto(this Role entity)
    {
        return new RoleRecord
        {
            Id = entity.Id,
            Name = entity.Name,
            LastUpdate = entity.LastUpdate,
            Permissions = entity.RolesPermissions.Select(x => x.PermissionId.ToString()).ToList(),
            Users = entity.UserRoles.Select(x => x.UserId.ToString()).ToList()
        };
    }

    public static IReadOnlyCollection<RoleRecord> ToDto(this IReadOnlyCollection<RoleModel> roles)
    {
        return roles.Select(role => new RoleRecord
        {
            Id = role.Id,
            Name = role.Name,
            LastUpdate = role.LastUpdate,
            Permissions = role.Permissions.ToList(),
            Users = role.Users.ToList(),
        }).ToList();
    }

    public static IReadOnlyCollection<RoleSimplifiedRecord> ToSimpleDto(this IReadOnlyCollection<RoleModel> roles)
    {
        return roles.Select(role => new RoleSimplifiedRecord
        {
            Id = role.Id,
            Name = role.Name,
            LastUpdate = DateTime.UtcNow
        }).ToList();
    }
}
