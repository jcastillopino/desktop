using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;

namespace ServiceTracking.Security.API.RBAC.Users.Abstracts;

public interface IUserRepository
{
    Task<User> Get(Guid id);

    Task<User> GetByMail(string username);

    Task<IReadOnlyCollection<Role>> GetRoles(Guid id);

    Task<IReadOnlyCollection<Permission>> GetPermissions(Guid id);

    Task<IReadOnlyCollection<Permission>> GetPermissionsAssigned(Guid id);

    Task<IReadOnlyCollection<(Guid Id, UserModel User)>> GetForPermissions(IReadOnlyCollection<Guid> permissionIds);

    Task<IReadOnlyCollection<(Guid Id, UserModel User)>> GetForRoles(IReadOnlyCollection<Guid> roleIds);

    Task<bool> Exists(string email);

    Task<bool> ExistsAll(IEnumerable<Guid> ids);

    Task<User> Create(User user);

    Task<User> Update(User user);

    Task<IReadOnlyCollection<User>> Search(SearchModel searchModel);

    Task<IReadOnlyCollection<User>> SearchByRole(SearchModel searchModel, Guid roleId);

    Task<IReadOnlyCollection<User>> SearchByPermission(SearchModel searchModel, Guid permissionId);

    Task<int> Count(SearchModel searchModel);

    Task<int> CountByRole(SearchModel searchModel, Guid roleId);

    Task<int> CountByPermission(SearchModel searchModel, Guid permissionId);

    Task<User> Delete(User user);

    Task Delete(IEnumerable<User> users);

    Task Delete(Guid permissionId);

    public Task<int> RemoveExpiredPasswordResetCodes();


}