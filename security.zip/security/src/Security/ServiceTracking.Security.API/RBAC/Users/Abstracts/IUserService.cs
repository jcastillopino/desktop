using ServiceTracking.Security.API.RBAC.Users;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;

namespace ServiceTracking.Security.API.RBAC.Users.Abstracts;

public interface IUserService
{
    Task<User> Create(User user);

    Task Update(Guid id, string name, string lastName, IReadOnlyCollection<Guid> permissions, IReadOnlyCollection<Guid> roles);

    Task<(IReadOnlyCollection<UserModel> Data, int Count)> Search(SearchModel searchModel);

    Task<(IReadOnlyCollection<UserModel> Data, int Count)> SearchByRole(SearchModel searchModel, Guid roleId);

    Task<(IReadOnlyCollection<UserModel> Data, int Count)> SearchByPermission(SearchModel searchModel, Guid permissionId);
}