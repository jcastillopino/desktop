using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Constants;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;

namespace ServiceTracking.Security.API.RBAC.Users;

public class UserRepository : IUserRepository
{
    private readonly AppDbContext _context;

    private readonly IDatabaseHelper _databaseHelper;

    public UserRepository(AppDbContext context, IDatabaseHelper databaseHelper)
    {
        _context = context;
        _databaseHelper = databaseHelper;
    }

    public async Task<User> Get(Guid id)
    {
        return await _context.ActiveUsers
            .Where(x => x.Id == id)
            .Include(x => x.UserPermissions)
            .Include(x => x.UserRoles)
            .Include(x => x.Claims)
            .FirstOrDefaultAsync();
    }

    public async Task<User> GetByMail(string username)
    {
        return await _context.ActiveUsers
            .Include(u => u.Claims)
            .FirstOrDefaultAsync(user => user.Email == username);
    }

    public async Task<IReadOnlyCollection<Permission>> GetPermissionsAssigned(Guid id)
    {
        var permissions = await _context.UserPermission
            .Where(userPermission => userPermission.UserId == id)
            .Join(_context.Permission,
                userPermission => userPermission.PermissionId,
                permission => permission.Id,
                (_, permission) => permission)
            .Where(p => p.IsActive)
            .ToListAsync();

        var roles = _context.UserRole
            .Where(userRole => userRole.UserId == id)
            .Join(_context.Role,
                userRole => userRole.RoleId,
                role => role.Id,
                (_, role) => role)
            .Where(r => r.IsActive);

        var rolesPermissions = await roles
            .Join(_context.RolePermission,
                role => role.Id,
                rolePermission => rolePermission.RoleId,
                (_, rolePermission) => rolePermission)
            .Join(_context.Permission,
                rolePermission => rolePermission.PermissionId,
                permission => permission.Id,
                (_, permission) => permission)
            .Where(p => p.IsActive)
            .ToListAsync();

        return permissions.UnionBy(rolesPermissions, p => p.Id).ToList();
    }

    public async Task<IReadOnlyCollection<Permission>> GetPermissions(Guid id)
    {
        var permissions = await _context.UserPermission
            .Where(userPermission => userPermission.UserId == id)
            .Join(_context.Permission,
                userPermission => userPermission.PermissionId,
                permission => permission.Id,
                (_, permission) => permission)
            .Where(p => p.IsActive)
            .ToListAsync();
        return permissions;
    }

    public async Task<IReadOnlyCollection<Role>> GetRoles(Guid id) 
    {
        var roles = await _context.UserRole
            .Where(userRole => userRole.UserId == id)
            .Join(_context.Role,
                userRole => userRole.RoleId,
                role => role.Id,
                (_, role) => role)
            .Where(r => r.IsActive)
            .ToListAsync();

        return roles;
    }

    public async Task<IReadOnlyCollection<(Guid Id, UserModel User)>> GetForPermissions(IReadOnlyCollection<Guid> permissionIds)
    {
        var result = new List<(Guid Id, UserModel User)>();

        var roles = await _databaseHelper.ReadFromStoreProcedure(
            _context.Database.GetConnectionString(),
            permissionIds,
            "[dbo].[usp_GetUsersForPermissions]",
            "@permissions",
            "dbo.PermissionType",
            "PermissionId",
            new[] { "Permission", "Email" });

        foreach (var role in roles)
        {
            result.Add((
                Guid.Parse(role.ElementAt(0)),
                new UserModel
                {
                    Name = role.ElementAt(1)
                }));
        }

        return result;

    }

    public async Task<IReadOnlyCollection<(Guid Id, UserModel User)>> GetForRoles(IReadOnlyCollection<Guid> roleIds)
    {
        var result = new List<(Guid Id, UserModel User)>();

        var roles = await _databaseHelper.ReadFromStoreProcedure(
            _context.Database.GetConnectionString(),
            roleIds,
            "[dbo].[usp_GetUsersForRoles]",
            "@roles",
            "dbo.RoleType",
            "RoleId",
            new[] { "RoleId", "UserName" });

        foreach (var role in roles)
        {
            result.Add((
                Guid.Parse(role.ElementAt(0)),
                new UserModel
                {
                    Name = role.ElementAt(1)
                }));
        }

        return result;
    }

    public async Task<bool> Exists(string email)
    {
        return await _context.ActiveUsers.AnyAsync(x => x.Email == email);
    }

    public async Task<bool> ExistsAll(IEnumerable<Guid> ids)
    {
        var total = await _context.User.CountAsync(x => ids.Contains(x.Id));

        return total == ids.Count();
    }

    public async Task<User> Create(User user)
    {
        user.IsActive = true;
        await _context.User.AddAsync(user);
        await _context.SaveChangesAsync();
        return user;
    }

    public async Task<User> Update(User user)
    {
        _context.User.Update(user);
        await _context.SaveChangesAsync();
        return user;
    }

    public async Task<IReadOnlyCollection<User>> Search(SearchModel searchModel)
    {
        var query = searchModel.ApplySearch(_context.ActiveUsers);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<IReadOnlyCollection<User>> SearchByPermission(SearchModel searchModel, Guid permissionId)
    {
        var query = _context.ActiveUsers
            .Where(p => p.UserPermissions.Any(x => x.PermissionId == permissionId));

        query = searchModel.ApplySearch(query);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<IReadOnlyCollection<User>> SearchByRole(SearchModel searchModel, Guid roleId)
    {
        var query = _context.ActiveUsers
            .Where(p => p.UserRoles.Any(x => x.RoleId == roleId));

        query = searchModel.ApplySearch(query);
        return await query.AsNoTracking().ToListAsync();
    }

    public async Task<int> Count(SearchModel searchModel)
    {
        var query = _context.ActiveUsers;
        query = searchModel.ApplySearch(query);
        return await query.CountAsync();
    }

    public async Task<int> CountByRole(SearchModel searchModel, Guid roleId)
    {
        var query = _context.ActiveUsers
            .Where(p => p.UserRoles.Any(x => x.RoleId == roleId));

        query = searchModel.ApplySearch(query);
        return await query.CountAsync();
    }

    public async Task<int> CountByPermission(SearchModel searchModel, Guid permissionId)
    {
        var query = _context.ActiveUsers
            .Where(p => p.UserPermissions.Any(x => x.PermissionId == permissionId));

        query = searchModel.ApplySearch(query);
        return await query.CountAsync();
    }

    public async Task<User> Delete(User user)
    {
        var removedUser = _context.User.Remove(user).Entity;
        await _context.SaveChangesAsync();
        return removedUser;
    }

    public async Task Delete(IEnumerable<User> users)
    {
        _context.User.RemoveRange(users);
        await _context.SaveChangesAsync();
    }

    public async Task Delete(Guid id)
    {
        var user = await _context.User.FirstAsync(x => x.Id == id && x.IsActive);
        user.IsActive = false;
        user.LastUpdate = DateTime.UtcNow;
        _context.User.Update(user);
        await _context.SaveChangesAsync();
    }

    public async Task<int> RemoveExpiredPasswordResetCodes()
    {
        var limitTime = DateTime.UtcNow.AddMinutes(-10);
        var expiredCodes = _context.Claim
            .Where(c => c.NormalizedName == ClaimTypes.ResetPasswordCode
            && c.LastUpdate <= limitTime);

        _context.Claim.RemoveRange(expiredCodes);
        await _context.SaveChangesAsync();
        return expiredCodes.Count();
    }
}