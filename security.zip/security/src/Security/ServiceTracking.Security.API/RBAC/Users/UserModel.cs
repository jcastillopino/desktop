namespace ServiceTracking.Security.API.RBAC.Users;

public class UserModel
{
    public Guid Id { get; set; }

    public string Name { get; set; }

    public string LastName { get; set; }

    public string Email { get; set; }

    public DateTimeOffset LastUpdate { get; set; }

    public IEnumerable<string> Permissions { get; set; }

    public IEnumerable<string> Roles { get; set; }
}