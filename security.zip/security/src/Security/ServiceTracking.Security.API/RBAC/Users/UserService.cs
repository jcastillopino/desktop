using ServiceTracking.Security.API.RBAC.Permissions;
using ServiceTracking.Security.API.RBAC.Permissions.Abstracts;
using ServiceTracking.Security.API.RBAC.Roles;
using ServiceTracking.Security.API.RBAC.Roles.Abstracts;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database.QueryHelpers;
using ServiceTracking.Utils.Exceptions;
using ServiceTracking.Utils.Extensions;

namespace ServiceTracking.Security.API.RBAC.Users;

public class UserService : IUserService
{
    private readonly IUserRepository _userRepository;
    private readonly IPermissionRepository _permissionRepository;
    private readonly IRoleRepository _roleRepository;

    public UserService(
        IUserRepository userRepository,
        IPermissionRepository permissionRepository,
        IRoleRepository roleRepository)
    {
        _userRepository = userRepository;
        _permissionRepository = permissionRepository;
        _roleRepository = roleRepository;
    }

    public async Task<User> Create(User user)
    {
        if (await _userRepository.Exists(user.Email))
            throw new ConflictException(user.Email);

        if (!await _permissionRepository.ExistsAll(user.GetPermissionIds()))
            throw new EntityNotFoundException(nameof(user.UserPermissions));

        if (!await _roleRepository.ExistsAll(user.GetRolesIds()))
            throw new EntityNotFoundException(nameof(user.UserRoles));

        return await _userRepository.Create(user);
    }

    public async Task Update(
        Guid id,
        string name,
        string lastName,
        IReadOnlyCollection<Guid> permissions,
        IReadOnlyCollection<Guid> roles)
    {
        permissions ??= new List<Guid>();
        roles ??= new List<Guid>();

        var user = await _userRepository.Get(id);

        if (user == null)
            throw new EntityNotFoundException(id.ToString());

        if (!await _permissionRepository.ExistsAll(permissions))
            throw new EntityNotFoundException(id + " permissions");

        if (!await _roleRepository.ExistsAll(roles))
            throw new EntityNotFoundException(id + " roles");

        user.Name = name;
        user.LastName = lastName;

        UpdateUserPermissions(permissions, user);
        UpdateUserRoles(roles, user);

        await _userRepository.Update(user);
    }

    private void UpdateUserPermissions(IReadOnlyCollection<Guid> permissions, User user)
    {
        var added = permissions
            .Where(p => user.UserPermissions.All(p2 => p2.PermissionId != p))
            .ToList();

        var deleted = user.UserPermissions
            .Where(p => permissions.All(p2 => p2 != p.PermissionId))
            .Select(x => x.PermissionId).ToList();

        foreach (var permission in added)
        {
            user.UserPermissions.Add(new UserPermission() { PermissionId = permission });
        }

        foreach (var permission in deleted)
        {
            var permissionDelete = user.UserPermissions.First(x => x.PermissionId == permission);
            user.UserPermissions.Remove(permissionDelete);
        }
    }

    private void UpdateUserRoles(IReadOnlyCollection<Guid> roles, User user)
    {
        var added = roles
            .Where(p => user.UserRoles.All(p2 => p2.RoleId != p))
            .ToList();

        var deleted = user.UserRoles
            .Where(p => roles.All(p2 => p2 != p.RoleId))
            .Select(x => x.RoleId).ToList();

        foreach (var role in added)
        {
            user.UserRoles.Add(new UserRole { RoleId = role });
        }

        foreach (var role in deleted)
        {
            var roleDelete = user.UserRoles.First(x => x.RoleId == role);
            user.UserRoles.Remove(roleDelete);
        }
    }

    public async Task<(IReadOnlyCollection<UserModel> Data, int Count)> Search(SearchModel searchModel)
    {
        NormalizeSearchModel(searchModel);

        var users = await _userRepository.Search(searchModel);
        var userIds = users.Select(x => x.Id).ToList();

        var countTask = _userRepository.Count(searchModel);
        var permissionTask = _permissionRepository.GetForUsers(userIds);
        var roleTask = _roleRepository.GetForUsers(userIds);

        await Task.WhenAll(permissionTask, roleTask, countTask);

        return (BuildSearchModel(users, await permissionTask, await roleTask), await countTask);
    }

    public async Task<(IReadOnlyCollection<UserModel> Data, int Count)> SearchByRole(
        SearchModel searchModel, 
        Guid roleId)
    {
        NormalizeSearchModel(searchModel);

        var users = await _userRepository.SearchByRole(searchModel, roleId);
        var countTask = _userRepository.CountByRole(searchModel, roleId);

        return (BuildSimpleSearchModel(users), await countTask);
    }

    public async Task<(IReadOnlyCollection<UserModel> Data, int Count)> SearchByPermission(
        SearchModel searchModel, 
        Guid permissionId)
    {
        NormalizeSearchModel(searchModel);

        var users = await _userRepository.SearchByPermission(searchModel, permissionId);
        var countTask = _userRepository.CountByPermission(searchModel, permissionId);

        return (BuildSimpleSearchModel(users), await countTask);
    }

    private List<UserModel> BuildSearchModel(
        IReadOnlyCollection<User> users,
        IReadOnlyCollection<(Guid Id, PermissionModel Permissions)> userPermissions,
        IReadOnlyCollection<(Guid Id, RoleModel Roles)> userRoles)
    {
        var result = new List<UserModel>();

        foreach (var user in users)
        {
            result.Add(new UserModel
            {
                Name = user.Name,
                LastUpdate = user.LastUpdate,
                Id = user.Id,
                LastName = user.LastName,
                Email = user.Email,
                Permissions = userPermissions
                    .Where(x => x.Id == user.Id)
                    .Select(x => x.Permissions.Name)
                    .ToList(),
                Roles = userRoles
                    .Where(x => x.Id == user.Id)
                    .Select(x => x.Roles.Name)
                    .ToList()
            });
        }

        return result;
    }

    private List<UserModel> BuildSimpleSearchModel(IEnumerable<User> users)
    {
        var result = new List<UserModel>();

        foreach (var user in users)
        {
            result.Add(new UserModel
            {
                Name = user.Name,
                Id = user.Id,
                LastUpdate = user.LastUpdate,
                Email = user.Email,
                LastName = user.LastName
            });
        }

        return result;
    }

    private void NormalizeSearchModel(SearchModel searchModel)
    {
        searchModel.AdvancedFilterModels ??= new List<AdvancedFilterModel>();

        searchModel.AdvancedFilterModels.Add(new AdvancedFilterModel
        {
            Column = "IsActive",
            Value = "true",
            Operator = FilterOperator.Equals,
            Type = CellDataType.Bool
        });

        var filters = searchModel.AdvancedFilterModels.Where(x => x.Column == "Name");

        foreach (var filter in filters)
        {
            filter.Column = "NormalizedName";
            filter.Value = filter.Value.Standarize();
        }

        filters = searchModel.AdvancedFilterModels.Where(x => x.Column == "LastName");

        foreach (var filter in filters)
        {
            filter.Column = "NormalizedLastName";
            filter.Value = filter.Value.Standarize();
        }

        filters = searchModel.AdvancedFilterModels.Where(x => x.Column == "Email");

        foreach (var filter in filters)
        {
            filter.Column = "NormalizedEmail";
            filter.Value = filter.Value.Standarize();
        }
    }
}