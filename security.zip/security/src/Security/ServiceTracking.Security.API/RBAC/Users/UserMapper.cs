using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.API.RBAC.Users;

public static class UserMapper
{
    public static User ToEntity(this UserAddDto dto) =>
        new(dto.Name, dto.LastName, dto.Email, dto.Roles, dto.Permissions);

    public static UserRecord ToDto(this User user) =>
        new()
        {
            Id = user.Id,
            Name = user.Name,
            LastName = user.LastName,
            Email = user.Email,
        };

    public static IReadOnlyCollection<UserRecord> ToDto(this IReadOnlyCollection<UserModel> users)
    {
        return users.Select(user => new UserRecord
        {
            Id = user.Id,
            Name = user.Name,
            LastName = user.LastName,
            Email = user.Email,
            LastUpdate = DateTime.UtcNow,
            Permissions = user.Permissions.ToList(),
            Roles = user.Roles.ToList()
        }).ToList();
    }

    public static IReadOnlyCollection<UserSimplifiedRecord> ToSimpleDto(this IReadOnlyCollection<UserModel> users)
    {
        return users.Select(user => new UserSimplifiedRecord
        {
            Id = user.Id,
            Name = user.Name,
            LastName = user.LastName,
            Email = user.Email,
            LastUpdate = DateTime.UtcNow
        }).ToList();
    }
}
