using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.Infrastructure.Configurations;

public class UserPermissionConfiguration : IEntityTypeConfiguration<UserPermission>
{
    public void Configure(EntityTypeBuilder<UserPermission> builder)
    {
        builder.ToTable("UserPermission");

        builder.HasKey(nameof(UserPermission.UserId), nameof(UserPermission.PermissionId));

        builder.HasOne(x => x.Permission)
                    .WithMany(x => x.UserPermissions);

        builder.HasOne(x => x.User)
            .WithMany(x => x.UserPermissions);

        builder.HasAlternateKey(c => new { c.UserId, c.PermissionId });
    }
}