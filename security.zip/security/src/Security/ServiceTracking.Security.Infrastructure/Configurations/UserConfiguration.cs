using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.Infrastructure.Configurations;

public class UserConfiguration : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.ToTable("User");
            builder.HasKey(user => user.Id);
            builder.Property(user => user.Id).ValueGeneratedOnAdd();
            builder.Property(user => user.IsActive).HasDefaultValue(false);
            builder.Property(user => user.IsAuthorized).HasDefaultValue(false);
            builder.Property(user => user.AuthorizationRequired).HasDefaultValue(false);
            builder.Property(user => user.IsApi).HasDefaultValue(false);
            builder.HasMany(user => user.Claims)
                .WithOne()
                .HasForeignKey(claim => claim.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.HasIndex(role => role.NormalizedName).HasFillFactor(90);
            builder.HasIndex(role => role.NormalizedEmail).HasFillFactor(90);
            builder.HasIndex(role => role.NormalizedLastName).HasFillFactor(90);
            builder.HasIndex(role => role.IsActive).HasFillFactor(90);
    }
    }