using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.Infrastructure.Configurations;

public class RolePermissionConfiguration : IEntityTypeConfiguration<RolePermission>
{
    public void Configure(EntityTypeBuilder<RolePermission> builder)
    {
        builder.ToTable("RolePermission");
        builder.HasKey(nameof(RolePermission.RoleId), nameof(RolePermission.PermissionId));

        builder.HasOne(x => x.Permission)
                    .WithMany(x => x.RolesPermissions);
        builder.HasOne(x => x.Role)
                   .WithMany(x => x.RolesPermissions);

        builder.HasAlternateKey(c => new { c.RoleId, c.PermissionId });


    }
}