using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.Infrastructure.Configurations;

public class PermissionConfiguration : IEntityTypeConfiguration<Permission>
{
    public void Configure(EntityTypeBuilder<Permission> builder)
    {
        builder.ToTable("Permission");
        builder.HasKey(permission => permission.Id);
        builder.Property(permission => permission.Id).ValueGeneratedOnAdd();
        builder.Property(permission => permission.IsActive).HasDefaultValue(true);

        builder.HasIndex(permission => permission.Name).HasFillFactor(90);
        builder.HasIndex(permission => permission.IsActive).HasFillFactor(90);
    }
}