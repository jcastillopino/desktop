using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.Infrastructure.Configurations;
public class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    public void Configure(EntityTypeBuilder<Role> builder)
    {
        builder.ToTable("Role");
        builder.HasKey(role => role.Id);
        builder.Property(role => role.Id).ValueGeneratedOnAdd();
        builder.Property(role => role.IsActive).HasDefaultValue(true);

        builder.HasIndex(role => role.NormalizedName).HasFillFactor(90);
        builder.HasIndex(role => role.IsActive).HasFillFactor(90);
    }
}