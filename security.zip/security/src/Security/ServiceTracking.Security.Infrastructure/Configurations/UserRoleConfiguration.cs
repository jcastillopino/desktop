using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracking.Security.Infrastructure.Configurations;

public class UserRoleConfiguration : IEntityTypeConfiguration<UserRole>
{
    public void Configure(EntityTypeBuilder<UserRole> builder)
    {
        builder.ToTable("UserRole");

        builder.HasKey(nameof(UserRole.UserId), nameof(UserRole.RoleId));

        builder.HasOne(x => x.Role)
                    .WithMany(x => x.UserRoles);

        builder.HasOne(x => x.User)
            .WithMany(x => x.UserRoles);

        builder.HasAlternateKey(c => new { c.UserId, c.RoleId });
    }
}