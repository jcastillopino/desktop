using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;

namespace ServiceTracking.Security.Infrastructure.Configurations.Oauth;

    public class RefreshTokenConfiguration : IEntityTypeConfiguration<RefreshToken>
    {
        public void Configure(EntityTypeBuilder<RefreshToken> builder)
        {
            builder.ToTable("RefreshToken");
            builder.HasKey(token => token.Id);
            builder.Property(token => token.Id).ValueGeneratedOnAdd();
        }
    }