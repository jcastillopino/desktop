using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;

namespace ServiceTracking.Security.Infrastructure.Configurations.Oauth;

    public class AuthorizationCodeConfiguration : IEntityTypeConfiguration<AuthorizationCode>
    {
        public void Configure(EntityTypeBuilder<AuthorizationCode> builder)
        {
            builder.ToTable("AuthorizationCode");
            builder.HasKey(code => code.Code);
        }
    }