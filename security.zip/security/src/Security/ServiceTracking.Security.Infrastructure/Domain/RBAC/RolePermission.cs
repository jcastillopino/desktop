using System.ComponentModel.DataAnnotations;

namespace ServiceTracking.Security.Infrastructure.Domain.RBAC;

public class RolePermission
{
    [Required]
    public Guid RoleId { get; set; }

    [Required]
    public Guid PermissionId { get; set; }

    public Role Role { get; set; }

    public Permission Permission { get; set; }
}