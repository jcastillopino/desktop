using ServiceTracking.Utils.Database.Models;
using ServiceTracking.Utils.Extensions;
using ServiceTracking.Utils.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ServiceTracking.Security.Infrastructure.Constants;

namespace ServiceTracking.Security.Infrastructure.Domain.RBAC;
public class User : Auditable
{
    private User()
    {
    }

    public User(string name, string lastName, string email)
    {
        SetName = name;
        SetLastName = lastName;
        SetEmail = email;
        Claims = new List<Claim>();
        UserPermissions = new List<UserPermission>();
        UserRoles = new List<UserRole>();

        this.Validate();
    }
    public User(
        string name, string lastName, string email,
        IEnumerable<Guid> roles,
        IEnumerable<Guid> permissions)
    {
        SetName = name;
        SetLastName = lastName;
        SetEmail = email;

        UserRoles = new List<UserRole>();
        UserPermissions = new List<UserPermission>();

        if (roles != null)
        {
            foreach (var role in roles)
            {
                UserRoles.Add(new UserRole { RoleId = role, UserId = Id });
            }
        }

        if (permissions != null)
        {
            foreach (var permission in permissions)
            {
                UserPermissions.Add(new UserPermission { PermissionId = permission, UserId = Id });
            }
        }

        this.Validate();
    }
    public User(string name, string lastName, string email, bool isAuthorized, bool authorizationRequired, bool isApi)
    {
        SetName = name;
        SetLastName = lastName;
        SetEmail = email;
        IsActive = true;
        IsAuthorized = isAuthorized;
        AuthorizationRequired = authorizationRequired;
        IsApi = isApi;
        Claims = new List<Claim>();
        UserPermissions = new List<UserPermission>();
        UserRoles = new List<UserRole>();
        this.Validate();
    }

    [Required]
    public Guid Id { get; }

    private string _name;

    [Required, MaxLength(30), MinLength(3)]
    public string Name
    {
        get => _name;
        set
        {
            SetName = value;
            this.Validate();
        }
    }

    private string SetName
    {
        set
        {
            _name = value;
            NormalizedName = _name.Standarize();
        }
    }

    [Required, MaxLength(30), MinLength(3)]
    public string NormalizedName { get; private set; }

    private string _lastName;

    [MaxLength(50)]
    public string LastName
    {
        get => _lastName;
        set
        {
            SetLastName = value;
            this.Validate();
        }
    }

    [MaxLength(50)]
    public string NormalizedLastName { get; private set; }

    [NotMapped]
    private string SetLastName
    {
        set
        {
            _lastName = value;
            NormalizedLastName = _lastName.Standarize();
        }
    }

    private string _email;

    [Required, MaxLength(50), MinLength(5)]
    public string Email
    {
        get => _email;
        set
        {
            SetEmail = value;
            this.Validate();
        }
    }

    [Required, MaxLength(50), MinLength(5)]
    public string NormalizedEmail { get; private set; }

    [NotMapped]
    private string SetEmail
    {
        set
        {
            _email = value;
            NormalizedEmail = _email.Standarize();
        }
    }

    [Required]
    public bool IsAuthorized { get; set; }

    [Required]
    public bool AuthorizationRequired { get; set; }

    [Required]
    public bool IsApi { get; set; }

    [Required]
    public bool IsActive { get; set; }

    public ICollection<Claim> Claims { get; set; }

    public IList<UserRole> UserRoles { get; set; }

    public IList<UserPermission> UserPermissions { get; set; }

    public IReadOnlyCollection<Guid> GetPermissionIds()
    {
        return UserPermissions.Select(x => x.PermissionId).ToList();
    }

    public IReadOnlyCollection<Guid> GetRolesIds()
    {
        return UserRoles.Select(x => x.RoleId).ToList();
    }

    public void AddPassword(string hash)
    {
        Claims ??= new List<Claim>();

        var existing = Claims.FirstOrDefault(x => x.NormalizedName == nameof(ClaimTypes.PasswordHash).Standarize());
        if (existing == null)
        {
            Claims.Add(new Claim(nameof(ClaimTypes.PasswordHash), hash));
        }
        else
            existing.Value = hash;
    }

    public string GetPassword()
    {
        Claims ??= new List<Claim>();
        return Claims.SingleOrDefault(c => c.NormalizedName == ClaimTypes.PasswordHash)?.Value;
    }

}