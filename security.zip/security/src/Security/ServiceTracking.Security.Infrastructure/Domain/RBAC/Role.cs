using ServiceTracking.Utils.Database.Models;
using ServiceTracking.Utils.Validation;
using System.ComponentModel.DataAnnotations;

namespace ServiceTracking.Security.Infrastructure.Domain.RBAC;
public class Role : NamedEntity
{
    public Role(string name) : base(name)
    {
        UserRoles = new List<UserRole>();
        RolesPermissions = new List<RolePermission>();
        this.Validate();
    }

    public Role(
        string name,
        IEnumerable<Guid> permissions,
        IEnumerable<Guid> users) : base(name)
    {
        UserRoles = new List<UserRole>();
        RolesPermissions = new List<RolePermission>();

        if (permissions != null)
        {
            foreach (var permission in permissions)
            {
                RolesPermissions.Add(new RolePermission { RoleId = Id, PermissionId = permission });
            }
        }

        if (users != null)
        {
            foreach (var user in users)
            {
                UserRoles.Add(new UserRole { RoleId = Id, UserId = user });
            }
        }

        this.Validate();
    }

    private Role(
        Guid id,
        string name,
        string normalizedName,
        bool isActive) : base(name, normalizedName, isActive)
    {
        Id = id;
        IsActive = isActive;
        UserRoles = new List<UserRole>();
        RolesPermissions = new List<RolePermission>();
        this.Validate();
    }

    [Required]
    public Guid Id { get; }

    public IList<UserRole> UserRoles { get; }

    public IList<RolePermission> RolesPermissions { get; }

    public IReadOnlyCollection<Guid> GetPermissionIds()
    {
        return RolesPermissions.Select(x => x.PermissionId).ToList();
    }

    public IReadOnlyCollection<Guid> GetUserIds()
    {
        return UserRoles.Select(x => x.UserId).ToList();
    }
}