using ServiceTracking.Utils.Database.Models;
using ServiceTracking.Utils.Validation;
using System.ComponentModel.DataAnnotations;

namespace ServiceTracking.Security.Infrastructure.Domain.RBAC;

public class Claim : NamedEntity
{
    public Claim(string name, string value) : base(name)
    {
        Value = value;
        this.Validate();
    }

    [Required]
    public Guid Id { get; set; }

    [Required, MaxLength(256)]
    public string Value { get; set; }

    [Required]
    public Guid UserId { get; set; }
}