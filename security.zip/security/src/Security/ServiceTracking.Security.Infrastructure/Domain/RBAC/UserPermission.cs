using System.ComponentModel.DataAnnotations;

namespace ServiceTracking.Security.Infrastructure.Domain.RBAC;

public class UserPermission
{
    [Required]
    public Guid UserId { get; set; }

    [Required]
    public Guid PermissionId { get; set; }

    public User User { get; set; }

    public Permission Permission { get; set; }
}