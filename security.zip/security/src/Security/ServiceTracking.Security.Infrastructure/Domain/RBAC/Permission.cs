using System.ComponentModel.DataAnnotations;
using ServiceTracking.Utils.Database.Models;
using ServiceTracking.Utils.Validation;

namespace ServiceTracking.Security.Infrastructure.Domain.RBAC;

public class Permission : NamedEntity
{
    public Permission(Guid id, string name) : base(name)
    {
        Id = id;
        UserPermissions = new List<UserPermission>();
        RolesPermissions = new List<RolePermission>();
        this.Validate();
    }

    public Permission(string name) : base(name)
    {
        UserPermissions = new List<UserPermission>();
        RolesPermissions = new List<RolePermission>();
        this.Validate();
    }

    private Permission(
        Guid id,
        string name,
        string normalizedName,
        bool isActive) : base(name, normalizedName, isActive)
    {
        Id = id;
        UserPermissions = new List<UserPermission>();
        RolesPermissions = new List<RolePermission>();
    }

    [Required]
    public Guid Id { get; private set; }

    public IEnumerable<UserPermission> UserPermissions { get; set; }

    public IEnumerable<RolePermission> RolesPermissions { get; set; }
}