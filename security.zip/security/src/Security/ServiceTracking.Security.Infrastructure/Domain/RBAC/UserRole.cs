using System.ComponentModel.DataAnnotations;

namespace ServiceTracking.Security.Infrastructure.Domain.RBAC;

public class UserRole
{
    [Required]
    public Guid UserId { get; set; }

    [Required]
    public Guid RoleId { get; set; }

    public User User { get; set; }

    public Role Role { get; set; }
}