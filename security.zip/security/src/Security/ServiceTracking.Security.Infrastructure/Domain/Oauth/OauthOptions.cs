namespace ServiceTracking.Security.Infrastructure.Domain.Oauth;

public class OauthOptions
{
    public IReadOnlyCollection<Client> Clients { get; set; }

    public string Issuer { get; set; }

    public string AccessTokenSecret { get; set; }

    public TimeSpan AccessTokenExpiration { get; set; }

    public string IdTokenSecret { get; set; }

    public TimeSpan IdTokenExpiration { get; set; }

    public TimeSpan RefreshTokenExpiration { get; set; }
}