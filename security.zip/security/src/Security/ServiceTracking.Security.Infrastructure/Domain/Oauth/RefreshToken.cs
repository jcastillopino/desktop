using ServiceTracking.Utils.Validation;
using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;
using System.Text;

namespace ServiceTracking.Security.Infrastructure.Domain.Oauth;

public class RefreshToken
{
    private const int TokenLength = 80;

    public RefreshToken()
    { }

    public RefreshToken(Guid clientId, Guid userId, DateTime expirationTime, string scope)
    {
        ClientId = clientId;
        UserId = userId;
        ExpirationTime = expirationTime;
        Scope = scope;
        Token = GenerateToken();
        IsLastGenerated = true;
        this.Validate();
    }

    [Required]
    public Guid Id { get; private set; }


    [Required, MinLength(TokenLength), MaxLength(TokenLength)]
    public string Token { get; private set; }

    [Required]
    public Guid ClientId { get; private set; }

    [Required]
    public Guid UserId { get; private set; }

    [Required]
    public DateTime ExpirationTime { get; private set; }

    [Required, MaxLength(256)]
    public string Scope { get; private set; }

    [Required]
    public bool IsLastGenerated { get; set; }

    public void RotateToken()
    {
        Token = GenerateToken();
    }

    private static string GenerateToken()
    {
        var validCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890.-_=/".ToCharArray();

        var sb = new StringBuilder(TokenLength);
        for (int i = 0; i < TokenLength; i++)
        {
            var charIndex = RandomNumberGenerator.GetInt32(validCharacters.Length);
            sb.Append(validCharacters[charIndex]);
        }

        return sb.ToString();
    }
}