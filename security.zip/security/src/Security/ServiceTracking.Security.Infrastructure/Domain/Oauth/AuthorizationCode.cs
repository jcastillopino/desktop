using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;
using System.Text;
using ServiceTracking.Utils.Validation;

namespace ServiceTracking.Security.Infrastructure.Domain.Oauth;

public class AuthorizationCode
{
    private const int CodeLength = 40;

    private AuthorizationCode()
    { }

    public AuthorizationCode(
        string state, 
        Guid clientId, 
        Uri redirectUri, 
        string scope, 
        DateTime expirationTime,
        Guid userId,
        string codeChallenge,
        CodeChallengeMethod codeChallengeMethod)
    {
        Code = GenerateCode();
        _state = state;
        ClientId   = clientId;
        RedirectUri = redirectUri;
        Scope = scope;
        ExpirationTime = expirationTime;
        UserId = userId;
        CodeChallengeMethod = codeChallengeMethod;
        CodeChallenge = codeChallenge;
        this.Validate();
    }

    [Required, MinLength(CodeLength), MaxLength(CodeLength)]
    public string Code { get; private set; }

    [Required]
    public Guid ClientId { get; private set; }

    [Required, MaxLength(2000)]
    public Uri RedirectUri { get; private set; }

    [Required, MaxLength(256)]
    public string Scope { get; private set; }

    private string _state;
    [Required, MaxLength(500)]
    public string State
    {
        get { return _state;}
        set
        {
            _state = value;
            this.Validate();
        }
    }

    [MaxLength(256)]
    public string CodeChallenge { get; private set; }

    public CodeChallengeMethod CodeChallengeMethod { get; private set; }

    [Required]
    public DateTime ExpirationTime { get; private set; }

    [Required]
    public Guid UserId { get; private set; }

    private static string GenerateCode()
    {
        var validCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();

        var sb = new StringBuilder(CodeLength);
        for (int i = 0; i < CodeLength; i++)
        {
            var charIndex = RandomNumberGenerator.GetInt32(validCharacters.Length);
            sb.Append(validCharacters[charIndex]);
        }

        return sb.ToString();
    }
}