using System.ComponentModel.DataAnnotations;

namespace ServiceTracking.Security.Infrastructure.Domain.Oauth;

public class Client
{
    public Client()
    {
        
    }

    [Required]
    public Guid Id { get; set; }

    [Required]
    public string Name { get; set; }

    public string Secret { get; set; }

    [Required]
    public Uri RedirectUri { get; set; }

    public IEnumerable<string> AllowedScopes { get; set; } = new List<string>();
}