namespace ServiceTracking.Security.Infrastructure.Domain.Oauth;

public enum CodeChallengeMethod
{
    None,
    Plain,
    S256
}