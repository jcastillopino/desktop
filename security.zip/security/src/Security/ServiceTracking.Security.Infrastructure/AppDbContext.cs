using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.Infrastructure.Configurations;
using ServiceTracking.Security.Infrastructure.Configurations.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.Models;

namespace ServiceTracking.Security.Infrastructure;

public class AppDbContext : DbContext
{
    private readonly string _connectionString;

    public AppDbContext(string connectionString) : base()
    {
        _connectionString= connectionString;
    }


    public AppDbContext(DbContextOptions options) : base(options) 
    {
    }

    public DbSet<Claim> Claim { get; set; }

    public DbSet<Permission> Permission { get; set; }

    public DbSet<Role> Role { get; set; }

    public DbSet<User> User { get; set; }

    public DbSet<UserRole> UserRole { get; set; }

    public DbSet<UserPermission> UserPermission { get; set; }

    public DbSet<RolePermission> RolePermission { get; set; }

    public DbSet<AuthorizationCode> AuthorizationCodes { get; set; }

    public DbSet<RefreshToken> RefreshTokens { get; set; }

    public IQueryable<Permission> ActivePermissions => Permission.Where(x => x.IsActive);

    public IQueryable<Role> ActiveRoles => Role.Where(x => x.IsActive);

    public IQueryable<User> ActiveUsers => User.Where(x => x.IsActive);

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        UpdateEntities();
        return base.SaveChangesAsync(cancellationToken);
    }

    public override int SaveChanges()
    {
        UpdateEntities();
        return base.SaveChanges();
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if(!string.IsNullOrEmpty(_connectionString))
            optionsBuilder.UseSqlServer(_connectionString);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new ClaimConfiguration());
        modelBuilder.ApplyConfiguration(new PermissionConfiguration());
        modelBuilder.ApplyConfiguration(new RoleConfiguration());
        modelBuilder.ApplyConfiguration(new UserConfiguration());
        modelBuilder.ApplyConfiguration(new UserRoleConfiguration());
        modelBuilder.ApplyConfiguration(new UserPermissionConfiguration());
        modelBuilder.ApplyConfiguration(new RolePermissionConfiguration());
        modelBuilder.ApplyConfiguration(new AuthorizationCodeConfiguration());
        modelBuilder.ApplyConfiguration(new RefreshTokenConfiguration());
        base.OnModelCreating(modelBuilder);
    }

    private void UpdateEntities()
    {
        var entities = ChangeTracker.Entries()
            .Where(x => x.State == EntityState.Added || x.State == EntityState.Modified)
            .Select(x => x.Entity);

        foreach (var entitiy in entities)
        {
            if (entitiy is Auditable auditableEntity)
            {
                var currentDateTime = DateTime.UtcNow;
                auditableEntity.LastUpdate = currentDateTime;
            }
        }

        var deletedEntities = ChangeTracker.Entries()
            .Where(x => x.State == EntityState.Deleted)
            .Select(x => x);

        foreach (var deletedEntity in deletedEntities)
        {
            if (deletedEntity.Entity.GetType().IsAssignableTo(typeof(ISoftDelete)))
            {
                ((ISoftDelete)deletedEntity.Entity).IsDeleted = true;
                deletedEntity.State = EntityState.Modified;
            }
        }
    }
}
