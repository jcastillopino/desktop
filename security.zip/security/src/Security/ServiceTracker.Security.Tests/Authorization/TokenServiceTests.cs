using Microsoft.Extensions.Options;
using Moq;
using ServiceTracking.Security.API.Flows.Authorization;
using ServiceTracking.Security.API.Flows.Token;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

#pragma warning disable CS8604 // Possible null reference argument.
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.Authorization;

public class TokenServiceTests
{
    private Mock<IAuthRepository> _authRepository;
    private Mock<IJwtService> _jwtService;
    private IOptions<OauthOptions> _authOptions;

    [SetUp]
    public void SetUp()
    {
        _authRepository = new Mock<IAuthRepository>();
        _jwtService = new Mock<IJwtService>();
        _authOptions = Options.Create(CreateBaseOptions());
    }

    private OauthOptions CreateBaseOptions()
    {
        return new OauthOptions
        {
            AccessTokenSecret = "6I8ByapoGz2FaqOUDTZyRPLrL+L7yW/tHAjojwH83YyGIjYjbYdZfPk-e-34mvrS5y1d/yH3+zD+cIqyE6OVq1XljkTmRDYSuPhF7m9NiGbfmTR6rLYvYbQqk8koibJKnBlgMJ-Bi9TlLXuh7kODAP3360QVWNdY",
            IdTokenSecret = "o/MoWfHN4+35CUJPwZLwPWvW1fHhdaWJQeXDFgQG4Iy5RwoHIlJQs7JktBBMXPEWCQOJh5BO9oTS0cyo5mAgWLJUf/2-V7R3-2gNhXiVhjLuqVYKMr3OdN/zg1IIvhtvqWdrRom27WJrnK/2JdGB9a5ZpVO4mLS0",
            Issuer = "localhost:9010",
            Clients = new List<Client>
            {
                new()
                {
                    Id = Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
                    Name = "Landing",
                    RedirectUri = new Uri("http://localhost:8080"),
                    AllowedScopes = new[] {"myscope"}

                }
            }
        };
    }

    [Test]
    public async Task BuildToken_ShouldBuildAuthFlow()
    {
        var user = new User("MyName", "MyLastName", "myEmail@mail.com");
        var permissions = new List<Permission> { new("Read"), new ("Write") };

        _jwtService.Setup(x => x.CreateJwt(
                It.IsAny<IEnumerable<System.Security.Claims.Claim>>(),
                _authOptions.Value.AccessTokenSecret,
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                "38048cf8979f4c12a0c93416da07e388",
                _authOptions.Value.Issuer
                ))
            .Returns("MyAccessCodeToken")
            .Verifiable();

        var service = new TokenService(
            _authOptions,
            _authRepository.Object,
            _jwtService.Object);

        var token = await service.BuildToken(
            user, 
            permissions,
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            "myscope");

        Assert.That(token.AccessToken, Is.EqualTo("MyAccessCodeToken"));
        Assert.True(string.IsNullOrEmpty(token.IdToken));
        Assert.False(string.IsNullOrEmpty(token.RefreshToken));
        Assert.That(token.Scope, Is.EqualTo("myscope"));

        _jwtService.VerifyAll();
        _authRepository.Verify(x => x.AddRefreshToken(It.IsAny<RefreshToken>()), Times.Once);
    }

    [Test]
    public async Task BuildToken_ShouldBuildAuthFlowWithId()
    {
        var user = new User("MyName", "MyLastName", "myEmail@mail.com");
        var permissions = new List<Permission> { new("Read"), new("Write") };
        _authOptions.Value.Clients.ElementAt(0).AllowedScopes = new[] { "openid" };

        _jwtService.Setup(x => x.CreateJwt(
                It.IsAny<IEnumerable<System.Security.Claims.Claim>>(),
                _authOptions.Value.AccessTokenSecret,
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                "38048cf8979f4c12a0c93416da07e388",
                _authOptions.Value.Issuer
            ))
            .Returns("MyAccessCodeToken")
            .Verifiable();

        _jwtService.Setup(x => x.CreateJwt(
                It.IsAny<IEnumerable<System.Security.Claims.Claim>>(),
                _authOptions.Value.IdTokenSecret,
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<string>(),
                It.IsAny<string>()
            ))
            .Returns("MyIdToken")
            .Verifiable();

        var service = new TokenService(
            _authOptions,
            _authRepository.Object,
            _jwtService.Object);

        var token = await service.BuildToken(
            user,
            permissions,
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            "openid");

        Assert.That(token.AccessToken, Is.EqualTo("MyAccessCodeToken"));
        Assert.That(token.IdToken, Is.EqualTo("MyIdToken"));
        Assert.True(token.RefreshToken != null);
        Assert.That(token.Scope, Is.EqualTo("openid"));

        _jwtService.VerifyAll();
        _authRepository.Verify(x => x.AddRefreshToken(It.IsAny<RefreshToken>()), Times.Once);
    }


    [Test]
    public async Task BuildToken_ShouldBuildRefreshFlow()
    {
        var user = new User("MyName", "MyLastName", "myEmail@mail.com");
        var permissions = new List<Permission> { new("Read"), new("Write") };

        _jwtService.Setup(x => x.CreateJwt(
                It.IsAny<IEnumerable<System.Security.Claims.Claim>>(),
                _authOptions.Value.AccessTokenSecret,
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                "38048cf8979f4c12a0c93416da07e388",
                _authOptions.Value.Issuer
            ))
            .Returns("MyAccessCodeToken")
            .Verifiable();

        var service = new TokenService(
            _authOptions,
            _authRepository.Object,
            _jwtService.Object);

        var token = await service.BuildToken(
            user,
            permissions,
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            "myscope",
            "MyRefreshToken");

        Assert.That(token.AccessToken, Is.EqualTo("MyAccessCodeToken"));
        Assert.True(string.IsNullOrEmpty(token.IdToken));
        Assert.False(string.IsNullOrEmpty(token.RefreshToken));
        Assert.True(token.RefreshToken != "MyRefreshToken");
        Assert.That(token.Scope, Is.EqualTo("myscope"));

        _jwtService.VerifyAll();
    }

    [Test]
    public void BuildToken_ShouldBuildApiToken()
    {
        var user = new User("MyName", "MyLastName", "myEmail@mail.com");
        var permissions = new List<Permission> { new("Read"), new("Write") };

        _jwtService.Setup(x => x.CreateJwt(
                It.IsAny<IEnumerable<System.Security.Claims.Claim>>(),
                _authOptions.Value.AccessTokenSecret,
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<string>(),
                _authOptions.Value.Issuer
            ))
            .Returns("MyAccessCodeToken")
            .Verifiable();

        var service = new TokenService(
            _authOptions,
            _authRepository.Object,
            _jwtService.Object);

        var token = service.BuildToken(
            user,
            permissions, 
            "38048cf8979f4c12a0c93416da07e300");

        Assert.That(token.AccessToken, Is.EqualTo("MyAccessCodeToken"));
        Assert.True(string.IsNullOrEmpty(token.IdToken));
        Assert.True(string.IsNullOrEmpty(token.RefreshToken));

        _jwtService.VerifyAll();
        _authRepository.Verify(x => x.AddRefreshToken(It.IsAny<RefreshToken>()), Times.Never);
    }
}