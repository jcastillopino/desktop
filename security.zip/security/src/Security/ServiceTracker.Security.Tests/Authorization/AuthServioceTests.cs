using Moq;
using ServiceTracking.Security.API.Flows.Authentication;
using ServiceTracking.Security.API.Flows.Authorization;
using ServiceTracking.Security.API.Flows.Token;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using System.Security.Cryptography;

#pragma warning disable CS8604 // Possible null reference argument.
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.Authorization;

public class AuthServiceTests
{
    private Mock<IAuthRepository> _authRepository;
    private Mock<IUserRepository> _userRepository;
    private Mock<IAuthValidator> _authValidator;
    private Mock<ITokenService> _tokenService;
    private Mock<ILoginService> _loginService;

    [SetUp]
    public void SetUp()
    {
        _authRepository = new Mock<IAuthRepository>();
        _authValidator = new Mock<IAuthValidator>();
        _tokenService = new Mock<ITokenService>();
        _userRepository = new Mock<IUserRepository>();
        _loginService = new Mock<ILoginService>();
    }

    private IAuthService BuildAuthService()
    {
        return new AuthService(
            _authRepository.Object,
            _userRepository.Object,
            _tokenService.Object,
            _loginService.Object,
            _authValidator.Object);
    }

    private RefreshToken CreateBaseRefreshToken()
    {
        return new RefreshToken(
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            DateTime.Parse("01/01/2024"),
            "myScope"
        );
    }

    private AuthorizationCode CreateBaseAuthCode()
    {
        return new AuthorizationCode(
            "state",
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080"),
            "myscope",
            DateTime.Parse("01/01/2024"),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            "BF5D9CDF9C1E9A533A0C61BA7ABD1066F1788AC4D2BE3B17F2D704FBC5A6E1D6",
            CodeChallengeMethod.S256
        );
    }

    private TokenRequest CreateBaseTokenRequest()
    {
        return new TokenRequest
        {
            GrantType = "authorization_code",
            Code = "11111",
            CodeVerifier = Convert.ToHexString(SHA256.HashData("verifier"u8.ToArray())),
            State = "state",
            RedirectUri = "http://localhost:8080/",
            ClientId = "38048cf8979f4c12a0c93416da07e388",
            Scope = "myscope"
        };
    }

    private AuthRequest CreateBaseRequest()
    {
        return new AuthRequest(
            "code",
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080/client"),
            "myscope",
            "state",
            "aassaa",
            CodeChallengeMethod.S256);
    }

    private IReadOnlyCollection<Permission> CreateBasePermissions()
    {
        return new List<Permission>
        {
            new("Read"),
            new("Write")
        };
    }

    [Test]
    public async Task Authorize_ShouldVerifyRequest()
    {
        var service = BuildAuthService();
        var request = CreateBaseRequest();

        _authValidator.Setup(x => x.ValidateAuthorizeRequest(request, It.IsAny<User>()))
            .Returns(null as AuthorizeError).Verifiable();
        await service.Authorize(request, Guid.NewGuid());

        _authValidator.VerifyAll();
    }

    [Test]
    public void Authorize_ShouldReturnOnValidationFailed()
    {
        var request = CreateBaseRequest();
        _authValidator.Setup(x => x.ValidateAuthorizeRequest(request, It.IsAny<User>()))
            .Returns(new AuthorizeError("asd", "asd"));

        var service = BuildAuthService();

        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.Authorize(request, Guid.NewGuid()));
        _authRepository.Verify(x => x.AddAuthorizationCode(It.IsAny<AuthorizationCode>()), Times.Never);
    }

    [Test]
    public async Task Authorize_ShouldSave()
    {
        var request = CreateBaseRequest();

        _authValidator.Setup(x => x.ValidateAuthorizeRequest(request, It.IsAny<User>()))
            .Returns(null as AuthorizeError);
        _userRepository.Setup(x => x.Get(Guid.Parse("38048cf8979f4c12a0c93416da07e300")))
            .ReturnsAsync(new User("Name", "LastName", "name@mail.com"));

        var service = BuildAuthService();
        var response = await service.Authorize(request, Guid.Parse("38048cf8979f4c12a0c93416da07e300"));

        Assert.That(response.Code, Is.Not.Null);
        Assert.That(response.Code, Is.Not.Empty);
        _authRepository.Verify(x => x.AddAuthorizationCode(It.IsAny<AuthorizationCode>()), Times.Once);
    }

    [Test]
    public async Task TokenCode_ShouldBuildAndVerify()
    {
        var request = CreateBaseTokenRequest();
        var authCode = CreateBaseAuthCode();
        var permissions = CreateBasePermissions();

        request.Code = authCode.Code;

        _authRepository.Setup(x => x.GetAuthorizationCode(authCode.Code))
            .ReturnsAsync(authCode).Verifiable();
        _authValidator.Setup(x => x.ValidateAuthorizationCodeRequest(authCode, It.IsAny<User>(),request))
            .Returns(null as TokenError).Verifiable();
        _userRepository.Setup(x => x.Get(Guid.Parse("38048cf8979f4c12a0c93416da07e300")))
            .ReturnsAsync(new User("Name", "LastName", "name@mail.com"));
        _userRepository.Setup(x => x.GetPermissionsAssigned(It.IsAny<Guid>()))
            .ReturnsAsync(permissions);

        var service = BuildAuthService();
        await service.BuildToken(request);

        _authRepository.VerifyAll();
        _authValidator.VerifyAll();
        _tokenService.Verify(x => x.BuildToken(
            It.IsAny<User>(), 
            permissions,
            authCode.ClientId, 
            authCode.Scope,
            null), Times.Once);
    }

    [Test]
    public void TokenCode_ShouldThrowExceptionValidationError()
    {
        var request = CreateBaseTokenRequest();
        var authCode = CreateBaseAuthCode();

        request.Code = authCode.Code;

        _authRepository.Setup(x => x.GetAuthorizationCode(authCode.Code))
            .ReturnsAsync(authCode).Verifiable();
        _authValidator.Setup(x => x.ValidateAuthorizationCodeRequest(authCode,It.IsAny<User>(), request))
            .Returns(TokenErrors.InvalidRequest).Verifiable();
        _userRepository.Setup(x => x.Get(Guid.Parse("38048cf8979f4c12a0c93416da07e300")))
            .ReturnsAsync(new User("Name", "LastName", "name@mail.com"));

        var service = BuildAuthService();
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.BuildToken(request));
    }

    [Test]
    public void TokenCode_ShouldThrowExceptionOnWrongCode()
    {
        var request = CreateBaseTokenRequest();
        var authCode = CreateBaseAuthCode();

        request.Code = authCode.Code;

        _authRepository.Setup(x => x.GetAuthorizationCode(authCode.Code))
            .ReturnsAsync(null as AuthorizationCode);
        _authValidator.Setup(x => x.ValidateAuthorizationCodeRequest(authCode, It.IsAny<User>(),request))
            .Returns(null as TokenError);
        _userRepository.Setup(x => x.Get(Guid.Parse("38048cf8979f4c12a0c93416da07e300")))
            .ReturnsAsync(null as User);

        var service = BuildAuthService();
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.BuildToken(request));
    }

    [Test]
    public async Task TokenRefresh_ShouldBuildAndVerify()
    {
        var request = CreateBaseTokenRequest();
        var refreshToken = CreateBaseRefreshToken();
        var permissions = CreateBasePermissions();

        request.GrantType = "refresh_token";
        request.RefreshToken = refreshToken.Token;

        _authRepository.Setup(x => x.GetRefreshToken(refreshToken.Token))
            .ReturnsAsync(refreshToken).Verifiable();
        _authValidator.Setup(x => x.ValidateRefreshTokenRequest(refreshToken,It.IsAny<User>(), request))
            .Returns(null as TokenError).Verifiable();
        _userRepository.Setup(x => x.Get(Guid.Parse("38048cf8979f4c12a0c93416da07e300")))
            .ReturnsAsync(new User("Name", "LastName", "name@mail.com"));
        _userRepository.Setup(x => x.GetPermissionsAssigned(Guid.Parse("38048cf8979f4c12a0c93416da07e300")))
            .ReturnsAsync(permissions);

        var service = BuildAuthService();
        await service.BuildToken(request);

        _authRepository.VerifyAll();
        _authValidator.VerifyAll();
        _tokenService.Verify(x => x.BuildToken(
            It.IsAny<User>(), 
            permissions,
            refreshToken.ClientId, 
            refreshToken.Scope, 
            refreshToken.Token), Times.Once);
    }

    [Test]
    public void TokenRefresh_ShouldReturnOnValidationError()
    {
        var request = CreateBaseTokenRequest();
        var refreshToken = CreateBaseRefreshToken();

        request.GrantType = "refresh_token";
        request.RefreshToken = refreshToken.Token;

        _authRepository.Setup(x => x.GetRefreshToken(refreshToken.Token))
            .ReturnsAsync(refreshToken).Verifiable();
        _authValidator.Setup(x => x.ValidateRefreshTokenRequest(refreshToken,It.IsAny<User>(), request))
            .Returns(TokenErrors.InvalidRequest).Verifiable();
        _userRepository.Setup(x => x.Get(Guid.Parse("38048cf8979f4c12a0c93416da07e300")))
            .ReturnsAsync(new User("Name","LastName","name@mail.com"));

        var service = BuildAuthService();
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.BuildToken(request));
    }

    [Test]
    public void TokenRefresh_ShouldReturnNoToken()
    {
        var request = CreateBaseTokenRequest();
        var refreshToken = CreateBaseRefreshToken();

        request.GrantType = "refresh_token";
        request.RefreshToken = refreshToken.Token;

        _authRepository.Setup(x => x.GetRefreshToken(refreshToken.Token))
            .ReturnsAsync(null as RefreshToken);
        
        var service = BuildAuthService();
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.BuildToken(request));
    }

    [Test]
    public void Token_ShouldNotAllowInvalidGrants()
    {
        var request = CreateBaseTokenRequest();
        request.GrantType = "TerribleGrantType";

        var service = BuildAuthService();
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.BuildToken(request));
    }

    [Test]
    public async Task BuildApi_ShouldBuildAndVerify()
    {
        var permissions = CreateBasePermissions();
        var user = new User("Name", "LastName", "name@mail.com")
        {
            IsApi = true
        };

        _userRepository.Setup(x => x.GetPermissionsAssigned(Guid.Parse("38048cf8979f4c12a0c93416da07e300")))
            .ReturnsAsync(permissions);
        _loginService.Setup(x => x.Login(Guid.Parse("38048cf8979f4c12a0c93416da07e300"), "MyPassword"))
            .ReturnsAsync(user);

        var service = BuildAuthService();
        await service.BuildApiToken(
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"), 
            "MyPassword", 
            "38048cf8979f4c12a0c93416da07e300");

        _authRepository.VerifyAll();
        _loginService.VerifyAll();
        _tokenService.Verify(x => x.BuildToken(
            user,
            permissions,
            "38048cf8979f4c12a0c93416da07e300"), Times.Once);
    }

    [Test]
    public void BuildApi_ShouldthrowExceptionOnWrongLogin()
    {
        var user = new User("Name", "LastName", "name@mail.com")
        {
            IsApi = true
        };

        _loginService.Setup(x => x.Login(Guid.Parse("38048cf8979f4c12a0c93416da07e300"), "MyPassword"))
            .ReturnsAsync(null as User);

        var service = BuildAuthService();
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.BuildApiToken(
            user.Id,
            "MyPassword",
            "38048cf8979f4c12a0c93416da07e300"));
    }

    [Test]
    public void BuildApi_ShouldReturnOnNonApiLogin()
    {
        var user = new User("Name", "LastName", "name@mail.com")
        {
            IsApi = false
        };

        _loginService.Setup(x => x.Login(Guid.Parse("38048cf8979f4c12a0c93416da07e300"), "MyPassword"))
            .ReturnsAsync(user);

        var service = BuildAuthService();
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.BuildApiToken(
            user.Id,
            "MyPassword",
            "38048cf8979f4c12a0c93416da07e300"));
    }
}