using Moq;
using ServiceTracking.Security.API.Flows.Authentication;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Security.Infrastructure.Constants;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Authorization;
using ServiceTracking.Utils.Validation;

// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.Authorization;

public class LoginTests
{
    [Test]
    public void Password_ShouldFailOnMaxLength()
    {
        var validator = new PasswordValidationAttribute();

        var result = validator.ValidatePassword(
            "aA1-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");

        Assert.That(result, Is.EqualTo(false));
    }

    [Test]
    public void Password_ShouldFailOnMinLength()
    {
        var validator = new PasswordValidationAttribute();

        var result = validator.ValidatePassword(
            "aA1-aaaaaaa");

        Assert.That(result, Is.EqualTo(false));
    }

    [Test]
    public void Password_ShouldFailOnNoLowerCase()
    {
        var validator = new PasswordValidationAttribute();

        var result = validator.ValidatePassword(
            "AA1-AAAAAAAAAAA");

        Assert.That(result, Is.EqualTo(false));
    }

    [Test]
    public void Password_ShouldFailOnNoUpperCase()
    {
        var validator = new PasswordValidationAttribute();

        var result = validator.ValidatePassword(
            "aa1-aaaaaaaaaa");

        Assert.That(result, Is.EqualTo(false));
    }

    [Test]
    public void Password_ShouldFailOnNoDigit()
    {
        var validator = new PasswordValidationAttribute();

        var result = validator.ValidatePassword(
            "aaA-aaaaaaaaaa");

        Assert.That(result, Is.EqualTo(false));
    }

    [Test]
    public void Password_ShouldFailOnNoSpecial()
    {
        var validator = new PasswordValidationAttribute();

        var result = validator.ValidatePassword(
            "aaA1aaaaaaaaaa");

        Assert.That(result, Is.EqualTo(false));
    }

    [Test]
    public void Password_ShouldSucceed()
    {
        var validator = new PasswordValidationAttribute();

        var result = validator.ValidatePassword(
            "aaA1aaa@aaaaaaa");

        Assert.That(result, Is.EqualTo(true));
    }

    [Test]
    public void ChangePassword_ShouldThrowExceptionOnInvalidPassword()
    {
        var userRepository = new Mock<IUserRepository>();
        var encriptionService = new Mock<IEncryptionService>();

        var user = new User("Name", "LastName", "myemail@mail.com");
        userRepository.Setup(x => x.GetByMail("myemail@mail.com")).ReturnsAsync(user);
        var service = new LoginService(userRepository.Object, encriptionService.Object);

        Assert.ThrowsAsync<ValidationException>(() => service.ChangePassword("myemail@mail.com", "oldPassword", "new"));
    }

    [Test]
    public void ChangePassword_ShouldThrowExceptionOnIncorrectPassword()
    {
        var userRepository = new Mock<IUserRepository>();
        var encriptionService = new Mock<IEncryptionService>();
        encriptionService.Setup(x =>
            x.Verify(
                It.IsAny<string>(),
                It.IsAny<string>()))
            .Returns(false);

        var user = new User("Name", "LastName", "myemail@mail.com");
        userRepository.Setup(x => x.GetByMail("myemail@mail.com")).ReturnsAsync(user);
        var service = new LoginService(userRepository.Object, encriptionService.Object);

        Assert.ThrowsAsync<Exception>(() => service.ChangePassword("myemail@mail.com", "oldPassword1*", "newPassword1*"));
    }

    [Test]
    public void Login_UserNotExistShouldThrowUnauthorized()
    {
        var userRepository = new Mock<IUserRepository>();
        var encriptionService = new Mock<IEncryptionService>();

        userRepository.Setup(x => x.GetByMail("mail@mail.com")).ReturnsAsync(null as User);

        var service = new LoginService(userRepository.Object, encriptionService.Object);
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.Login("mail@mail.com", "oldPassword1*"));
    }

    [Test]
    public void Login_IncorrectPasswordShouldThrowUnauthorized()
    {
        var userRepository = new Mock<IUserRepository>();

        var user = new User("Name", "LastName", "mail@mail.com");

        var encript = new EncryptionService();
        var passClaim = new Claim(nameof(ClaimTypes.PasswordHash), encript.Encrypt("oldPassword1*"));

        user.Claims ??= new List<Claim>();
        user.Claims.Add(passClaim);

        userRepository.Setup(x => x.GetByMail("mail@mail.com")).ReturnsAsync(user);

        var service = new LoginService(userRepository.Object, encript);
        Assert.ThrowsAsync<UnauthorizedAccessException>(() => service.Login("mail@mail.com", "oldPassword1*2"));
    }

    [Test]
    public async Task Login_ShouldUpdatePass()
    {
        var userRepository = new Mock<IUserRepository>();

        var user = new User("Name", "LastName", "mail@mail.com");

        var encript = new EncryptionService();
        var passClaim = new Claim(nameof(ClaimTypes.PasswordHash), encript.Encrypt("oldPassword1*"));

        user.Claims ??= new List<Claim>();
        user.Claims.Add(passClaim);

        userRepository.Setup(x => x.GetByMail("mail@mail.com")).ReturnsAsync(user);

        var service = new LoginService(userRepository.Object, encript);
        var returned = await service.Login("mail@mail.com", "oldPassword1*");

        Assert.That(returned.Name, Is.EqualTo("Name"));
    }

}