using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using System.Security.Cryptography;
using System.Text;
using ServiceTracking.Security.API.Flows.Authorization;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.Authorization;

public class AuthValidatorTests
{
    private Mock<ILogger<AuthValidator>> _logger;

    private IOptions<OauthOptions> _authOptions;

    private RefreshToken CreateBaseRefreshToken()
    {
        return new RefreshToken(
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            DateTime.Parse("01/01/2024"),
            "myscope"
        );
    }

    private AuthorizationCode CreateBaseAuthCode()
    {
        return new AuthorizationCode(
            "state",
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080"),
            "myscope",
            DateTime.Parse("01/01/2024"),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            "BF5D9CDF9C1E9A533A0C61BA7ABD1066F1788AC4D2BE3B17F2D704FBC5A6E1D6",
            CodeChallengeMethod.S256
        );
    }

    private TokenRequest CreateBaseTokenRequest()
    {
        return new TokenRequest {
            GrantType = "authorization_code",
            Code = "11111",
            CodeVerifier = Convert.ToHexString(SHA256.HashData(Encoding.ASCII.GetBytes("aaxx11"))),
            State = "state",
            RedirectUri = "http://localhost:8080/",
            ClientId = "38048cf8979f4c12a0c93416da07e388",
            Scope = "myscope"
        };
    }

    private OauthOptions CreateBaseOptions()
    {
        return new OauthOptions
        {
            AccessTokenSecret = "6I8ByapoGz2FaqOUDTZyRPLrL+L7yW/tHAjojwH83YyGIjYjbYdZfPk-e-34mvrS5y1d/yH3+zD+cIqyE6OVq1XljkTmRDYSuPhF7m9NiGbfmTR6rLYvYbQqk8koibJKnBlgMJ-Bi9TlLXuh7kODAP3360QVWNdY",
            IdTokenSecret = "o/MoWfHN4+35CUJPwZLwPWvW1fHhdaWJQeXDFgQG4Iy5RwoHIlJQs7JktBBMXPEWCQOJh5BO9oTS0cyo5mAgWLJUf/2-V7R3-2gNhXiVhjLuqVYKMr3OdN/zg1IIvhtvqWdrRom27WJrnK/2JdGB9a5ZpVO4mLS0",
            Issuer = "localhost:9010",
            Clients = new List<Client>
            {
                new()
                {
                    Id = Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
                    Name = "Landing",
                    RedirectUri = new Uri("http://localhost:8080"),
                    AllowedScopes = new[] {"myscope"}

                }
            }
        };
    }

    private AuthRequest CreateBaseRequest()
    {
        return new AuthRequest(
            "code",
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080/client"),
            "myscope",
            "state",
            "aassaa",
            CodeChallengeMethod.S256);
    }

    [SetUp]
    public void SetUp()
    {
        _logger = new Mock<ILogger<AuthValidator>>();
        var authoptions = CreateBaseOptions();
        _authOptions = Options.Create(authoptions);
    }

    [Test]
    public void ValidateRedirectUri_ClientShouldExist()
    {
        _logger.Setup(x => x.Log(
            LogLevel.Error, 0, 
            It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), It.IsAny<Func<It.IsAnyType, Exception, string>>()!)).Verifiable();

        var service = new AuthValidator(_logger.Object, _authOptions);

        var result = service.ValidateRedirectUri(new Guid("08048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080/client"));

        _logger.Verify();
        Assert.False(result);
    }

    [Test]
    public void ValidateRedirectUri_ShouldBeBasedOnConfig()
    {
        _logger.Setup(x => x.Log(
            LogLevel.Error, 0,
            It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), It.IsAny<Func<It.IsAnyType, Exception, string>>()!)).Verifiable();

        var service = new AuthValidator(_logger.Object, _authOptions);

        var result = service.ValidateRedirectUri(new Guid("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8081/client"));

        _logger.Verify();
        Assert.False(result);
    }

    [Test]
    public void ValidateRedirectUri_Correct()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);

        var result = service.ValidateRedirectUri(new Guid("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080/client"));

        Assert.True(result);
    }

    [Test]
    public void ValidateAuthorizeRequest_UserShouldExist()
    {
        _logger.Setup(x => x.Log(
            LogLevel.Error, 0,
            It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), It.IsAny<Func<It.IsAnyType, Exception, string>>()!)).Verifiable();

        var service = new AuthValidator(_logger.Object, _authOptions);

        var user = new User("name", "lastName", "mail@mail.com");
        var request = CreateBaseRequest();
        request.ClientId = Guid.Parse("08048cf8979f4c12a0c93416da07e388");
        var result = service.ValidateAuthorizeRequest(request, null);
        Assert.That(result.key, Is.EqualTo(AuthorizeErrors.UnauthorizedUser.key));
    }

    [Test]
    public void ValidateAuthorizeRequest_ClientShouldExist()
    {
        _logger.Setup(x => x.Log(
            LogLevel.Error, 0,
            It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), It.IsAny<Func<It.IsAnyType, Exception, string>>()!)).Verifiable();

        var service = new AuthValidator(_logger.Object, _authOptions);

        var user = new User("name","lastName", "mail@mail.com");
        var request = CreateBaseRequest();
        request.ClientId = Guid.Parse("08048cf8979f4c12a0c93416da07e388");
        var result = service.ValidateAuthorizeRequest(request, user);
        Assert.That(result.key, Is.EqualTo(AuthorizeErrors.UnauthorizedClient.key));
    }

    [Test]
    public void ValidateAuthorizeRequest_StateShouldExist()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);

        var request = CreateBaseRequest();
        request.State = null;
        var user = new User("name", "lastName", "mail@mail.com");
        var result = service.ValidateAuthorizeRequest(request, user);
        Assert.That(result.key, Is.EqualTo(AuthorizeErrors.InvalidRequest.key));
    }

    [Test]
    public void ValidateAuthorizeRequest_WrongResponseType()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var request = CreateBaseRequest();
        request.ResponseType = "refresh";

        var result = service.ValidateAuthorizeRequest(request, user);
        Assert.That(result.key, Is.EqualTo(AuthorizeErrors.UnsupportedResponseType.key));
    }

    [Test]
    public void ValidateAuthorizeRequest_WrongRedirect()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var request = CreateBaseRequest();
        request.RedirectUri = new Uri("http://servicetracker");

        var result = service.ValidateAuthorizeRequest(request, user);
        Assert.That(result.key, Is.EqualTo(AuthorizeErrors.UnauthorizedRedirectUri.key));
    }

    [Test]
    public void ValidateAuthorizeRequest_ScopeNotExists()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var request = CreateBaseRequest();
        request.Scope = "secondScope";

        var result = service.ValidateAuthorizeRequest(request, user);
        Assert.That(result.key, Is.EqualTo(AuthorizeErrors.InvalidScope.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_UserShouldExist()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var tokenRequest = CreateBaseTokenRequest();

        var result = service.ValidateAuthorizationCodeRequest(null, null, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidUser.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_AuthCodeShouldExist()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var tokenRequest = CreateBaseTokenRequest();

        var result = service.ValidateAuthorizationCodeRequest(null,user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidRequest.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_ShouldNotBeExpired()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var authCode = new AuthorizationCode(
            "state",
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080"),
            "myscope",
            DateTime.UtcNow.Subtract(new TimeSpan(0,0,0,1)),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            "aaxx11",
            CodeChallengeMethod.S256
        );
        var tokenRequest = CreateBaseTokenRequest();

        var result = service.ValidateAuthorizationCodeRequest(authCode, user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.Expired.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_ShouldHaveSameState()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var authCode = CreateBaseAuthCode();
        var tokenRequest = CreateBaseTokenRequest();
        tokenRequest.State = "myNewState";
        var result = service.ValidateAuthorizationCodeRequest(authCode,user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidState.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_ShouldHaveSameRedirect()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var authCode = CreateBaseAuthCode();
        var tokenRequest = CreateBaseTokenRequest();
        tokenRequest.RedirectUri = "http://localhost:8081";
        var result = service.ValidateAuthorizationCodeRequest(authCode,user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidRedirect.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_ShouldHaveSameClient()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var authCode = CreateBaseAuthCode();
        var tokenRequest = CreateBaseTokenRequest();
        tokenRequest.ClientId = "48048cf8979f4c12a0c93416da07e388";
        var result = service.ValidateAuthorizationCodeRequest(authCode,user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidClient.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_ShouldValidateChallengeRSA()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var authCode = CreateBaseAuthCode();
        var tokenRequest = CreateBaseTokenRequest();
        tokenRequest.CodeVerifier = Convert.ToHexString(SHA256.HashData(Encoding.ASCII.GetBytes("aaxx12")));

        var result = service.ValidateAuthorizationCodeRequest(authCode,user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidPKCE.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_ShouldBeCorrectOnRSA()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var authCode = CreateBaseAuthCode();
        var tokenRequest = CreateBaseTokenRequest();

        var result = service.ValidateAuthorizationCodeRequest(authCode, user, tokenRequest);
        Assert.IsNull(result);
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_ShouldValidateChallengePlain()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var authCode = new AuthorizationCode(
            "state",
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080"),
            "myscope",
            DateTime.UtcNow.AddMinutes(1),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            "myCodeChallenge",
            CodeChallengeMethod.Plain
        );

        var tokenRequest = CreateBaseTokenRequest();
        tokenRequest.CodeVerifier = "myCodeChallenge2";

        var result = service.ValidateAuthorizationCodeRequest(authCode,user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidPKCE.key));
    }

    [Test]
    public void ValidateAuthorizationCodeRequest_ShouldBeCorrectPlain()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var authCode = new AuthorizationCode(
            "state",
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost:8080"),
            "myscope",
            DateTime.UtcNow.AddMinutes(1),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            "myCodeChallenge",
            CodeChallengeMethod.Plain
        );

        var tokenRequest = CreateBaseTokenRequest();
        tokenRequest.CodeVerifier = "myCodeChallenge";

        var result = service.ValidateAuthorizationCodeRequest(authCode,user, tokenRequest);
        Assert.IsNull(result);
    }

    [Test]
    public void ValidateRefreshToken_ShouldBeCorrect()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var refresh = CreateBaseRefreshToken();
        var user = new User("name", "lastName", "mail@mail.com");
        var tokenRequest = CreateBaseTokenRequest();
 
        var result = service.ValidateRefreshTokenRequest(refresh,user, tokenRequest);
        Assert.IsNull(result);
    }

    [Test]
    public void ValidateRefreshToken_ShouldValidateUser()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var tokenRequest = CreateBaseTokenRequest();
        var refresh = CreateBaseRefreshToken();

        var result = service.ValidateRefreshTokenRequest(refresh, null, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidUser.key));
    }

    [Test]
    public void ValidateRefreshToken_ShouldValidateToken()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var user = new User("name", "lastName", "mail@mail.com");
        var tokenRequest = CreateBaseTokenRequest();

        var result = service.ValidateRefreshTokenRequest(null, user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidRequest.key));
    }

    [Test]
    public void ValidateRefreshToken_ShouldValidateExpiration()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var refresh = new RefreshToken(
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            DateTime.UtcNow.Subtract(new TimeSpan(0,0,0,1)),
            "myscope");
        var user = new User("name", "lastName", "mail@mail.com");
        var tokenRequest = CreateBaseTokenRequest();

        var result = service.ValidateRefreshTokenRequest(refresh,user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.Expired.key));
    }

    [Test]
    public void ValidateRefreshToken_ShouldValidateScope()
    {
        var service = new AuthValidator(_logger.Object, _authOptions);
        var refresh = new RefreshToken(
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            Guid.Parse("38048cf8979f4c12a0c93416da07e300"),
            DateTime.Now.AddMinutes(1),
            "myscope2");
        var user = new User("name", "lastName", "mail@mail.com");
        var tokenRequest = CreateBaseTokenRequest();

        var result = service.ValidateRefreshTokenRequest(refresh,user, tokenRequest);
        Assert.That(result.key, Is.EqualTo(TokenErrors.InvalidScope.key));
    }
}