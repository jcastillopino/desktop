﻿using JasperFx.CodeGeneration;
using System.Text;

namespace ServiceTracker.Security.UnitTests;
static  class TestUtils
{
    public static string GetEmptyError(string property)
    {
        return $"Property {property} can't be empty.";
    }

    public static string GetMaxLengthError(string property, string length)
    {
        return $"Property {property} exceeds maximum length ({length}).";
    }

    public static string GetMinLengthError(string property, string length)
    {
        return $"Property {property} doesn't reach minimun length ({length}).";
    }

    public static string GetString(int length)
    {
        StringBuilder sb = new StringBuilder("");

        for (int i = 0; i < length; i++)
            sb.Append("a");

        return sb.ToString();
    }
}
