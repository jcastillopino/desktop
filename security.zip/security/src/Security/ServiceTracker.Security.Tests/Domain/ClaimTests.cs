using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Validation;
// ReSharper disable UseObjectOrCollectionInitializer
// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.Domain;

public class ClaimTests
{
    [Test]
    public void Instantiation_ShouldNormalizeName()
    {
        var claim = new Claim("NewClaim", "Value");
        Assert.That(claim.NormalizedName, Is.EqualTo("newclaim"));
    }

    [Test]
    public void NameUpdate_ShouldNormalizeName()
    {
        var claim = new Claim("NewClaim", "Value");
        claim.Name = "MyNewName";
        Assert.That(claim.NormalizedName, Is.EqualTo("mynewname"));
    }

    [Test]
    public void Instantiation_EmptyName_ShouldFailValidation()
    { 
        var ex = Assert.Throws<ValidationException>(() => new Claim("", "Value"));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("Name")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
    }

    [Test]
    public void Instantiation_LongName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new Claim("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Value"));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("Name","30")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
    }

    [Test]
    public void Instantiation_SmallName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new Claim("AA", "Value"));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMinLengthError("Name", "3")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
    }

    [Test]
    public void Instantiation_EmptyValue_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new Claim("MyNewClaim", ""));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("Value")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Value"));
    }

    [Test]
    public void Instantiation_LongValue_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new Claim("MyNewClaim", TestUtils.GetString(257)));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("Value", "256")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Value"));
    }
}