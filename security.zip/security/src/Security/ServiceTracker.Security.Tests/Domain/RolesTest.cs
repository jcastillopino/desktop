using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Validation;
// ReSharper disable ObjectCreationAsStatement
// ReSharper disable UseObjectOrCollectionInitializer

namespace ServiceTracker.Security.UnitTests.Domain;

public class RolesTests
{
    [Test]
    public void Instantiation_ShouldNormalizeName()
    {
        var role = new Role("NewRole");
        Assert.That(role.NormalizedName, Is.EqualTo("newrole"));
    }

    [Test]
    public void NameUpdate_ShouldNormalizeName()
    {
        var role = new Role("NewRole");
        role.Name = "MyNewName";
        Assert.That(role.NormalizedName, Is.EqualTo("mynewname"));
    }

    [Test]
    public void Instantiation_EmptyName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new Role(""));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("Name")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
    }

    [Test]
    public void Instantiation_LongName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new Role("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("Name", "30")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
    }

    [Test]
    public void Instantiation_SmallName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new Role("AA"));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMinLengthError("Name", "3")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
    }
}