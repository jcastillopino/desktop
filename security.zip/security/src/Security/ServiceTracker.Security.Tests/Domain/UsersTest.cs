using ServiceTracking.Security.Infrastructure.Constants;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Extensions;
using ServiceTracking.Utils.Validation;
// ReSharper disable ObjectCreationAsStatement
// ReSharper disable UseObjectOrCollectionInitializer

namespace ServiceTracker.Security.UnitTests.Domain;

public class UsersTest
{
    [Test]
    public void Instantiation_ShouldNormalizeFields()
    {
        var user = new User("NewName", "NewLastName", "NewEmail@com");
        Assert.That(user.NormalizedName, Is.EqualTo("newname"));
        Assert.That(user.NormalizedLastName, Is.EqualTo("newlastname"));
        Assert.That(user.NormalizedEmail, Is.EqualTo("newemail@com"));
    }

    [Test]
    public void NameUpdate_ShouldNormalizeName()
    {
        var user = new User("NewName", "NewLastName", "NewEmail@com");
        user.Name = "MyNewName";
        Assert.That(user.NormalizedName, Is.EqualTo("mynewname"));
    }

    [Test]
    public void LastNameUpdate_ShouldNormalizeLastName()
    {
        var user = new User("NewName", "NewLastName", "NewEmail@com");
        user.LastName = "MyNewLastName";
        Assert.That(user.NormalizedLastName, Is.EqualTo("mynewlastname"));
    }

    [Test]
    public void EmailUpdate_ShouldNormalizeEmail()
    {
        var user = new User("NewName", "NewLastName", "NewEmail@com");
        user.Email = "MyNewEmail";
        Assert.That(user.NormalizedEmail, Is.EqualTo("mynewemail"));
    }

    [Test]
    public void Instantiation_EmptyName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new User("", "NewLastName", "NewEmail@com"));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("Name")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
    }

    [Test]
    public void Instantiation_LongName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new User("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "NewLastName", "NewEmail@com"));
        Assert.Multiple(() =>
        {
            Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
            Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("Name", "30")));
            Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
        });
    }

    [Test]
    public void Instantiation_SmallName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new User("AA", "NewLastName", "NewEmail@com"));
        Assert.Multiple(() =>
        {
            Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
            Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMinLengthError("Name", "3")));
            Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Name"));
        });
    }

    [Test]
    public void Instantiation_LongLastName_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new User(
            "NewName",
            "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            "NewMail"));
        Assert.Multiple(() =>
        {
            Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
            Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("LastName", "50")));
            Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("LastName"));
        });
    }

    [Test]
    public void Instantiation_EmptyEmail_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new User("NewName", "NewLastName", ""));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("Email")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Email"));
    }
    [Test]
    public void Instantiation_LongEmail_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new User(
            "NewName",
            "NewLastName",
            "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("Email", "50")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Email"));
    }

    [Test]
    public void Instantiation_SmallEmail_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new User("NewName", "NewLastName", "AAAA"));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMinLengthError("Email", "5")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Email"));
    }

    [Test]
    public void AddPassword_ShouldSetClaim()
    {
        var user = new User("Name", "LastName", "email@mail.com");
        user.AddPassword("NewPassword");
        Assert.That(user.Claims.First(x => x.NormalizedName == nameof(ClaimTypes.PasswordHash).Standarize()).Value,
            Is.EqualTo("NewPassword"));
    }
}