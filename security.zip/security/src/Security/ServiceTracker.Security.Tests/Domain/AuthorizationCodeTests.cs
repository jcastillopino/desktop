using System.Text;
using ServiceTracking.Security.Infrastructure.Domain;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Utils.Validation;
// ReSharper disable UseObjectOrCollectionInitializer
// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.Domain;

public class AuthorizationCodeTests
{
    [Test]
    public void Instantiation_ShouldGenerateCode()
    {
        var code = new AuthorizationCode(
            "state",
            Guid.NewGuid(),
            new Uri("http://servicetracker.com"),
            "scope",
            DateTime.Now,
            Guid.NewGuid(),
            "challenge",
            CodeChallengeMethod.None);

        Assert.True(code.Code.Length > 0);
    }

    [Test]
    public void Instantiation_StateUpdate_ShouldTriggerValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new AuthorizationCode(
            null,
            Guid.NewGuid(),
            new Uri("http://servicetracker.com"),
            "scope",
            DateTime.Now,
            Guid.NewGuid(),
            "challenge",
            CodeChallengeMethod.None));

        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("State")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("State"));
    }

    [Test]
    public void Instantiation_EmptyState_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new AuthorizationCode(
            null,
            Guid.NewGuid(),
            new Uri("http://servicetracker.com"),
            "scope",
            DateTime.Now,
            Guid.NewGuid(),
            "challenge",
            CodeChallengeMethod.None));

        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("State")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("State"));
    }

    [Test]
    public void Instantiation_LongState_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new AuthorizationCode(
            TestUtils.GetString(501),
            Guid.NewGuid(),
            new Uri("http://servicetracker.com"),
            "scope",
            DateTime.Now,
            Guid.NewGuid(),
            "challenge",
            CodeChallengeMethod.None));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("State", "500")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("State"));
    }

    [Test]
    public void Instantiation_EmptyUri_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new AuthorizationCode(
            "state",
            Guid.NewGuid(),
            null,
            "scope",
            DateTime.Now,
            Guid.NewGuid(),
            "challenge",
            CodeChallengeMethod.None));

        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("RedirectUri")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("RedirectUri"));
    }

    [Test]
    public void Instantiation_EmptyScope_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new AuthorizationCode(
            "state",
            Guid.NewGuid(),
            new Uri("http://servicetracker.com"),
            null,
            DateTime.Now,
            Guid.NewGuid(),
            "challenge",
            CodeChallengeMethod.None));

        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("Scope")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Scope"));
    }

    [Test]
    public void Instantiation_LongScope_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new AuthorizationCode(
            "state",
            Guid.NewGuid(),
            new Uri("http://servicetracker.com"),
            TestUtils.GetString(257),
            DateTime.Now,
            Guid.NewGuid(),
            "challenge",
            CodeChallengeMethod.None));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("Scope", "256")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Scope"));
    }

    [Test]
    public void Instantiation_LongChallenge_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new AuthorizationCode(
            "state",
            Guid.NewGuid(),
            new Uri("http://servicetracker.com"),
            "scope",
            DateTime.Now,
            Guid.NewGuid(),
            TestUtils.GetString(257),
            CodeChallengeMethod.None));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("CodeChallenge", "256")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("CodeChallenge"));
    }
}