using System.Text;
using ServiceTracking.Security.Infrastructure.Domain;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Utils.Validation;
// ReSharper disable UseObjectOrCollectionInitializer
// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.Domain;

public class RefreshTokenTests
{
    [Test]
    public void Instantiation_ShouldGenerateToken()
    {
        var token = new RefreshToken(
            Guid.NewGuid(),
            Guid.NewGuid(),
            DateTime.Now,
            "scope");

        Assert.True(token.Token.Length > 0);
    }

    [Test]
    public void Rotation_ShouldChangeCode()
    {
        var token = new RefreshToken(
            Guid.NewGuid(),
            Guid.NewGuid(),
            DateTime.Now,
            "scope");

        var existing = token.Token;

        token.RotateToken();
        Assert.True(token.Token != existing);
    }

    [Test]
    public void Instantiation_EmptyScope_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new RefreshToken(
            Guid.NewGuid(),
            Guid.NewGuid(),
            DateTime.Now,
            null));

        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetEmptyError("Scope")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Scope"));
    }

    [Test]
    public void Instantiation_LongScope_ShouldFailValidation()
    {
        var ex = Assert.Throws<ValidationException>(() => new RefreshToken(
            Guid.NewGuid(),
            Guid.NewGuid(),
            DateTime.Now,
            TestUtils.GetString(257)));
        Assert.That(ex?.Message, Is.EqualTo("Validation has failed"));
        Assert.That(ex?.ValidationResult.First().Message, Is.EqualTo(TestUtils.GetMaxLengthError("Scope", "256")));
        Assert.That(ex?.ValidationResult.First().PropertyName, Is.EqualTo("Scope"));
    }
}