using Moq;
using ServiceTracking.Security.API.RBAC.Permissions.Abstracts;
using ServiceTracking.Security.API.RBAC.Roles;
using ServiceTracking.Security.API.RBAC.Roles.Abstracts;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Exceptions;

namespace ServiceTracker.Security.UnitTests.RBAC;

public class RolesServiceTests
{
    [Test]
    public void CreateDuplicated_ShouldThrowException()
    {
        var roleRepository = new Mock<IRoleRepository>();
        roleRepository.Setup(x => x.Exists("Test")).ReturnsAsync(true);

        var service = new RoleService(roleRepository.Object, null, null);
        Assert.ThrowsAsync<ConflictException>(() => service.Create(new Role("Test")));
    }

    [Test]
    public void CreatePermissionNotExist_ShouldThrowException()
    {
        var roleRepository = new Mock<IRoleRepository>();
        roleRepository.Setup(x => x.Exists("Test")).ReturnsAsync(false);

        var permissions = new List<Guid>() { Guid.NewGuid() };

        var permissionRepository = new Mock<IPermissionRepository>();
        permissionRepository.Setup(x => x.ExistsAll(permissions)).ReturnsAsync(false);

        var role = new Role("Test", permissions, null);

        var service = new RoleService(roleRepository.Object, permissionRepository.Object, null);
        Assert.ThrowsAsync<EntityNotFoundException>(() => service.Create(role));
    }

    [Test]
    public void CreateUserNotExist_ShouldThrowException()
    {
        var roleRepository = new Mock<IRoleRepository>();
        roleRepository.Setup(x => x.Exists("Test")).ReturnsAsync(false);

        var permissionRepository = new Mock<IPermissionRepository>();
        permissionRepository.Setup(x => x.ExistsAll(It.IsAny<IReadOnlyCollection<Guid>>())).ReturnsAsync(false);

        var users = new List<Guid>() { Guid.NewGuid() };

        var userRepository = new Mock<IUserRepository>();
        userRepository.Setup(x => x.ExistsAll(users)).ReturnsAsync(false);

        var role = new Role("Test", null, users);

        var service = new RoleService(roleRepository.Object, permissionRepository.Object, userRepository.Object);
        Assert.ThrowsAsync<EntityNotFoundException>(() => service.Create(role));
    }

    [Test]
    public void UpdateNotExisting_ShouldThrowException()
    {
        var id = Guid.NewGuid();

        var roleRepository = new Mock<IRoleRepository>();
        _ = roleRepository.Setup(x => x.Get(id)).ReturnsAsync(null as Role);

        var service = new RoleService(roleRepository.Object, null, null);
        Assert.ThrowsAsync<EntityNotFoundException>(() => service.Update(Guid.NewGuid(), "Test", null));
    }

    [Test]
    public void UpdatePermissionNotExists_ShouldThrowException()
    {
        var id = Guid.NewGuid();
        var newPermissions = new List<Guid>() { Guid.NewGuid() };
        var role = new Role("Test", newPermissions, null);
        var existingPermission = new List<Permission>() {
            new Permission(Guid.NewGuid(),"MyTestingPermission")
        };

        var roleRepository = new Mock<IRoleRepository>();
        _ = roleRepository.Setup(x => x.Get(id)).ReturnsAsync(role);
        _ = roleRepository.Setup(x => x.GetRolePermissions(id)).ReturnsAsync(existingPermission);

        var permissionRepository = new Mock<IPermissionRepository>();
        permissionRepository.Setup(x => x.ExistsAll(newPermissions)).ReturnsAsync(false);

        var service = new RoleService(roleRepository.Object, permissionRepository.Object, null);
        Assert.ThrowsAsync<EntityNotFoundException>(() => service.Update(id, "Test", newPermissions));
    }
}