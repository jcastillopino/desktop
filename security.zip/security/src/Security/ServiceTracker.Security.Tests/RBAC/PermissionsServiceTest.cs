using Moq;
using ServiceTracking.Security.API.Controllers;
using ServiceTracking.Security.API.RBAC.Permissions;
using ServiceTracking.Security.API.RBAC.Permissions.Abstracts;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Exceptions;

// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.RBAC;

public class PermissionServiceTests
{
    [Test]
    public void CreateDuplicated_ShouldThrowException()
    {
        var permissionRepository = new Mock<IPermissionRepository>();
        permissionRepository.Setup(x => x.Exists("Test")).ReturnsAsync(true);

        var service = new PermissionService(permissionRepository.Object, null, null);
        Assert.ThrowsAsync<ConflictException>(() => service.Create(new Permission("Test")));

    }

    [Test]
    public void UpdateNotExisting_ShouldThrowException()
    {
        var id = Guid.NewGuid();

        var permissionRepository = new Mock<IPermissionRepository>();
        _ = permissionRepository.Setup(x => x.Get(id)).ReturnsAsync(null as Permission);

        var service = new PermissionService(permissionRepository.Object, null, null);
        Assert.ThrowsAsync<EntityNotFoundException>(() => service.Update(Guid.NewGuid(), "Test"));
    }

    [Test]
    public void DeleteNotExisting_ShouldThrowException()
    {
        var id = Guid.NewGuid();

        var permissionRepository = new Mock<IPermissionRepository>();
        _ = permissionRepository.Setup(x => x.Exists(id)).ReturnsAsync(false);

        var permissionService = new PermissionService(permissionRepository.Object, null, null);

        var controller = new PermissionController(permissionRepository.Object, permissionService);
        Assert.ThrowsAsync<EntityNotFoundException>(() => controller.Delete(id));

    }
}