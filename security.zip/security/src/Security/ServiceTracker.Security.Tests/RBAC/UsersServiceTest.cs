using Moq;
using ServiceTracking.Security.API.RBAC.Permissions.Abstracts;
using ServiceTracking.Security.API.RBAC.Roles.Abstracts;
using ServiceTracking.Security.API.RBAC.Users;
using ServiceTracking.Security.API.RBAC.Users.Abstracts;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Exceptions;

// ReSharper disable ObjectCreationAsStatement

namespace ServiceTracker.Security.UnitTests.RBAC;

public class UsersServiceTest
{
    [Test]
    public void CreateDuplicated_ShouldThrowException()
    {
        var roleRepository = new Mock<IRoleRepository>();
        var userRepository = new Mock<IUserRepository>();
        var permissionRepository = new Mock<IPermissionRepository>();
        userRepository.Setup(x => x.Exists("Test@mail.com")).ReturnsAsync(true);

        var service = new UserService(userRepository.Object, permissionRepository.Object, roleRepository.Object);
        Assert.ThrowsAsync<ConflictException>(() => service.Create(new User("Name", "LastName", "Test@mail.com")));
    }

    [Test]
    public void CreatePermissionNotExist_ShouldThrowException()
    {
        var roleRepository = new Mock<IRoleRepository>();
        var userRepository = new Mock<IUserRepository>();
        var permissionRepository = new Mock<IPermissionRepository>();

        userRepository.Setup(x => x.Exists("Test@mail.com")).ReturnsAsync(false);

        var permissions = new List<Guid> { Guid.NewGuid() };
        permissionRepository.Setup(x => x.ExistsAll(permissions)).ReturnsAsync(false);

        var user = new User("Name", "LastName", "Test@mail.com");

        var service = new UserService(userRepository.Object, permissionRepository.Object, roleRepository.Object);
        Assert.ThrowsAsync<EntityNotFoundException>(() => service.Create(user));
    }

    [Test]
    public void CreateRoleNotExist_ShouldThrowException()
    {
        var roleRepository = new Mock<IRoleRepository>();
        var userRepository = new Mock<IUserRepository>();
        var permissionRepository = new Mock<IPermissionRepository>();
        userRepository.Setup(x => x.Exists("Test@mail.com")).ReturnsAsync(false);

        var permissions = new List<Guid> { Guid.NewGuid() };
        permissionRepository.Setup(x => x.ExistsAll(permissions)).ReturnsAsync(true);

        var roles = new List<Guid> { Guid.NewGuid() };
        roleRepository.Setup(x => x.ExistsAll(roles)).ReturnsAsync(false);

        var user = new User("Name", "LastName", "Test@mail.com");

        var service = new UserService(userRepository.Object, permissionRepository.Object, roleRepository.Object);
        Assert.ThrowsAsync<EntityNotFoundException>(() => service.Create(user));
    }
}