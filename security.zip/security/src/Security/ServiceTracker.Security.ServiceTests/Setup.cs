﻿using Microsoft.Extensions.Configuration;
using NUnit.Framework;
using ServiceTracker.Security.ServiceTests.Utils;
using ServiceTracker.Security.ServiceTests.Utils.Data;
using ServiceTracking.Utils.Database;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace ServiceTracker.Security.ServiceTests;

[SetUpFixture]
public class RootFixtureSetup
{
    [OneTimeSetUp]
    public void OneTimeSetUp()
    {
        var config = new ConfigurationBuilder()
          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
          .AddEnvironmentVariables()
          .Build();

        SeedService(config);
        LoadAccessTokens(config);
    }

    private static void SeedService(IConfigurationRoot config)
    {
        var databaseHelper = new DatabaseHelper();
        var seed = File.ReadAllText("Seed.SQL");
        var connectionString = config.GetValue<string>("DBConnectionProvider:ConnectionString");
        databaseHelper.ExecuteScript(connectionString, seed);
    }

    private static void LoadAccessTokens(IConfigurationRoot config)
    {
        HttpHelper.AccessTokens = new Dictionary<Guid, string>();
        var baseUrl = config.GetValue<string>("ServiceURL");

        var httpClient = new HttpClient();
        httpClient.BaseAddress = new Uri(baseUrl);

        var ids = new List<Guid>
        {
            Permissions.SecurityPermissionsEdit,
            Permissions.SecurityPermissionsRead,
            Permissions.SecurityRolesEdit,
            Permissions.SecurityRolesRead,
            Permissions.SecurityUsersRead,
            Permissions.SecurityUsersEdit
        };

        foreach (var id in ids)
        {
            var task = HttpHelper.GetToken(httpClient, id);
            task.Wait();

            HttpHelper.AccessTokens.Add(id, task.Result);
        }
    }

    [OneTimeTearDown]
    public void OneTimeTearDown()
    {
        var config = new ConfigurationBuilder()
          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
          .AddEnvironmentVariables()
          .Build();

        var databaseHelper = new DatabaseHelper();
        var seed = File.ReadAllText("DeleteSeed.SQL");
        var connectionString = config.GetValue<string>("DBConnectionProvider:ConnectionString");
        databaseHelper.ExecuteScript(connectionString, seed);
    }
}
