﻿using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Constants;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Authorization;

namespace ServiceTracker.Security.ServiceTests.Utils.Data;

internal class UserDatabaseHelper
{
    private readonly string _connectionString;
    private readonly AppDbContext _context;
    private bool _disposedValue;

    public UserDatabaseHelper(string connectionString)
    {
        _connectionString = connectionString;
        _context = new AppDbContext(_connectionString);
    }

    public async Task Delete(string name)
    {
        var user = await _context.User.FirstOrDefaultAsync(x => x.Email == name);
        if (user != null)
        {
            await _context.UserPermission.Where(x => x.UserId == user.Id).ExecuteDeleteAsync();
            await _context.UserRole.Where(x => x.UserId == user.Id).ExecuteDeleteAsync();
            await _context.AuthorizationCodes.Where(x => x.UserId == user.Id).ExecuteDeleteAsync();
            await _context.RefreshTokens.Where(x => x.UserId == user.Id).ExecuteDeleteAsync();
        }

        await _context.User.Where(x => x.Email == name).ExecuteDeleteAsync();
    }

    public async Task<User> Get(string email)
    {
        return await _context.User
                .Where(x => x.Email == email)
                .Include(x => x.UserPermissions)
                .Include(x => x.UserRoles)
                .Include(x => x.Claims)
                .AsNoTracking()
                .FirstOrDefaultAsync();
    }

    public async Task<User> Create(
        string name, 
        string lastName, 
        string email, 
        IEnumerable<Permission> permissions,  
        IEnumerable<Role> roles,
        bool isApi = false)
    {
        await using var context = new AppDbContext(_connectionString);

        var user = new User(name, lastName, email)
        {
            IsActive = true
        };

        if (permissions != null)
        {
            IEnumerable<Permission> enumerable = permissions as Permission[] ?? permissions.ToArray();
            await context.AddRangeAsync(enumerable);

            foreach (var permission in enumerable)
            {
                user.UserPermissions.Add(new UserPermission { PermissionId = permission.Id });
            }
        }

        if (roles != null)
        {
            IEnumerable<Role> enumerable = roles as Role[] ?? roles.ToArray();
            await context.AddRangeAsync(enumerable);

            foreach (var role in enumerable)
            {
                user.UserRoles.Add(new UserRole() { RoleId = role.Id });
            }
        }

        user.IsApi = isApi;
        await context.AddAsync(user);
        await context.SaveChangesAsync();

        return user;
    }

    public async Task AddPassword(string email, string password)
    {
        await using var context = new AppDbContext(_connectionString);

        var user = await _context.User.FirstOrDefaultAsync(x => x.Email == email);
        var encryptionService = new EncryptionService();
        
        var passClaim = new Claim
        (
            nameof(ClaimTypes.PasswordHash),
            encryptionService.Encrypt(password)
        );
        
        user.Claims = new[] { passClaim };
        context.Update(user);

        await context.SaveChangesAsync();
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposedValue)
        {
            if (disposing)
            {
                _context.Dispose();
            }

            _disposedValue = true;
        }
    }
}
