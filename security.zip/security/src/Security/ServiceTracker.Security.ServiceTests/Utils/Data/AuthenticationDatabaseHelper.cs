﻿using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Constants;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Authorization;

namespace ServiceTracker.Security.ServiceTests.Utils.Data;

internal class AuthenticationDatabaseHelper
{
    private readonly string _connectionString;
    private readonly AppDbContext _context;
    private bool _disposedValue;

    public AuthenticationDatabaseHelper(string connectionString)
    {
        _connectionString = connectionString;
        _context = new AppDbContext(_connectionString);
    }

    public async Task AddAuthorizationCode(AuthorizationCode code)
    {
        await _context.AddAsync(code);
        await _context.SaveChangesAsync();
    }

    public async Task AddRefreshToken(RefreshToken token)
    {
        await _context.AddAsync(token);
        await _context.SaveChangesAsync();
    }

    public async Task<IReadOnlyCollection<RefreshToken>> GetTokensForUser(Guid userId)
    {
        return _context.RefreshTokens.Where(x => x.UserId == userId).ToList();
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposedValue)
        {
            if (disposing)
            {
                _context.Dispose();
            }

            _disposedValue = true;
        }
    }
}
