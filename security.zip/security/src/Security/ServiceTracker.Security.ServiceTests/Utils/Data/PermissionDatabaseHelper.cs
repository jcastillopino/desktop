﻿using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracker.Security.ServiceTests.Utils.Data;

internal class PermissionDatabaseHelper
{
    protected readonly string _connectionString;

    private readonly AppDbContext _context;
    
    private bool _disposedValue;

    public PermissionDatabaseHelper(string connectionString)
    {
        _connectionString = connectionString;
        _context = new AppDbContext(_connectionString);
    }

    public async Task Delete(string name)
    {
        await _context.Permission.Where(x => x.Name == name).ExecuteDeleteAsync();
    }

    public async Task<Permission> Get(string name)
    {
        return await _context.Permission.Where(x => x.Name == name)
            .AsNoTracking()
            .FirstOrDefaultAsync();
    }

    public async Task Create(string name)
    {
        await _context.Permission.AddAsync(new Permission(name));
        await _context.SaveChangesAsync();
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposedValue)
        {
            if (disposing)
            {
                _context.Dispose();
            }

            _disposedValue = true;
        }
    }
}
