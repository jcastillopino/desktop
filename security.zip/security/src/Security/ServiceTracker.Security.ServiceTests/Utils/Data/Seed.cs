﻿namespace ServiceTracker.Security.ServiceTests.Utils.Data;
static class Seed
{
    public static Guid PermissionReadId => new("11111111-1111-1111-1111-111111111111") ;

    public static Guid PermissionWriteId => new("11111111-1111-1111-1111-111111111112");

    public static Guid PermissionAdminId => new("11111111-1111-1111-1111-111111111113");

    public static string PermissionReadName => "Read Permission";

    public static string PermissionWriteName => "Write Permission";

    public static string PermissionAdminName => "Admin Permission";

    public static string RoleAdministratorName => "TestAdministrator";

    public static Guid RoleReadId => new("22222222-2222-2222-2222-222222222221");

    public static Guid RoleAdministratorId => new("22222222-2222-2222-2222-222222222222");

    public static string RoleReadName => new("Read");

    public static Guid UserPacoId => new("33333333-3333-3333-3333-333333333333");

    public static string UserPacoName => "Paco";

    public static string UserPacoLastName => "Rubio";

    public static string UserPacoFullName => "Paco Rubio";

    public static string UserPacoEmail => "francisco.rubio@gmail.com";

    public static string UserAdministratorName => "TestAdministrator";

}

public static class Permissions
{
    public static Guid SecurityUsersRead => new("33333333-3333-3333-3333-333333333311");
    public static Guid SecurityUsersEdit => new("33333333-3333-3333-3333-333333333312");
    public static Guid SecurityRolesRead => new("33333333-3333-3333-3333-333333333313");
    public static Guid SecurityRolesEdit => new("33333333-3333-3333-3333-333333333314");
    public static Guid SecurityPermissionsRead => new("33333333-3333-3333-3333-333333333315");
    public static Guid SecurityPermissionsEdit => new("33333333-3333-3333-3333-333333333316");

}
