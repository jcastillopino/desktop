﻿using Microsoft.EntityFrameworkCore;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;

namespace ServiceTracker.Security.ServiceTests.Utils.Data;

internal class RoleDatabaseHelper
{
    private readonly string _connectionString;
    private readonly AppDbContext _context;
    private bool _disposedValue;

    public RoleDatabaseHelper(string connectionString)
    {
        _connectionString = connectionString;
        _context = new AppDbContext(_connectionString);
    }

    public async Task Delete(string name)
    {
        var role = await _context.Role.FirstOrDefaultAsync(x => x.Name == name);
        if (role != null)
        {
            await _context.RolePermission.Where(x => x.RoleId == role.Id).ExecuteDeleteAsync();
            await _context.UserRole.Where(x => x.RoleId == role.Id).ExecuteDeleteAsync();
        }

        await _context.Role.Where(x => x.Name == name).ExecuteDeleteAsync();
    }

    public async Task<Role> Get(string name)
    {
        return await _context.Role
                .Where(x => x.Name == name)
                .Include(x => x.RolesPermissions)
                .Include(x => x.UserRoles)
                .AsNoTracking()
                .FirstOrDefaultAsync();
    }

    public async Task<IEnumerable<RolePermission>> GetPermissionsForRole(Guid id)
    {
        return await _context.RolePermission
                .Include(x => x.Permission)
                .Where(x => x.RoleId == id)
                .AsNoTracking()
                .ToListAsync();
    }

    public async Task Create(string name, IEnumerable<Permission> permissions)
    {
        await using var context = new AppDbContext(_connectionString);

        var role = new Role(name);

        if (permissions != null)
        {
            IEnumerable<Permission> enumerable = permissions as Permission[] ?? permissions.ToArray();
            await context.AddRangeAsync(enumerable);

            foreach (var permission in enumerable)
            {
                role.RolesPermissions.Add(new RolePermission() { PermissionId = permission.Id });
            }
        }

        await context.AddAsync(role);
        await context.SaveChangesAsync();
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposedValue)
        {
            if (disposing)
            {
                _context.Dispose();
            }

            _disposedValue = true;
        }
    }
}
