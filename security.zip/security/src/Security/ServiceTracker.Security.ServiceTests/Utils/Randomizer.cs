﻿namespace ServiceTracker.Security.ServiceTests.Utils;

public static class Randomizer
{

    public static string RandomString(int length)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        Random random = new Random();

        return new string(Enumerable.Repeat(chars, length)
            .Select(s => s[random.Next(s.Length)]).ToArray());
    }

    public static string RandomNumber(int length)
    {
        Random rd = new Random();
        int max = (int)Math.Pow(10, length);
        int min = max / 10;
        return rd.Next(min, max).ToString();
    }

    public static int GetDigitsFromString(string stringHasNumber)
    {
        return int.Parse(string.Join("", stringHasNumber.ToCharArray().Where(Char.IsDigit)));
    }
}
