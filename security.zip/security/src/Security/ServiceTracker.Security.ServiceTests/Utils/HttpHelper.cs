﻿using Newtonsoft.Json;
using ServiceTracking.Security.DTO.Oauth;
using System.Dynamic;
using System.Net.Http.Headers;
using System.Text;

namespace ServiceTracker.Security.ServiceTests.Utils;

internal static class HttpHelper
{

    public static Dictionary<Guid, string> AccessTokens;

    public static string BaseClient = "38048cf8979f4c12a0c93416da07e388";

    public static async Task<HttpResponseMessage> Post(
        Guid user, 
        string baseUrl, 
        string url, 
        StringContent content)
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(baseUrl);

        client.DefaultRequestHeaders.Authorization = 
            new AuthenticationHeaderValue("Bearer", AccessTokens.GetValueOrDefault(user));

        return await client.PostAsync(url, content);
    }

    public static async Task<HttpResponseMessage> Get(Guid user, string baseUrl, string url)
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(baseUrl);

        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", AccessTokens.GetValueOrDefault(user));
        return await client.GetAsync(url);
    }

    public static async Task<HttpResponseMessage> Put(
        Guid user, 
        string baseUrl, 
        string url, 
        StringContent content)
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(baseUrl);

        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", AccessTokens.GetValueOrDefault(user));
        return await client.PutAsync(url, content);
    }

    public static async Task<HttpResponseMessage> Delete(Guid user, string baseUrl, string url)
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(baseUrl);

        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", AccessTokens.GetValueOrDefault(user));
        return await client.DeleteAsync(url);
    }

    public static async Task<string> GetToken(HttpClient client, Guid user)
    {
        var payload = new ApiLoginDto(user, "Password123$", BaseClient);
        var contentToken = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");


        var result = await client.PostAsync("oauth/token/api", contentToken);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;
        return dynamicObject.access_token.ToString();
    }
}
