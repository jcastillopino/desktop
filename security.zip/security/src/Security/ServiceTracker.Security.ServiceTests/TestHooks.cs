﻿//using Microsoft.Extensions.Configuration;
//using ServiceTracking.Utils.Database;
//using ServiceTracking.Utils.Docker;

//namespace StepOne.E2ETests.E2ETests;

//[Binding]
//public static class TestHooks
//{
//    [BeforeTestRun]
//    public static async Task SetUpEnvironment()
//    {
//        var config = new ConfigurationBuilder()
//          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
//          .AddEnvironmentVariables()
//          .Build();

//        var databaseHelper = new DatabaseHelper();
//        var seed = File.ReadAllText("Seed.SQL");
//        var connectionString = config.GetValue<string>("DBConnectionProvider:ConnectionString");
//        databaseHelper.ExecuteScript(connectionString, seed);

//        if (IsDockerEnabled(config))
//        {
//            var services = new List<DockerService>();
//            var section = config.GetSection("Services");
//            section.Bind(services);
//            var dockerComposepath = config["DockerComposePath"];
//            var volume = config["SqlVolume"];

//            var dbType = config.GetValue<string>("DBConnectionProvider:ServerType");

//            var runner = new DockerRunner();

//            await CleanExistingRuns(runner, dockerComposepath, dbType, volume);
//            await BuildEnvironment(runner, dockerComposepath, dbType);
//            await LaunchEnvironment(runner, dockerComposepath, dbType, services);
//        }
//    }

//    [AfterTestRun]
//    public static async Task CleanEnvironment()
//    {
//        var runner = new DockerRunner();
//        var config = new ConfigurationBuilder()
//          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
//          .AddEnvironmentVariables()
//          .Build();

//        if (IsDockerEnabled(config))
//        {
//            var dockerComposepath = config["DockerComposePath"];
//            var dbType = config.GetValue<string>("DBConnectionProvider:ServerType");

//            var cancellationBuild = new CancellationTokenSource();
//            cancellationBuild.CancelAfter(TimeSpan.FromMinutes(5));

//            var resultbuild = await runner.ComposeDown(dockerComposepath, dbType, cancellationBuild.Token);

//            if (resultbuild.HasError)
//                throw new Exception("An error has occured executing docker-compose build");
//        }
//    }

//    private static bool IsDockerEnabled(IConfigurationRoot config)
//    {
//        return config.GetValue<bool>("DockerEnabled");
//    }

//    private static async Task CleanExistingRuns(
//        DockerRunner runner, 
//        string dockerComposepath, 
//        string dbType, 
//        string volume)
//    {
//        var cancellationBuild = new CancellationTokenSource();
//        cancellationBuild.CancelAfter(TimeSpan.FromMinutes(5));

//        var resultbuild = await runner.ComposeDown(dockerComposepath, dbType, cancellationBuild.Token);

//        if (resultbuild.HasError)
//            throw new Exception("An error has occured executing docker-compose down");

//        resultbuild = await runner.RemoveVolume(dockerComposepath, volume, cancellationBuild.Token);

//        if (resultbuild.HasError)
//            throw new Exception("An error has occured executing docker rm");
//    }

//    private static async Task BuildEnvironment(
//        DockerRunner runner, 
//        string dockerComposepath, 
//        string dbType)
//    {
//        var cancellationBuild = new CancellationTokenSource();
//        cancellationBuild.CancelAfter(TimeSpan.FromMinutes(10));

//        var resultbuild = await runner.ComposeBuild(dockerComposepath,
//            dbType, 
//            cancellationBuild.Token);

//        if (resultbuild.HasError)
//            throw new Exception("An error has occured executing docker-compose build");
//    }

//    private static async Task LaunchEnvironment(
//        DockerRunner runner, 
//        string dockerComposepath, 
//        string dbType, 
//        List<DockerService> services)
//    {
//        var cancellationUp = new CancellationTokenSource();
//        cancellationUp.CancelAfter(TimeSpan.FromMinutes(5));

//        var result = await runner.ComposeUp(services, dockerComposepath, dbType, cancellationUp.Token);

//        if (result.HasError)
//        {
//            await CleanEnvironment();
//            throw new Exception("An error has occured executing docker-compose");
//        }
//    }
//}