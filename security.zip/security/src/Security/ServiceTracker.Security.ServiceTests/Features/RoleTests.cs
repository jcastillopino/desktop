﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NUnit.Framework;
using ServiceTracker.Security.ServiceTests.Utils;
using ServiceTracker.Security.ServiceTests.Utils.Data;
using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;
using System.Dynamic;
using System.Net;
using System.Text;

namespace ServiceTracker.Security.ServiceTests.Features;

public class RoleTests
{
    private readonly string _serviceUrl;

    private readonly RoleDatabaseHelper _databaseHelper;

    private readonly PermissionDatabaseHelper _permissionHelper;

    public RoleTests()
    {
        var config = new ConfigurationBuilder()
          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
          .AddEnvironmentVariables()
          .Build();

        _serviceUrl = config.GetValue<string>("ServiceURL");
        var connectionString = config.GetValue<string>("DBConnectionProvider:ConnectionString");

        _databaseHelper = new RoleDatabaseHelper(connectionString);
        _permissionHelper = new PermissionDatabaseHelper(connectionString);
    }

    [OneTimeTearDown]
    public void BaseTearDown()
    {
        _databaseHelper.Dispose();
        _permissionHelper.Dispose();
    }

    [Test]
    public async Task Create()
    {
        const string newRole = "MyNewRole";
        await _databaseHelper.Delete(newRole);

        var permissions = new List<Guid>
        {
            Seed.PermissionReadId
        };

        var users = new List<Guid>
        {
            Seed.UserPacoId
        };

        var payload = new RoleAddDto(newRole, users, permissions);
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

        var result = await HttpHelper.Post(
            Permissions.SecurityRolesEdit,
            _serviceUrl,
            "roles"
            , content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        var roleCreated = await _databaseHelper.Get(newRole);

        Assert.AreEqual(dynamicObject.Name, roleCreated.Name);
        Assert.AreEqual(dynamicObject.Id, roleCreated.Id.ToString());
        Assert.AreEqual(Seed.PermissionReadId, roleCreated.RolesPermissions.First().PermissionId);
        Assert.AreEqual(Seed.UserPacoId, roleCreated.UserRoles.First().UserId);

        await _databaseHelper.Delete(newRole);
    }

    [Test]
    public async Task CreateExisting()
    {
        var payload = new RoleAddDto(Seed.RoleReadName, null, null);
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Post(
            Permissions.SecurityRolesEdit,
            _serviceUrl,
            "roles"
            , content);
        Assert.AreEqual(HttpStatusCode.Conflict, result.StatusCode);
    }

    [Test]
    public async Task CreateNotExistingPermission()
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(_serviceUrl);

        var newPermissions = new List<Guid> { Guid.NewGuid() };

        var payload = new RoleAddDto("CreateNotExistingPermission", null, newPermissions);
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Post(
            Permissions.SecurityRolesEdit,
            _serviceUrl,
            "roles"
            , content);

        Assert.AreEqual(HttpStatusCode.NotFound, result.StatusCode);
    }

    [Test]
    public async Task CreateNotExistingUser()
    {
        var newUser = new List<Guid>
        {
            Guid.NewGuid()
        };

        var payload = new RoleAddDto("CreateNotExistingUser", newUser, null);
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Post(
            Permissions.SecurityRolesEdit,
            _serviceUrl,
            "roles"
            , content);
        Assert.AreEqual(HttpStatusCode.NotFound, result.StatusCode);
    }

    [Test]
    public async Task Delete()
    {
        var existingName = "PacoRoleDelete";

        await _databaseHelper.Delete(existingName);
        await _databaseHelper.Create(existingName, null);
        var existingRole = await _databaseHelper.Get(existingName);

        var result = await HttpHelper.Delete(
            Permissions.SecurityRolesEdit,
            _serviceUrl,
            "roles/" + existingRole.Id);
        result.EnsureSuccessStatusCode();

        var deletedRole = await _databaseHelper.Get(existingName);

        Assert.AreEqual(false, deletedRole.IsActive);
        await _databaseHelper.Delete(existingName);
    }

    [Test]
    public async Task Update()
    {
        var existingName = "PacoUpdate";
        var newName = "PacoUpdate2";

        await CleanupUpdate(existingName, newName);

        var existingRole = await _databaseHelper.Get(existingName);
        var permissionAdd = await _permissionHelper.Get("PermissionAdd");
        var permissionKeep = await _permissionHelper.Get("PermissionKeep");

        var newPermissions = new List<Guid>
        {
            permissionAdd.Id,
            permissionKeep.Id
        };

        var payload = new RoleUpdateDto(existingRole.Id, newName, newPermissions);
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Put(
            Permissions.SecurityRolesEdit,
            _serviceUrl,
            "roles"
            , content);

        result.EnsureSuccessStatusCode();

        var updatedRole = await _databaseHelper.Get(newName);

        Assert.AreEqual(existingRole.Id, updatedRole.Id);
        Assert.True(updatedRole.RolesPermissions.Any(x => x.PermissionId == permissionAdd.Id));
        Assert.True(updatedRole.RolesPermissions.Any(x => x.PermissionId == permissionKeep.Id));
        Assert.AreEqual(2, updatedRole.RolesPermissions.Count);

        await _databaseHelper.Delete(newName);
        await _permissionHelper.Delete("PermissionAdd");
        await _permissionHelper.Delete("PermissionKeep");
        await _permissionHelper.Delete("PermissionDelete");
    }

    [Test]
    public async Task Search()
    {
        var content = SearchModelUtils.BuildSearchModel("Name", Seed.UserAdministratorName, CellDataType.Text, "Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityRolesRead,
            _serviceUrl,
            "roles/search"
            , content);
        result.EnsureSuccessStatusCode();
        
        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;
        
        Assert.AreEqual(Seed.RoleAdministratorId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(Seed.RoleAdministratorName, dynamicObject.Items[0].Name);
        Assert.AreEqual(Seed.PermissionReadName, dynamicObject.Items[0].Permissions[0]);
        Assert.AreEqual(Seed.PermissionWriteName, dynamicObject.Items[0].Permissions[1]);
        Assert.AreEqual(2, dynamicObject.Items[0].Permissions.Count);
        Assert.AreEqual(Seed.UserPacoFullName, dynamicObject.Items[0].Users[0]);
        Assert.AreEqual(1, dynamicObject.Items[0].Users.Count);
    }

    [Test]
    public async Task SearchByPermission()
    {
        var content = SearchModelUtils.BuildSortSearchModel("Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityRolesRead,
            _serviceUrl,
            $"roles/permission/{Seed.PermissionReadId}"
            , content);
        
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        Assert.AreEqual(Seed.RoleReadId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(Seed.RoleAdministratorId.ToString(), dynamicObject.Items[1].Id);
        Assert.AreEqual(2, dynamicObject.Items.Count);
    }

    [Test]
    public async Task SearchByUser()
    {
        var content = SearchModelUtils.BuildSortSearchModel("Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityRolesRead,
            _serviceUrl,
            $"roles/user/{Seed.UserPacoId}"
            , content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        Assert.AreEqual(Seed.RoleAdministratorId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(1, dynamicObject.Items.Count);
    }

    [Test]
    public async Task GetRolePermissions()
    {
        var result = await HttpHelper.Get(
            Permissions.SecurityRolesRead,
            _serviceUrl,
            $"roles/{Seed.RoleAdministratorId}/permissions");
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<List<PermissionRecord>>(resultContent)!;

        Assert.AreEqual(Seed.PermissionReadId, dynamicObject[0].Id);
        Assert.AreEqual(Seed.PermissionReadName.ToString(), dynamicObject[0].Name);
        Assert.AreEqual(Seed.PermissionWriteId, dynamicObject[1].Id);
        Assert.AreEqual(Seed.PermissionWriteName.ToString(), dynamicObject[1].Name);
        Assert.AreEqual(2, dynamicObject.Count);
    }

    private async Task CleanupUpdate(string existingName, string newName)
    {
        var permissionKeep = new Permission("PermissionKeep");
        var permissionDelete = new Permission("PermissionDelete");

        var permissionsExisting = new List<Permission> { permissionKeep, permissionDelete };
        await _databaseHelper.Delete(existingName);
        await _databaseHelper.Delete(newName);
        await _databaseHelper.Delete(newName);
        await _permissionHelper.Delete("PermissionAdd");
        await _permissionHelper.Delete("PermissionKeep");
        await _permissionHelper.Delete("PermissionDelete");

        await _permissionHelper.Create("PermissionAdd");
        await _databaseHelper.Create(existingName, permissionsExisting);
    }
}