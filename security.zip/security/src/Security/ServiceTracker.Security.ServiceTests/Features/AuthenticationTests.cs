﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NUnit.Framework;
using ServiceTracker.Security.ServiceTests.Utils;
using ServiceTracker.Security.ServiceTests.Utils.Data;
using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.Infrastructure.Domain.Oauth;
using System.Dynamic;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace ServiceTracker.Security.ServiceTests.Features;

public class AuthenticationTests
{
    private readonly string _serviceUrl;

    private readonly UserDatabaseHelper _userHelper;

    private readonly AuthenticationDatabaseHelper _authHelper;

    public AuthenticationTests()
    {
        var config = new ConfigurationBuilder()
          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
          .AddEnvironmentVariables()
          .Build();

        _serviceUrl = config.GetValue<string>("ServiceURL");
        var connectionString = config.GetValue<string>("DBConnectionProvider:ConnectionString");

        _userHelper = new UserDatabaseHelper(connectionString);
        _authHelper = new AuthenticationDatabaseHelper(connectionString);
    }

    [OneTimeTearDown]
    public void BaseTearDown()
    {
        _userHelper.Dispose();
    }

    [Test]
    public async Task BuildApiToken()
    {
        const string newUser = "apitoken@mail.com";

        await _userHelper.Delete(newUser);
        using var client = new HttpClient();
        client.BaseAddress = new Uri(_serviceUrl);

        var user = await _userHelper.Create(
            "MyName", 
            "MyLastName",
            newUser, 
            null, 
            null, 
            true);

        await _userHelper.AddPassword(newUser, "MyOldPassword1+");

        var payload = new ApiLoginDto(user.Id, "MyOldPassword1+", HttpHelper.BaseClient);
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

        var result = await client.PostAsync("oauth/token/api", content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;
        string accessToken = dynamicObject.access_token.ToString();
        Assert.True(accessToken.Length > 1);
        Assert.Null(dynamicObject.id_token);
        Assert.Null(dynamicObject.refresh_token);

        await _userHelper.Delete(newUser);
    }

    [Test]
    public async Task BuildAccessToken()
    {
        const string newUser = "authtoken@mail.com";

        await _userHelper.Delete(newUser);
        using var client = new HttpClient();
        client.BaseAddress = new Uri(_serviceUrl);

        var user = await _userHelper.Create("MyName", "MyLastName", newUser, null, null, true);
        await _userHelper.AddPassword(newUser, "MyOldPassword1+");

        var authCode = new AuthorizationCode(
            "state",
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            new Uri("http://localhost/client/user"),
            "openid",
            DateTime.UtcNow.AddMinutes(5),
            user.Id,
            Convert.ToHexString(SHA256.HashData(Encoding.ASCII.GetBytes("asd"))),
            CodeChallengeMethod.S256);

        await _authHelper.AddAuthorizationCode(authCode);

        var payload = new 
        {
            grant_type = "authorization_code",
            client_id = "38048cf8979f4c12a0c93416da07e388",
            code = authCode.Code,
            code_verifier = "asd",
            redirect_uri = "http://localhost/client/user",
            refresh_token = "",
            scope = "openid",
            state = "state"

        };

        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

        var result = await client.PostAsync("oauth/token", content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;
        string accessToken = dynamicObject.access_token.ToString();
        Assert.True(accessToken.Length > 1);
        Assert.True(dynamicObject.id_token.Length > 1);
        Assert.True(dynamicObject.refresh_token.Length > 1);

        await _userHelper.Delete(newUser);
    }

    [Test]
    public async Task BuildRefreshToken()
    {
        const string newUser = "authtoken@mail.com";

        await _userHelper.Delete(newUser);
        using var client = new HttpClient();
        client.BaseAddress = new Uri(_serviceUrl);

        var user = await _userHelper.Create(
            "MyName",
            "MyLastName",
            newUser, 
            null,
            null,
            true);

        await _userHelper.AddPassword(newUser, "MyOldPassword1+");

        var refreshToken = new RefreshToken(
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            user.Id,
            DateTime.UtcNow.AddMinutes(5),
            "openid");

        await _authHelper.AddRefreshToken(refreshToken);

        var payload = new
        {
            grant_type = "refresh_token",
            client_id = "38048cf8979f4c12a0c93416da07e388",
            refresh_token = refreshToken.Token,
            scope = "openid"
        };

        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

        var result = await client.PostAsync("oauth/token", content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;
        string accessToken = dynamicObject.access_token.ToString();
        Assert.True(accessToken.Length > 1);
        Assert.True(dynamicObject.id_token.Length > 1);
        Assert.True(dynamicObject.refresh_token.Length > 1);
        Assert.True(dynamicObject.refresh_token.ToString() != refreshToken.Token);

        await _userHelper.Delete(newUser);
    }

    [Test]
    public async Task DetectRefreshTokenReuse()
    {
        const string newUser = "refreshToken@mail.com";

        await _userHelper.Delete(newUser);
        using var client = new HttpClient();
        client.BaseAddress = new Uri(_serviceUrl);

        var user = await _userHelper.Create(
            "MyName",
            "MyLastName",
            newUser,
            null,
            null,
            true);

        await _userHelper.AddPassword(newUser, "MyOldPassword1+");

        var refreshToken = new RefreshToken(
            Guid.Parse("38048cf8979f4c12a0c93416da07e388"),
            user.Id,
            DateTime.UtcNow.AddMinutes(5),
            "openid");

        await _authHelper.AddRefreshToken(refreshToken);

        var payload = new
        {
            grant_type = "refresh_token",
            client_id = "38048cf8979f4c12a0c93416da07e388",
            refresh_token = refreshToken.Token,
            scope = "openid"
        };

        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await client.PostAsync("oauth/token", content);
        result.EnsureSuccessStatusCode();
        result = await client.PostAsync("oauth/token", content);
        Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.Unauthorized));

        var existingTokens = await _authHelper.GetTokensForUser(user.Id);
        Assert.That(existingTokens.Count, Is.EqualTo(0));

        await _userHelper.Delete(newUser);
    }
}