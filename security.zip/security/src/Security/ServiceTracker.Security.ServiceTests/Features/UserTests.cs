﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NUnit.Framework;
using ServiceTracker.Security.ServiceTests.Utils;
using ServiceTracker.Security.ServiceTests.Utils.Data;
using ServiceTracking.Security.DTO.Oauth;
using ServiceTracking.Security.DTO.RBAC;
using ServiceTracking.Security.Infrastructure.Constants;
using ServiceTracking.Security.Infrastructure.Domain.RBAC;
using ServiceTracking.Utils.Authorization;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;
using System.Dynamic;
using System.Net;
using System.Text;

namespace ServiceTracker.Security.ServiceTests.Features;

public class UserTests
{
    private readonly string _serviceUrl;

    private readonly UserDatabaseHelper _userHelper;

    private readonly RoleDatabaseHelper _roleHelper;

    private readonly PermissionDatabaseHelper _permissionHelper;

    public UserTests()
    {
        var config = new ConfigurationBuilder()
          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
          .AddEnvironmentVariables()
          .Build();

        _serviceUrl = config.GetValue<string>("ServiceURL");
        var connectionString = config.GetValue<string>("DBConnectionProvider:ConnectionString");

        _roleHelper = new RoleDatabaseHelper(connectionString);
        _permissionHelper = new PermissionDatabaseHelper(connectionString);
        _userHelper = new UserDatabaseHelper(connectionString);
    }

    [OneTimeTearDown]
    public void BaseTearDown()
    {
        _roleHelper.Dispose();
        _permissionHelper.Dispose();
    }

    [Test]
    public async Task Create()
    {
        const string newUser = "newuser@gmail.com";

        await _userHelper.Delete(newUser);
        var permissions = new List<Guid>
        {
            Seed.PermissionReadId
        };

        var roles = new List<Guid>
        {
            Seed.RoleAdministratorId
        };

        var payload = new UserAddDto("NewUserName", "NewUserLastName", newUser,"NewPassword12345.", permissions, roles);
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

        var result = await HttpHelper.Post(
            Permissions.SecurityUsersEdit,
            _serviceUrl,
            "users"
            , content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        var userCreated = await _userHelper.Get(newUser);

        Assert.AreEqual(dynamicObject.Email, newUser);
        Assert.AreEqual(dynamicObject.LastName, "NewUserLastName");
        Assert.AreEqual(dynamicObject.Name, "NewUserName");
        Assert.AreEqual(dynamicObject.Id, userCreated.Id.ToString());
        Assert.AreEqual(Seed.PermissionReadId, userCreated.UserPermissions.First().PermissionId);
        Assert.AreEqual(Seed.RoleAdministratorId, userCreated.UserRoles.First().RoleId);
        Assert.AreEqual("PasswordHash", userCreated.Claims.First().Name);
        await _userHelper.Delete(newUser);
    }

    [Test]
    public async Task CreateExisting()
    {
        var payload = new UserAddDto(
            "NewUserName", 
            "NewUserLastName", 
            Seed.UserPacoEmail, 
            "NewPassword", 
            null,
            null);

        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Post(
            Permissions.SecurityUsersEdit,
            _serviceUrl,
            "users"
            , content);
        Assert.AreEqual(HttpStatusCode.Conflict, result.StatusCode);
    }

    [Test]
    public async Task CreateNotExistingPermission()
    {
        var newPermissions = new List<Guid> { Guid.NewGuid() };

        var payload = new UserAddDto(
            "NewUserName",
            "NewUserLastName",
            Guid.NewGuid().ToString(),
            "NewPassword",
            newPermissions,
            null);

        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Post(
            Permissions.SecurityUsersEdit,
            _serviceUrl,
            "users"
            , content);
        Assert.AreEqual(HttpStatusCode.NotFound, result.StatusCode);
    }

    [Test]
    public async Task CreateNotExistingUser()
    {
        var newRole = new List<Guid>
        {
            Guid.NewGuid()
        };

        var payload = new UserAddDto(
            "NewUserName",
            "NewUserLastName",
            Guid.NewGuid().ToString(),
            "NewPassword",
            null,
            newRole);

        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Post(
            Permissions.SecurityUsersEdit,
            _serviceUrl,
            "users"
            , content);

        Assert.AreEqual(HttpStatusCode.NotFound, result.StatusCode);
    }

    [Test]
    public async Task Update()
    {
        var existingName = "UserName";
        var newName = "UserName2";
        var existingLastName = "UserLastName";
        var newLastName = "UserLastName2";
        var existingEmail = "userupdate@mail.com";

        await CleanupUpdate(existingName, existingLastName, existingEmail);
        var existingUser = await _userHelper.Get(existingEmail);

        var permissionAdd = await _permissionHelper.Get("PermissionUserAdd");
        var permissionKeep = await _permissionHelper.Get("PermissionUserKeep");

        var roleAdd = await _roleHelper.Get("RoleUserAdd");
        var roleKeep = await _roleHelper.Get("RoleUserKeep");

        var newPermissions = new List<Guid>
        {
            permissionAdd.Id,
            permissionKeep.Id
        };

        var newRoles = new List<Guid>
        {
            roleAdd.Id,
            roleKeep.Id
        };

        var payload = new UserUpdateDto(existingUser.Id, newName, newLastName, newPermissions, newRoles);
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Put(
            Permissions.SecurityUsersEdit,
            _serviceUrl,
            "users"
            , content);
        result.EnsureSuccessStatusCode();

        var updatedUser = await _userHelper.Get(existingEmail);

        Assert.AreEqual(existingUser.Id, updatedUser.Id);
        Assert.True(updatedUser.UserPermissions.Any(x => x.PermissionId == permissionAdd.Id));
        Assert.True(updatedUser.UserPermissions.Any(x => x.PermissionId == permissionKeep.Id));
        Assert.AreEqual(2, updatedUser.UserPermissions.Count);
        Assert.True(updatedUser.UserRoles.Any(x => x.RoleId == roleAdd.Id));
        Assert.True(updatedUser.UserRoles.Any(x => x.RoleId == roleKeep.Id));
        Assert.AreEqual(2, updatedUser.UserRoles.Count);

        await _userHelper.Delete(existingEmail);
        await _permissionHelper.Delete("PermissionUserAdd");
        await _permissionHelper.Delete("PermissionUserKeep");
        await _permissionHelper.Delete("PermissionUserDelete");
        await _permissionHelper.Delete("RoleUserAdd");
        await _permissionHelper.Delete("RoleUserKeep");
        await _permissionHelper.Delete("RoleUserDelete");
    }

    [Test]
    public async Task Delete()
    {
        const string existingName = "userupdate@mail.com";

        await _userHelper.Delete(existingName);
        await _userHelper.Create("MyName", "MyLastName", existingName,null,null);
        var user = await _userHelper.Get(existingName);

        var result = await HttpHelper.Delete(
            Permissions.SecurityUsersEdit,
            _serviceUrl,
            "users/" + user.Id);
        result.EnsureSuccessStatusCode();

        var deleted = await _userHelper.Get(existingName);

        Assert.AreEqual(false, deleted.IsActive);

        await _userHelper.Delete(existingName);
    }

    [Test]
    public async Task Search()
    {
        var content = SearchModelUtils.BuildSearchModel("Name", Seed.UserPacoName, CellDataType.Text, "Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityUsersRead,
            _serviceUrl,
            "users/search",
            content);
        result.EnsureSuccessStatusCode();
        
        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;
        
        Assert.AreEqual(Seed.UserPacoId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(Seed.UserPacoName, dynamicObject.Items[0].Name);
        Assert.AreEqual(Seed.UserPacoLastName, dynamicObject.Items[0].LastName);
        Assert.AreEqual(Seed.UserPacoEmail, dynamicObject.Items[0].Email);
        Assert.AreEqual(Seed.PermissionReadName, dynamicObject.Items[0].Permissions[0]);
        Assert.AreEqual(Seed.PermissionAdminName, dynamicObject.Items[0].Permissions[1]);
        Assert.AreEqual(2, dynamicObject.Items[0].Permissions.Count);
        Assert.AreEqual(Seed.RoleAdministratorName, dynamicObject.Items[0].Roles[0]);
        Assert.AreEqual(1, dynamicObject.Items[0].Roles.Count);
    }

    [Test]
    public async Task SearchByRole()
    {
        var content = SearchModelUtils.BuildSortSearchModel("Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityUsersRead,
            _serviceUrl,
            $"users/role/{Seed.RoleAdministratorId}",
            content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        Assert.AreEqual(Seed.UserPacoId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(1, dynamicObject.Items.Count);
    }

    [Test]
    public async Task SearchByPermission()
    {
        var content = SearchModelUtils.BuildSortSearchModel("Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityUsersRead,
            _serviceUrl,
            $"users/permission/{Seed.PermissionReadId}",
            content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        Assert.AreEqual(Seed.UserPacoId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(1, dynamicObject.Items.Count);
    }

    [Test]
    public async Task GetUserPermissions()
    {
        var result = await HttpHelper.Get(
            Permissions.SecurityUsersRead,
            _serviceUrl,
            $"users/{Seed.UserPacoId}/permissions");
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<List<PermissionRecord>>(resultContent)!;

        Assert.AreEqual(Seed.PermissionReadId, dynamicObject[0].Id);
        Assert.AreEqual(Seed.PermissionReadName.ToString(), dynamicObject[0].Name);
        Assert.AreEqual(Seed.PermissionAdminId, dynamicObject[1].Id);
        Assert.AreEqual(Seed.PermissionAdminName.ToString(), dynamicObject[1].Name);
        Assert.AreEqual(2, dynamicObject.Count);
    }

    [Test]
    public async Task GetUserRoles()
    {
        var result = await HttpHelper.Get(
            Permissions.SecurityUsersRead,
            _serviceUrl,
            $"users/{Seed.UserPacoId}/roles");
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<List<RoleRecord>>(resultContent)!;

        Assert.AreEqual(Seed.RoleAdministratorId, dynamicObject[0].Id);
        Assert.AreEqual(Seed.RoleAdministratorName.ToString(), dynamicObject[0].Name);
        Assert.AreEqual(1, dynamicObject.Count);
    }

    [Test]
    public async Task ChangePassword()
    {
        const string newUser = "changePassword@gmail.com";

        await _userHelper.Delete(newUser);
        using var client = new HttpClient();
        client.BaseAddress = new Uri(_serviceUrl);

        await _userHelper.Create("MyName", "MyLastName", newUser, null, null);
        await _userHelper.AddPassword(newUser, "MyOldPassword1+");

        var payload = new ChangePasswordDto(newUser, "MyOldPassword1+", "MyNewPassword1+");
        var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

        var result = await HttpHelper.Put(
            Permissions.SecurityUsersEdit,
            _serviceUrl,
            $"users/password",
            content);
        result.EnsureSuccessStatusCode();

        var userCreated = await _userHelper.Get(newUser);
        var passClaim = userCreated.Claims.First(x => x.NormalizedName == ClaimTypes.PasswordHash);

        var encryptionService = new EncryptionService();
        Assert.True(encryptionService.Verify("MyNewPassword1+", passClaim.Value));
        await _userHelper.Delete(newUser);
    }

    private async Task CleanupUpdate(string existingName, string existingLastName, string existingEmail)
    {
        var permissionKeep = new Permission("PermissionUserKeep");
        var permissionDelete = new Permission("PermissionUserDelete");

        var roleKeep = new Role("RoleUserKeep");
        var roleDelete = new Role("RoleUserDelete");

        var permissionsExisting = new List<Permission> { permissionKeep, permissionDelete };
        var rolesExisting = new List<Role> { roleDelete, roleKeep };

        await _userHelper.Delete(existingEmail);

        await _permissionHelper.Delete("PermissionUserAdd");
        await _permissionHelper.Delete("PermissionUserKeep");
        await _permissionHelper.Delete("PermissionUserDelete");

        await _roleHelper.Delete("RoleUserAdd");
        await _roleHelper.Delete("RoleUserKeep");
        await _roleHelper.Delete("RoleUserDelete");

        await _permissionHelper.Create("PermissionUserAdd");
        await _roleHelper.Create("RoleUserAdd", null);

        await _userHelper.Create(existingName, existingLastName, existingEmail,  permissionsExisting, rolesExisting);
    }
}