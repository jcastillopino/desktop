﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NUnit.Framework;
using ServiceTracker.Security.ServiceTests.Utils;
using ServiceTracker.Security.ServiceTests.Utils.Data;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.QueryHelpers;
using System.Dynamic;
using System.Net;
using System.Text;

namespace ServiceTracker.Security.ServiceTests.Features;


public class PermissionTests
{
    private readonly string serviceURL;

    private readonly PermissionDatabaseHelper databaseHelper;

    public PermissionTests()
    {
        var config = new ConfigurationBuilder()
          .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
          .AddEnvironmentVariables()
          .Build();

        serviceURL = config.GetValue<string>("ServiceURL");
        var connectionString = config.GetValue<string>("DBConnectionProvider:ConnectionString");

        databaseHelper = new PermissionDatabaseHelper(connectionString);
    }

    [OneTimeTearDown]
    public void BaseTearDown()
    {
        databaseHelper.Dispose();
    }

    [Test]
    public async Task Search()
    {
        var content = SearchModelUtils.BuildSearchModel("Name", Seed.PermissionReadName, CellDataType.Text, "Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityPermissionsRead,
            serviceURL,
            "permissions/search"
            , content);
        result.EnsureSuccessStatusCode();
        
        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;
        
        Assert.AreEqual(Seed.PermissionReadId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(Seed.PermissionReadName, dynamicObject.Items[0].Name);
        Assert.AreEqual(Seed.RoleAdministratorName, dynamicObject.Items[0].Roles[0]);
        Assert.AreEqual(Seed.RoleReadName, dynamicObject.Items[0].Roles[1]);
        Assert.AreEqual(2, dynamicObject.Items[0].Roles.Count);
        Assert.AreEqual(Seed.UserPacoEmail, dynamicObject.Items[0].Users[0]);
        Assert.AreEqual(1, dynamicObject.Items[0].Users.Count);
    }

    [Test]
    public async Task SearchByRole()
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(serviceURL);

        var content = SearchModelUtils.BuildSortSearchModel("Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityPermissionsRead,
            serviceURL,
            $"permissions/role/{Seed.RoleReadId}"
            , content);
        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        Assert.AreEqual(Seed.PermissionReadId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(1, dynamicObject.Items.Count);
    }

    [Test]
    public async Task SearchByUser()
    {
        using var client = new HttpClient();
        client.BaseAddress = new Uri(serviceURL);

        var content = SearchModelUtils.BuildSortSearchModel("Id");
        var result = await HttpHelper.Post(
            Permissions.SecurityPermissionsRead,
            serviceURL,
            $"permissions/user/{Seed.UserPacoId}"
            , content);

        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        Assert.AreEqual(Seed.PermissionReadId.ToString(), dynamicObject.Items[0].Id);
        Assert.AreEqual(Seed.PermissionAdminId.ToString(), dynamicObject.Items[1].Id);
        Assert.AreEqual(2, dynamicObject.Items.Count);
    }

    [Test]
    public async Task Create()
    {
        var newPermission = "Paco";

        await databaseHelper.Delete(newPermission);
        var payload = @"{
          'Name' : 'Paco'
        }".Replace("'", "\"");
        var content = new StringContent(payload, Encoding.UTF8, "application/json");

        var result = await HttpHelper.Post(
            Permissions.SecurityPermissionsEdit,
            serviceURL,
            "permissions"
            , content);

        result.EnsureSuccessStatusCode();

        var resultContent = await result.Content.ReadAsStringAsync();
        dynamic dynamicObject = JsonConvert.DeserializeObject<ExpandoObject>(resultContent)!;

        var permissionInserted = await databaseHelper.Get(newPermission);

        Assert.AreEqual(dynamicObject.Name, permissionInserted.Name);
        Assert.AreEqual(dynamicObject.Id, permissionInserted.Id.ToString());

        await databaseHelper.Delete(newPermission);
    }

    [Test]
    public async Task CreateExisting()
    {
        var payload = @"{
          'Name' : 'Read Permission'
        }".Replace("'", "\"");
        var content = new StringContent(payload, Encoding.UTF8, "application/json");

        var result = await HttpHelper.Post(
            Permissions.SecurityPermissionsEdit,
            serviceURL,
            "permissions"
            , content);
        Assert.AreEqual(HttpStatusCode.Conflict, result.StatusCode);
    }

    [Test]
    public async Task Update()
    {
        var existingName = "PacoUpdate";
        var newName = "PacoUpdate2";

        await databaseHelper.Delete(existingName);
        await databaseHelper.Delete(newName);
        await databaseHelper.Create(existingName);
        var existingPermission = await databaseHelper.Get(existingName);

        var payload = @"{
          'Id': '" + existingPermission.Id + @"',
          'Name' : 'PacoUpdate2'
        }";

        var content = new StringContent(payload.Replace("'", "\""), Encoding.UTF8, "application/json");
        var result = await HttpHelper.Put(
            Permissions.SecurityPermissionsEdit,
            serviceURL,
            "permissions"
            , content);
        result.EnsureSuccessStatusCode();

        var updatedPermission = await databaseHelper.Get(newName);

        Assert.AreEqual(existingPermission.Id, updatedPermission.Id);
        await databaseHelper.Delete(newName);
    }

    [Test]
    public async Task Delete()
    {
        var existingName = "PacoDelete";

        await databaseHelper.Delete(existingName);
        await databaseHelper.Create(existingName);
        var existingPermission = await databaseHelper.Get(existingName);

        using var client = new HttpClient();
        client.BaseAddress = new Uri(serviceURL);

        var result = await HttpHelper.Delete(
            Permissions.SecurityPermissionsEdit,
            serviceURL,
            "permissions/" + existingPermission.Id);

        result.EnsureSuccessStatusCode();

        var deletedPermission = await databaseHelper.Get(existingName);

        Assert.AreEqual(false, deletedPermission.IsActive);
        await databaseHelper.Delete(existingName);
    }
}