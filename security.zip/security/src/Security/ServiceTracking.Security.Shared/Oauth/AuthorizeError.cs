namespace ServiceTracking.Security.DTO.Oauth;


public record AuthorizeError(string key, string description);

