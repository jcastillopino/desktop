using System.Text.Json.Serialization;

namespace ServiceTracking.Security.DTO.Oauth;

/// <summary>
/// Contains the OAut token response.
/// </summary>
public class TokenResponse
{
    /// <summary>
    /// The access token issued by the authorization server.
    /// </summary>
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; }

    /// <summary>
    /// The type of the token.
    /// </summary>
    [JsonPropertyName("token_type")]
    public string TokenType { get; set; } = "Bearer";

    /// <summary>
    /// Lifetime in seconds of the access token.
    /// </summary>
    [JsonPropertyName("expires_in")]
    public double ExpiresIn { get; set; }

    /// <summary>
    /// The refresh token used to obtain new access token.
    /// </summary>
    [JsonPropertyName("refresh_token")]
    public string RefreshToken { get; set; }

    /// <summary>
    /// OpenId Id token.
    /// </summary>
    [JsonPropertyName("id_token")]
    public string IdToken { get; set; }

    /// <summary>
    /// The scopes granted. Will only have value if they differ from the ones originally requested.
    /// </summary>
    [JsonPropertyName("scope")]
    public string Scope { get; set; }
}