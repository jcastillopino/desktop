namespace ServiceTracking.Security.DTO.Oauth;

public record TokenError(string key, string description);