namespace ServiceTracking.Security.DTO.Oauth;

public static class TokenErrors
{
    public static readonly TokenError TokenReuse = new("invalid_token", "The provided token has been reused.");

    public static readonly TokenError InvalidPKCE = new("invalid_pkce", "The PKCE code verifier does not match.");

    public static readonly TokenError InvalidRedirect = new("invalid_redirect", "The redirect is not a match for the authorization code request");

    public static readonly TokenError InvalidState = new("invalid_state", "The state is not a match for the authorization code request");

    public static readonly TokenError InvalidUser = new ("invalid_user", "The user that is no longer active");

    public static readonly TokenError InvalidRequest = new ("invalid_request", "The request is missing a required parameter, includes an unsupported parameter value, or is otherwise malformed.");

    public static readonly TokenError InvalidClient = new("invalid_client", "The client is not a match for the authorization code request.");

    public static readonly TokenError InvalidGrant = new ("invalid_grant", "The provided authorization grant or refresh token is invalid, expired, revoked, or otherwise invalid.");

    public static readonly TokenError InvalidScope = new ("invalid_scope", "The request scope is invalid, unknown, malformed, or exeeds the scope granted by the resource owner.");

    public static readonly TokenError ServerError = new ("server_error", "An unexpected condition prevented issuing the access token.");

    public static readonly TokenError Expired = new("expired", "The authorization code has expired.");
}