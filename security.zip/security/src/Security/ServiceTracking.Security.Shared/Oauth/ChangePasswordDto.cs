using System.ComponentModel.DataAnnotations;
using ServiceTracking.Security.DTO.RBAC;

namespace ServiceTracking.Security.DTO.Oauth;

public class ChangePasswordDto
{
    public ChangePasswordDto(string email, string oldPassword, string newPassword)
    {
        Email = email;
        OldPassword = oldPassword;
        NewPassword = newPassword;
    }

    [Required, RegularExpression(@".*@.*\..*", ErrorMessage = "The username must be a valid email.")]
    public string Email { get; set; }

    [Required]
    public string OldPassword { get; set; }

    [PasswordValidation()]
    public string NewPassword { get; set; }
}
