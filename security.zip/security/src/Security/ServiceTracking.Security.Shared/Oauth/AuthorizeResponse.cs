namespace ServiceTracking.Security.DTO.Oauth;

/// <summary>
/// Contains the OAuth authorization response for the authorization code grant.
/// </summary>
public class AuthorizeResponse
{
    /// <summary>
    /// Authorization code to retrieve the access token.
    /// </summary>
    public string Code { get; set; }

    /// <summary>
    /// State initially provided by the client.
    /// </summary>
    public string State { get; set; }

    /// <summary>
    /// If unable to create the authorization code, includes the error code.
    /// </summary>
    public string Error { get; set; }

    /// <summary>
    /// Description of the error.
    /// </summary>
    public string ErrorDescription { get; set; }

    public static AuthorizeResponse FromError(AuthorizeError error, string state) =>
        new AuthorizeResponse
        {
            Error = error.key,
            ErrorDescription = error.description,
            State = state
        };
}