namespace ServiceTracking.Security.DTO.Oauth;

public class LoginDto
{
    public string Username { get; set; }

    public string Password { get; set; }
}

public record ApiLoginDto(Guid Id, string Password, string Client);
