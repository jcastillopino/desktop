namespace ServiceTracking.Security.DTO.Oauth;

public static class AuthorizeErrors
{
    public static readonly AuthorizeError InvalidRequest = new ("invalid_request", "The request is missing a required parameter, includes an unsupported parameter value, or is otherwise malformed.");

    public static readonly AuthorizeError UnauthorizedClient = new ("unauthorized_client", "Client authentication failed.");

    public static readonly AuthorizeError AccessDenied = new ("access_denied", "The resource owner or authorization server denied the request.");

    public static readonly AuthorizeError UnsupportedResponseType = new ("unsupported_response_type", "THe authorization server does not support obtaining an authorization code using this method.");

    public static readonly AuthorizeError ServerError = new ("server_error", "An unexpected condition prevented issuing the authorization code.");

    public static readonly AuthorizeError InvalidScope = new ("invalid_scope", "The request scope is invalid, unknown, malformed, or exeeds the scopes allowed on the client.");

    public static readonly AuthorizeError UnauthorizedUser = new("unauthorized_user", "Client authentication failed.");

    public static readonly AuthorizeError UnauthorizedRedirectUri= new("unauthorized_redirect", "Redirect Uri does not match allowed client ones.");
}