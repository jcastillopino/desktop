﻿namespace ServiceTracking.Security.DTO.RBAC;

public record struct RoleSimplifiedRecord(
    Guid Id,
    string Name,
    DateTimeOffset LastUpdate);

public record struct RoleRecord(
    Guid Id,
    string Name,
    DateTimeOffset LastUpdate,
    IReadOnlyCollection<string> Users,
    IReadOnlyCollection<string> Permissions);

public record struct RoleAddDto(
    string Name,
    IReadOnlyCollection<Guid> Users,
    IReadOnlyCollection<Guid> Permissions);

public record struct RoleUpdateDto
(
    Guid Id,
    string Name,
    IReadOnlyCollection<Guid> Permissions
);
