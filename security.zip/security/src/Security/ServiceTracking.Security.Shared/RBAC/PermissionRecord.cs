﻿namespace ServiceTracking.Security.DTO.RBAC;

public record struct PermissionRecord(
    Guid Id,
    string Name,
    DateTimeOffset LastUpdate,
    IEnumerable<string> Users,
    IEnumerable<string> Roles);

public readonly record struct PermissionAddDto(string Name);

public readonly record struct PermissionUpdateDto(Guid Id, string Name);

