using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace ServiceTracking.Security.DTO.RBAC;

public class PasswordValidationAttribute : ValidationAttribute
{
    private static readonly Regex UpperRegex = new("[A-Z]");
    private static readonly Regex LowerRegex = new ("[a-z]");
    private static readonly Regex DigitRegex = new (@"\d");
    private static readonly Regex CharRegex = new ("[!?*@_+.,]");

    public string UsernameFieldName { get; set; }

    public PasswordValidationAttribute()
    {
    }

    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        var password = value as string;
        if (password is null)
        {
            return new ValidationResult("The password is required");
        }

        var validPassword = ValidatePassword( password);
        if (!validPassword)
        {
            return new ValidationResult("Password must be between 12 and 50 characters, and include lowercase, uppercase, digit, and symbol.");
        }

        return ValidationResult.Success;
    }

    public bool ValidatePassword( string password)
    {
        return password.Length is >= 12 and <= 50
               && UpperRegex.IsMatch(password)
               && LowerRegex.IsMatch(password)
               && DigitRegex.IsMatch(password)
               && CharRegex.IsMatch(password);
    }
}
