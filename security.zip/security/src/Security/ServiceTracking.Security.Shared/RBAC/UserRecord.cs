﻿namespace ServiceTracking.Security.DTO.RBAC;

public record struct UserRecord(

    Guid Id,
    string Name,
    string LastName,
    string Email,
    DateTimeOffset LastUpdate,
    IReadOnlyCollection<string> Permissions,
    IReadOnlyCollection<string> Roles
);

public record struct UserSimplifiedRecord(

    Guid Id,
    string Name,
    string LastName,
    string Email,
    DateTimeOffset LastUpdate
);

public record struct UserAddDto(
    string Name,
    string LastName,
    string Email,
    string Password,
    IReadOnlyCollection<Guid> Permissions,
    IReadOnlyCollection<Guid> Roles
    );

public record struct UserUpdateDto(
    Guid Id,
    string Name,
    string LastName,
    IReadOnlyCollection<Guid> Permissions,
    IReadOnlyCollection<Guid> Roles
);