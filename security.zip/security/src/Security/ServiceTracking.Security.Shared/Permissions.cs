namespace ServiceTracking.Security.DTO;

public static class Permissions
{
    public const string SecurityPermissionsRead = "permissionsread";
    public const string SecurityPermissionsEdit = "permissionsedit";
    public const string SecurityRolesRead = "rolesread";
    public const string SecurityRolesEdit = "rolesedit";
    public const string SecurityUsersRead = "usersread";
    public const string SecurityUsersEdit = "usersedit";
}
