namespace ServiceTracking.Security.Infrastructure.Constants;

public static class ClaimTypes
{
    public const string PasswordHash = "passwordhash";

    public const string ResetPasswordCode = "resetpasswordcode";
}