﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ServiceTracking.Security.Infrastructure.Migrations.Migrations
{
    /// <inheritdoc />
    public partial class UpdateRefreshTokens : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsLastGenerated",
                table: "RefreshToken",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsLastGenerated",
                table: "RefreshToken");
        }
    }
}
