﻿using Microsoft.EntityFrameworkCore.Migrations;
using ServiceTracking.Utils.Database.Providers.SqlServer;

#nullable disable

namespace ServiceTracking.Security.Infrastructure.Migrations.Migrations
{
    /// <inheritdoc />
    public partial class Procedures : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.ExecuteSQL("SQL\\DataTypes.sql");
            migrationBuilder.ExecuteSQL("SQL\\usp_GetPermissionsForRoles.sql");
            migrationBuilder.ExecuteSQL("SQL\\usp_GetPermissionsForUsers.sql");
            migrationBuilder.ExecuteSQL("SQL\\usp_GetRolesForPermissions.sql");
            migrationBuilder.ExecuteSQL("SQL\\usp_GetRolesForUsers.sql");
            migrationBuilder.ExecuteSQL("SQL\\usp_GetUsersForPermissions.sql");
            migrationBuilder.ExecuteSQL("SQL\\usp_GetUsersForRoles.sql");
            migrationBuilder.ExecuteSQL("SQL\\CreateAdminUser.sql");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
