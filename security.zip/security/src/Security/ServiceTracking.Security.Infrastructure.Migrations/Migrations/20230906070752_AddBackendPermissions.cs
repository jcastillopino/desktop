﻿using Microsoft.EntityFrameworkCore.Migrations;
using ServiceTracking.Utils.Database.Providers.SqlServer;
#nullable disable

namespace ServiceTracking.Security.Infrastructure.Migrations.Migrations
{
    /// <inheritdoc />
    public partial class AddBackendPermissions : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.ExecuteSQL("SQL\\UpdateAdminUser.sql");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
