﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [AuthorizationCode] (
        [Code] nvarchar(40) NOT NULL,
        [ClientId] uniqueidentifier NOT NULL,
        [RedirectUri] nvarchar(2000) NOT NULL,
        [Scope] nvarchar(256) NOT NULL,
        [State] nvarchar(500) NOT NULL,
        [CodeChallenge] nvarchar(256) NULL,
        [CodeChallengeMethod] int NOT NULL,
        [ExpirationTime] datetime2 NOT NULL,
        [UserId] uniqueidentifier NOT NULL,
        CONSTRAINT [PK_AuthorizationCode] PRIMARY KEY ([Code])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [Permission] (
        [Id] uniqueidentifier NOT NULL,
        [LastUpdate] datetime2 NOT NULL,
        [Name] nvarchar(30) NOT NULL,
        [NormalizedName] nvarchar(30) NOT NULL,
        [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
        CONSTRAINT [PK_Permission] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [RefreshToken] (
        [Id] uniqueidentifier NOT NULL,
        [Token] nvarchar(80) NOT NULL,
        [ClientId] uniqueidentifier NOT NULL,
        [UserId] uniqueidentifier NOT NULL,
        [ExpirationTime] datetime2 NOT NULL,
        [Scope] nvarchar(256) NOT NULL,
        CONSTRAINT [PK_RefreshToken] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [Role] (
        [Id] uniqueidentifier NOT NULL,
        [LastUpdate] datetime2 NOT NULL,
        [Name] nvarchar(30) NOT NULL,
        [NormalizedName] nvarchar(30) NOT NULL,
        [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
        CONSTRAINT [PK_Role] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [User] (
        [Id] uniqueidentifier NOT NULL,
        [Name] nvarchar(30) NOT NULL,
        [NormalizedName] nvarchar(30) NOT NULL,
        [LastName] nvarchar(50) NULL,
        [NormalizedLastName] nvarchar(50) NULL,
        [Email] nvarchar(50) NOT NULL,
        [NormalizedEmail] nvarchar(50) NOT NULL,
        [IsAuthorized] bit NOT NULL DEFAULT CAST(0 AS bit),
        [AuthorizationRequired] bit NOT NULL DEFAULT CAST(0 AS bit),
        [IsApi] bit NOT NULL DEFAULT CAST(0 AS bit),
        [IsActive] bit NOT NULL DEFAULT CAST(0 AS bit),
        [LastUpdate] datetime2 NOT NULL,
        CONSTRAINT [PK_User] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [RolePermission] (
        [RoleId] uniqueidentifier NOT NULL,
        [PermissionId] uniqueidentifier NOT NULL,
        CONSTRAINT [PK_RolePermission] PRIMARY KEY ([RoleId], [PermissionId]),
        CONSTRAINT [FK_RolePermission_Permission_PermissionId] FOREIGN KEY ([PermissionId]) REFERENCES [Permission] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_RolePermission_Role_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Role] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [Claim] (
        [Id] uniqueidentifier NOT NULL,
        [Value] nvarchar(256) NOT NULL,
        [UserId] uniqueidentifier NOT NULL,
        [LastUpdate] datetime2 NOT NULL,
        [Name] nvarchar(30) NOT NULL,
        [NormalizedName] nvarchar(30) NOT NULL,
        [IsActive] bit NOT NULL,
        CONSTRAINT [PK_Claim] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Claim_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [User] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [UserPermission] (
        [UserId] uniqueidentifier NOT NULL,
        [PermissionId] uniqueidentifier NOT NULL,
        CONSTRAINT [PK_UserPermission] PRIMARY KEY ([UserId], [PermissionId]),
        CONSTRAINT [FK_UserPermission_Permission_PermissionId] FOREIGN KEY ([PermissionId]) REFERENCES [Permission] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_UserPermission_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [User] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE TABLE [UserRole] (
        [UserId] uniqueidentifier NOT NULL,
        [RoleId] uniqueidentifier NOT NULL,
        CONSTRAINT [PK_UserRole] PRIMARY KEY ([UserId], [RoleId]),
        CONSTRAINT [FK_UserRole_Role_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Role] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_UserRole_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [User] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_Claim_UserId] ON [Claim] ([UserId]);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_Permission_IsActive] ON [Permission] ([IsActive]) WITH (FILLFACTOR = 90);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_Permission_Name] ON [Permission] ([Name]) WITH (FILLFACTOR = 90);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_Role_IsActive] ON [Role] ([IsActive]) WITH (FILLFACTOR = 90);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_Role_NormalizedName] ON [Role] ([NormalizedName]) WITH (FILLFACTOR = 90);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_RolePermission_PermissionId] ON [RolePermission] ([PermissionId]);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_User_IsActive] ON [User] ([IsActive]) WITH (FILLFACTOR = 90);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_User_NormalizedEmail] ON [User] ([NormalizedEmail]) WITH (FILLFACTOR = 90);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_User_NormalizedLastName] ON [User] ([NormalizedLastName]) WITH (FILLFACTOR = 90);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_User_NormalizedName] ON [User] ([NormalizedName]) WITH (FILLFACTOR = 90);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_UserPermission_PermissionId] ON [UserPermission] ([PermissionId]);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    CREATE INDEX [IX_UserRole_RoleId] ON [UserRole] ([RoleId]);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143309_Initial')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20230825143309_Initial', N'7.0.2');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = 'CREATE TYPE PermissionType AS TABLE ( PermissionId UniqueIdentifier );
    CREATE TYPE RoleType AS TABLE ( RoleId UniqueIdentifier );
    CREATE TYPE UserType AS TABLE ( UserId UniqueIdentifier );'
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = 'CREATE PROC [dbo].[usp_GetPermissionsForRoles]
    	@roles RoleType READONLY
    AS

    SET NOCOUNT ON
    SELECT 
      RS.RoleId, 
      RS.PermissionName,
      RS.PermissionId 
    FROM 
      (
        SELECT 
          RP.RoleId AS RoleId, 
          P.Name As PermissionName, 
          RP.PermissionId AS PermissionId, 
          ROW_NUMBER() OVER (
            Partition BY RP.RoleId 
            ORDER BY 
              P.Name
          ) AS Rank 
        FROM 
          RolePermission RP 
          JOIN [dbo].[Permission] P ON RP.PermissionId = P.Id
          JOIN @roles PP ON PP.RoleId = RP.RoleId
        WHERE P.IsActive = 1
      ) RS 
    WHERE 
      Rank <= 10
    '
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = 'CREATE PROC [dbo].[usp_GetPermissionsForUsers]
    @users UserType READONLY
    AS
    SET NOCOUNT ON
        SELECT 
          RS.UserId, 
    	  RS.PermissionId,
          RS.PermissionName 
        FROM 
          (
            SELECT 
              UU.UserId AS UserId, 
    		  P.Id AS PermissionId,
              P.Name As PermissionName, 
              ROW_NUMBER() OVER (
                Partition BY UP.UserId
                ORDER BY 
                  UP.UserId
              ) AS Rank 
            FROM 
              UserPermission UP 
              JOIN [dbo].[Permission] P ON UP.PermissionId = P.Id
              JOIN @users AS UU ON UU.UserId = UP.UserId
            WHERE P.IsActive = 1
          ) RS 
        WHERE 
          Rank <= 10'
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = 'CREATE PROC [dbo].[usp_GetRolesForPermissions]
        	@permissions PermissionType READONLY
        AS
        SET NOCOUNT ON
        SELECT 
        	rs.PermissionId AS PermissionId,
        	rs.Name AS RoleName,
    		rs.RoleId as RoleId
        FROM (
            SELECT  UR.PermissionId AS PermissionId,
        			UU.Name As Name,
    				UR.RoleId As RoleId,
        			ROW_NUMBER() 
              OVER (Partition BY UR.PermissionId
                    ORDER BY UU.Name DESC ) AS Rank
        	from RolePermission UR
        		JOIN [dbo].[Role] UU ON UR.RoleId = UU.Id
        		JOIN @permissions p ON P.PermissionId = UR.PermissionId
        		JOIN [dbo].[Permission] PP ON PP.Id = P.PermissionId
        	WHERE UU.IsActive = 1 AND PP.IsActive = 1

            ) rs WHERE Rank <= 10'
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = 'CREATE PROC [dbo].[usp_GetRolesForUsers]
    @users UserType READONLY
    AS
    SET NOCOUNT ON
        SELECT 
          RS.UserId, 
    	  RS.RoleId,
          RS.RoleName 
        FROM 
          (
            SELECT 
              UU.UserId AS UserId, 
    		  R.Id AS RoleId,
              R.Name As RoleName, 
              ROW_NUMBER() OVER (
                Partition BY UR.UserId
                ORDER BY 
                  UR.UserId
            ) AS Rank 
            FROM 
              UserRole UR 
              JOIN [dbo].[Role] R ON UR.RoleId = R.Id
              JOIN @users AS UU ON UU.UserId = UR.UserId
             WHERE R.IsActive = 1
          ) RS 
        WHERE 
          Rank <= 10
    '
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = 'CREATE PROC [dbo].[usp_GetUsersForPermissions]
    	@permissions PermissionType READONLY
    AS

    SET NOCOUNT ON
    	SELECT 
    		rs.PermissionId AS Permission,
    		rs.Email
    	FROM (
    		SELECT  UPP.PermissionId AS PermissionId,
    				UU.Email As Email, 
    				ROW_NUMBER() 
    		  OVER (Partition BY UPP.PermissionId
    				ORDER BY UU.Email DESC ) AS Rank
    		from UserPermission UPP
    			JOIN [dbo].[User] UU ON UPP.UserId = UU.Id
    			JOIN @permissions p ON P.PermissionId = UPP.PermissionId
    		WHERE UU.IsActive = 1
    		) rs WHERE Rank <= 10'
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = 'CREATE PROC [dbo].[usp_GetUsersForRoles]
    	@roles RoleType READONLY
    AS

    SET NOCOUNT ON
    SELECT 
      RS.RoleId, 
      RS.UserName 
    FROM 
      (
        SELECT 
          UR.RoleId AS RoleId, 
          CONCAT(U.Name , '' '', U.LastName ) As UserName, 
          ROW_NUMBER() OVER (
            Partition BY UR.RoleId 
            ORDER BY 
              U.Name
          ) AS Rank 
        FROM 
          UserRole UR 
          JOIN [dbo].[User] U ON UR.UserId = U.Id
          JOIN @roles PP ON PP.RoleId = UR.RoleId
        WHERE 
          U.IsActive = 1
      ) RS 
    WHERE 
      Rank <= 10
    '
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = '    DECLARE @now DATETIME = GETUTCDATE();

        -- Create user
        DECLARE @userID UNIQUEIDENTIFIER = NEWID();

        INSERT INTO [User]
            (Id, Name,NormalizedName, LastName,NormalizedLastName, Email,NormalizedEmail, LastUpdate, IsActive)
        VALUES
            (@userID, ''Admin'',''admim'', ''Admin'',''admim'', ''admin@stepone.com'',''admin@stepone.com'', @now, 1);

        -- Create password claim
        INSERT INTO [Claim]
            (Id, UserId, Name, NormalizedName, Value, LastUpdate, IsActive)
        VALUES
            (NEWID(), @userID, ''PasswordHash'', ''passwordhash'', ''$2a$11$j7zsJzk37QUkWxrW8z7xOunm78hHO6KqNx1DYCYCYiKWnGm0fj/zW'', @now, 1);

        -- Create permissions
        DECLARE @permissions TABLE (
            [Id] UNIQUEIDENTIFIER,
            [Name] VARCHAR(256),
            [NormalizedName] VARCHAR(256)
        );

        INSERT INTO @permissions
            (Id, Name, NormalizedName)
        VALUES
            (''00000000-0000-0000-0000-000000000001'', ''Users Read'', ''usersread''),
            (''00000000-0000-0000-0000-000000000002'', ''Users Edit'', ''usersedit''),
            (''00000000-0000-0000-0000-000000000003'', ''Roles Read'', ''rolesread''),
            (''00000000-0000-0000-0000-000000000004'', ''Roles Edit'', ''rolesedit''),
            (''00000000-0000-0000-0000-000000000005'', ''Permissions Read'', ''permissionsread''),
            (''00000000-0000-0000-0000-000000000006'', ''Permissions Edit'', ''permissionsedit'');

        INSERT INTO [Permission]
            (Id, Name, NormalizedName, LastUpdate, IsActive)
        SELECT p.Id, p.Name, p.NormalizedName, @now, 1
        FROM @permissions p

        -- Create admin role
        DECLARE @adminRoleId UNIQUEIDENTIFIER = NEWID();

        INSERT INTO [Role]
            (Id, Name, NormalizedName, LastUpdate, IsActive)
        VALUES
            (@adminRoleId, ''Administrator'', ''administrator'', @now, 1)

        -- Assign permissions to admin role
        INSERT INTO [RolePermission]
            (RoleId, PermissionId)
        SELECT @adminRoleId, p.Id
        FROM @permissions p

        -- Assign admin role to user
        INSERT INTO [UserRole]
            (UserId, RoleId)
        VALUES
            (@userID, @adminRoleId)'
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230825143354_Procedures')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20230825143354_Procedures', N'7.0.2');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230826163809_UpdateRefreshTokens')
BEGIN
    ALTER TABLE [RefreshToken] ADD [IsLastGenerated] bit NOT NULL DEFAULT CAST(0 AS bit);
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230826163809_UpdateRefreshTokens')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20230826163809_UpdateRefreshTokens', N'7.0.2');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230906070752_AddBackendPermissions')
BEGIN
    DECLARE @SQL AS NVARCHAR(MAX) = '    DECLARE @now DATETIME = GETUTCDATE();

        -- Create user
        DECLARE @userID UNIQUEIDENTIFIER = NEWID();

        -- Create permissions
        DECLARE @permissions TABLE (
            [Id] UNIQUEIDENTIFIER,
            [Name] VARCHAR(256),
            [NormalizedName] VARCHAR(256)
        );

        INSERT INTO @permissions
            (Id, Name, NormalizedName)
        VALUES
            (''00000000-0000-0000-0000-000000000008'', ''Candidates Read'', ''candidatesread''),
            (''00000000-0000-0000-0000-000000000009'', ''Candidates Edit'', ''candidatesedit''),
            (''00000000-0000-0000-0000-000000000010'', ''Positions Read'', ''positionsread''),
            (''00000000-0000-0000-0000-000000000011'', ''Positions Edit'', ''positionsedit'')

        INSERT INTO [Permission]
            (Id, Name, NormalizedName, LastUpdate, IsActive)
        SELECT p.Id, p.Name, p.NormalizedName, @now, 1
        FROM @permissions p

        -- Create admin role
        DECLARE @adminRoleId UNIQUEIDENTIFIER = NEWID();

        SELECT @adminRoleId = Id FROM [Role]
        WHERE NormalizedName = ''administrator''

        -- Assign permissions to admin role
        INSERT INTO [RolePermission]
            (RoleId, PermissionId)
        SELECT @adminRoleId, p.Id
        FROM @permissions p'
    EXEC sp_executesql @SQL
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20230906070752_AddBackendPermissions')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20230906070752_AddBackendPermissions', N'7.0.2');
END;
GO

COMMIT;
GO

