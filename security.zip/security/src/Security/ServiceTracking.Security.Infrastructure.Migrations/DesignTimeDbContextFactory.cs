﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using ServiceTracking.Security.Infrastructure;
using ServiceTracking.Utils.Database;
using ServiceTracking.Utils.Database.Extensions;

namespace StepOne.Security.Infrastructure.Migrations;

public class ApplicationDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
{
    public AppDbContext CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", true)
            .AddJsonFile("appsettings.Development.json", true)
            .Build();

        var builder = new DbContextOptionsBuilder();
        var dbConnectionProvider = new DBConnectionProvider();
        configuration.GetRequiredSection("DBConnectionProvider")
            .Bind(dbConnectionProvider);
        builder.UseDatabaseServer(dbConnectionProvider, typeof(ApplicationDbContextFactory).Assembly.FullName);

        return new AppDbContext(builder.Options);
    }
}