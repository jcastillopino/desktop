﻿CREATE TYPE PermissionType AS TABLE ( PermissionId UniqueIdentifier );
CREATE TYPE RoleType AS TABLE ( RoleId UniqueIdentifier );
CREATE TYPE UserType AS TABLE ( UserId UniqueIdentifier );