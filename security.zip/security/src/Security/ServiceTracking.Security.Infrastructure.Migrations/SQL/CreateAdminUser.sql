    DECLARE @now DATETIME = GETUTCDATE();

    -- Create user
    DECLARE @userID UNIQUEIDENTIFIER = NEWID();

    INSERT INTO [User]
        (Id, Name,NormalizedName, LastName,NormalizedLastName, Email,NormalizedEmail, LastUpdate, IsActive)
    VALUES
        (@userID, 'Admin','admim', 'Admin','admim', 'admin@stepone.com','admin@stepone.com', @now, 1);

    -- Create password claim
    INSERT INTO [Claim]
        (Id, UserId, Name, NormalizedName, Value, LastUpdate, IsActive)
    VALUES
        (NEWID(), @userID, 'PasswordHash', 'passwordhash', '$2a$11$j7zsJzk37QUkWxrW8z7xOunm78hHO6KqNx1DYCYCYiKWnGm0fj/zW', @now, 1);

    -- Create permissions
    DECLARE @permissions TABLE (
        [Id] UNIQUEIDENTIFIER,
        [Name] VARCHAR(256),
        [NormalizedName] VARCHAR(256)
    );

    INSERT INTO @permissions
        (Id, Name, NormalizedName)
    VALUES
        ('00000000-0000-0000-0000-000000000001', 'Users Read', 'usersread'),
        ('00000000-0000-0000-0000-000000000002', 'Users Edit', 'usersedit'),
        ('00000000-0000-0000-0000-000000000003', 'Roles Read', 'rolesread'),
        ('00000000-0000-0000-0000-000000000004', 'Roles Edit', 'rolesedit'),
        ('00000000-0000-0000-0000-000000000005', 'Permissions Read', 'permissionsread'),
        ('00000000-0000-0000-0000-000000000006', 'Permissions Edit', 'permissionsedit');

    INSERT INTO [Permission]
        (Id, Name, NormalizedName, LastUpdate, IsActive)
    SELECT p.Id, p.Name, p.NormalizedName, @now, 1
    FROM @permissions p

    -- Create admin role
    DECLARE @adminRoleId UNIQUEIDENTIFIER = NEWID();

    INSERT INTO [Role]
        (Id, Name, NormalizedName, LastUpdate, IsActive)
    VALUES
        (@adminRoleId, 'Administrator', 'administrator', @now, 1)

    -- Assign permissions to admin role
    INSERT INTO [RolePermission]
        (RoleId, PermissionId)
    SELECT @adminRoleId, p.Id
    FROM @permissions p

    -- Assign admin role to user
    INSERT INTO [UserRole]
        (UserId, RoleId)
    VALUES
        (@userID, @adminRoleId)