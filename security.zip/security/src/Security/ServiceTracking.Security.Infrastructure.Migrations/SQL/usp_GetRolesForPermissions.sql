﻿CREATE PROC [dbo].[usp_GetRolesForPermissions]
    	@permissions PermissionType READONLY
    AS
    SET NOCOUNT ON
    SELECT 
    	rs.PermissionId AS PermissionId,
    	rs.Name AS RoleName,
		rs.RoleId as RoleId
    FROM (
        SELECT  UR.PermissionId AS PermissionId,
    			UU.Name As Name,
				UR.RoleId As RoleId,
    			ROW_NUMBER() 
          OVER (Partition BY UR.PermissionId
                ORDER BY UU.Name DESC ) AS Rank
    	from RolePermission UR
    		JOIN [dbo].[Role] UU ON UR.RoleId = UU.Id
    		JOIN @permissions p ON P.PermissionId = UR.PermissionId
    		JOIN [dbo].[Permission] PP ON PP.Id = P.PermissionId
    	WHERE UU.IsActive = 1 AND PP.IsActive = 1

        ) rs WHERE Rank <= 10