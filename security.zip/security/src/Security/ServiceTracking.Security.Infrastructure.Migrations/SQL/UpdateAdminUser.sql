    DECLARE @now DATETIME = GETUTCDATE();

    -- Create user
    DECLARE @userID UNIQUEIDENTIFIER = NEWID();

    -- Create permissions
    DECLARE @permissions TABLE (
        [Id] UNIQUEIDENTIFIER,
        [Name] VARCHAR(256),
        [NormalizedName] VARCHAR(256)
    );

    INSERT INTO @permissions
        (Id, Name, NormalizedName)
    VALUES
        ('00000000-0000-0000-0000-000000000008', 'Candidates Read', 'candidatesread'),
        ('00000000-0000-0000-0000-000000000009', 'Candidates Edit', 'candidatesedit'),
        ('00000000-0000-0000-0000-000000000010', 'Positions Read', 'positionsread'),
        ('00000000-0000-0000-0000-000000000011', 'Positions Edit', 'positionsedit')

    INSERT INTO [Permission]
        (Id, Name, NormalizedName, LastUpdate, IsActive)
    SELECT p.Id, p.Name, p.NormalizedName, @now, 1
    FROM @permissions p

    -- Create admin role
    DECLARE @adminRoleId UNIQUEIDENTIFIER = NEWID();

    SELECT @adminRoleId = Id FROM [Role]
    WHERE NormalizedName = 'administrator'

    -- Assign permissions to admin role
    INSERT INTO [RolePermission]
        (RoleId, PermissionId)
    SELECT @adminRoleId, p.Id
    FROM @permissions p