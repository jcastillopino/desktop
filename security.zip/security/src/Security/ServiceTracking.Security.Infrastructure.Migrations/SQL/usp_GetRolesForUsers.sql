﻿CREATE PROC [dbo].[usp_GetRolesForUsers]
@users UserType READONLY
AS
SET NOCOUNT ON
    SELECT 
      RS.UserId, 
	  RS.RoleId,
      RS.RoleName 
    FROM 
      (
        SELECT 
          UU.UserId AS UserId, 
		  R.Id AS RoleId,
          R.Name As RoleName, 
          ROW_NUMBER() OVER (
            Partition BY UR.UserId
            ORDER BY 
              UR.UserId
        ) AS Rank 
        FROM 
          UserRole UR 
          JOIN [dbo].[Role] R ON UR.RoleId = R.Id
          JOIN @users AS UU ON UU.UserId = UR.UserId
         WHERE R.IsActive = 1
      ) RS 
    WHERE 
      Rank <= 10
