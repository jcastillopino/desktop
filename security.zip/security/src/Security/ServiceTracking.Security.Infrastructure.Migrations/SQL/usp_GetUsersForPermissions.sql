﻿CREATE PROC [dbo].[usp_GetUsersForPermissions]
	@permissions PermissionType READONLY
AS

SET NOCOUNT ON
	SELECT 
		rs.PermissionId AS Permission,
		rs.Email
	FROM (
		SELECT  UPP.PermissionId AS PermissionId,
				UU.Email As Email, 
				ROW_NUMBER() 
		  OVER (Partition BY UPP.PermissionId
				ORDER BY UU.Email DESC ) AS Rank
		from UserPermission UPP
			JOIN [dbo].[User] UU ON UPP.UserId = UU.Id
			JOIN @permissions p ON P.PermissionId = UPP.PermissionId
		WHERE UU.IsActive = 1
		) rs WHERE Rank <= 10