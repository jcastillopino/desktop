﻿CREATE PROC [dbo].[usp_GetPermissionsForRoles]
	@roles RoleType READONLY
AS

SET NOCOUNT ON
SELECT 
  RS.RoleId, 
  RS.PermissionName,
  RS.PermissionId 
FROM 
  (
    SELECT 
      RP.RoleId AS RoleId, 
      P.Name As PermissionName, 
      RP.PermissionId AS PermissionId, 
      ROW_NUMBER() OVER (
        Partition BY RP.RoleId 
        ORDER BY 
          P.Name
      ) AS Rank 
    FROM 
      RolePermission RP 
      JOIN [dbo].[Permission] P ON RP.PermissionId = P.Id
      JOIN @roles PP ON PP.RoleId = RP.RoleId
    WHERE P.IsActive = 1
  ) RS 
WHERE 
  Rank <= 10
