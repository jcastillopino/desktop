﻿CREATE PROC [dbo].[usp_GetPermissionsForUsers]
@users UserType READONLY
AS
SET NOCOUNT ON
    SELECT 
      RS.UserId, 
	  RS.PermissionId,
      RS.PermissionName 
    FROM 
      (
        SELECT 
          UU.UserId AS UserId, 
		  P.Id AS PermissionId,
          P.Name As PermissionName, 
          ROW_NUMBER() OVER (
            Partition BY UP.UserId
            ORDER BY 
              UP.UserId
          ) AS Rank 
        FROM 
          UserPermission UP 
          JOIN [dbo].[Permission] P ON UP.PermissionId = P.Id
          JOIN @users AS UU ON UU.UserId = UP.UserId
        WHERE P.IsActive = 1
      ) RS 
    WHERE 
      Rank <= 10