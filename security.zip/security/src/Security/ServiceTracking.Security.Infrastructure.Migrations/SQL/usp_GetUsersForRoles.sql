﻿CREATE PROC [dbo].[usp_GetUsersForRoles]
	@roles RoleType READONLY
AS

SET NOCOUNT ON
SELECT 
  RS.RoleId, 
  RS.UserName 
FROM 
  (
    SELECT 
      UR.RoleId AS RoleId, 
      CONCAT(U.Name , ' ', U.LastName ) As UserName, 
      ROW_NUMBER() OVER (
        Partition BY UR.RoleId 
        ORDER BY 
          U.Name
      ) AS Rank 
    FROM 
      UserRole UR 
      JOIN [dbo].[User] U ON UR.UserId = U.Id
      JOIN @roles PP ON PP.RoleId = UR.RoleId
    WHERE 
      U.IsActive = 1
  ) RS 
WHERE 
  Rank <= 10
